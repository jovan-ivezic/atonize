# WordPress MySQL database migration
#
# Generated: Thursday 14. December 2017 13:08 UTC
# Hostname: localhost
# Database: `joekrollbuilder`
# URL: //localhost/joekrollbuilder.com
# Path: /Applications/MAMP/htdocs/joekrollbuilder.com
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_rg_form, wp_rg_form_meta, wp_rg_form_view, wp_rg_incomplete_submissions, wp_rg_lead, wp_rg_lead_detail, wp_rg_lead_detail_long, wp_rg_lead_meta, wp_rg_lead_notes, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users, wp_yoast_seo_links, wp_yoast_seo_meta
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, nav_menu_item, page, portfolio, post
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=791 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/joekrollbuilder.com', 'yes'),
(2, 'home', 'http://localhost/joekrollbuilder.com', 'yes'),
(3, 'blogname', 'Joe Kroll Builder', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'wp@makespaceweb.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '0', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'closed', 'yes'),
(20, 'default_ping_status', 'closed', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '1', 'yes'),
(27, 'moderation_notify', '0', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:107:{s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:25:"index.php?xsl=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:12:"portfolio/?$";s:29:"index.php?post_type=portfolio";s:42:"portfolio/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?post_type=portfolio&feed=$matches[1]";s:37:"portfolio/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?post_type=portfolio&feed=$matches[1]";s:29:"portfolio/page/([0-9]{1,})/?$";s:47:"index.php?post_type=portfolio&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:35:"portfolio/.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"portfolio/.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"portfolio/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"portfolio/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"portfolio/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"portfolio/.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"portfolio/(.+?)/embed/?$";s:42:"index.php?portfolio=$matches[1]&embed=true";s:28:"portfolio/(.+?)/trackback/?$";s:36:"index.php?portfolio=$matches[1]&tb=1";s:48:"portfolio/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?portfolio=$matches[1]&feed=$matches[2]";s:43:"portfolio/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?portfolio=$matches[1]&feed=$matches[2]";s:36:"portfolio/(.+?)/page/?([0-9]{1,})/?$";s:49:"index.php?portfolio=$matches[1]&paged=$matches[2]";s:43:"portfolio/(.+?)/comment-page-([0-9]{1,})/?$";s:49:"index.php?portfolio=$matches[1]&cpage=$matches[2]";s:32:"portfolio/(.+?)(?:/([0-9]+))?/?$";s:48:"index.php?portfolio=$matches[1]&page=$matches[2]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=4&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:5:{i:0;s:29:"gravityforms/gravityforms.php";i:1;s:25:"add-to-any/add-to-any.php";i:2;s:34:"advanced-custom-fields-pro/acf.php";i:3;s:24:"wordpress-seo/wp-seo.php";i:4;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'makespace-framework', 'yes'),
(41, 'stylesheet', 'makespace-child', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '1', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '0', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(58, 'thumbnail_size_w', '300', 'yes'),
(59, 'thumbnail_size_h', '300', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '900', 'yes'),
(62, 'medium_size_h', '900', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '2048', 'yes'),
(65, 'large_size_h', '2048', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '1', 'yes'),
(70, 'close_comments_days_old', '1', 'yes'),
(71, 'thread_comments', '0', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', 'America/Kentucky/Louisville', 'yes'),
(83, 'page_for_posts', '5', 'yes'),
(84, 'page_on_front', '4', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:20:"wpseo_manage_options";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:13:"wpseo_manager";a:2:{s:4:"name";s:11:"SEO Manager";s:12:"capabilities";a:37:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;s:20:"wpseo_manage_options";b:1;}}s:12:"wpseo_editor";a:2:{s:4:"name";s:10:"SEO Editor";s:12:"capabilities";a:36:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(103, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'nonce_key', 'SLIKK#,8n6@hRc;u8ofi_ 4x(SLtg7R7,5rRGa<e(4fV!]>y-Ig`Ty+p(CHnRdtV', 'no'),
(107, 'nonce_salt', 'EIi$-a,mcLpRPWS5/d5+XEwo$xWTd7|NHs4>UV5,Z^1S&~cKj|n9{ax-s?W3u{Ek', 'no'),
(108, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'cron', 'a:5:{i:1513283724;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1513283726;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1513283746;a:2:{s:19:"wpseo-reindex-links";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:17:"gravityforms_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1513331511;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(113, 'auth_key', 'qA-q#NBTF|BG99KyJg{TP^LG_W=#]O.gg^^2N!MBa1,OwwjSBTYK*Wd Wv~z&`Pp', 'no'),
(114, 'auth_salt', 'b7lEI/s[Ghu7my>*>])O*;I!>DV@E9GH~*G!;IIVf4?(KSG/#k&dZpRw_v_6o:~[', 'no'),
(115, 'logged_in_key', '#)p?do8@w#kJ(;<N7.T5Wz78$%L,_MN|0O?PTZ^LJX:=2lfPqMO J[`$AcxIz ~:', 'no'),
(116, 'logged_in_salt', 'WssXXm[|bONA)VN5[V@lyvE0[{ip]~u5+;EyP1)p{QZ.Vop9~:sa,) 9VhB0p_nG', 'no'),
(126, 'can_compress_scripts', '1', 'no'),
(139, 'recently_activated', 'a:0:{}', 'yes'),
(140, 'wpseo', 'a:25:{s:14:"blocking_files";a:0:{}s:15:"ms_defaults_set";b:0;s:7:"version";s:5:"5.9.3";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:17:"company_or_person";s:0:"";s:20:"disableadvanced_meta";b:1;s:19:"onpage_indexability";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:11:"person_name";s:0:"";s:12:"website_name";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"yandexverify";s:0:"";s:9:"site_type";s:0:"";s:20:"has_multiple_authors";s:0:"";s:16:"environment_type";s:0:"";s:23:"content_analysis_active";b:1;s:23:"keyword_analysis_active";b:1;s:20:"enable_setting_pages";b:1;s:21:"enable_admin_bar_menu";b:1;s:26:"enable_cornerstone_content";b:1;s:24:"enable_text_link_counter";b:1;s:22:"show_onboarding_notice";b:1;s:18:"first_activated_on";i:1511900134;}', 'yes'),
(141, 'wpseo_permalinks', 'a:9:{s:15:"cleanpermalinks";b:0;s:24:"cleanpermalink-extravars";s:0:"";s:29:"cleanpermalink-googlecampaign";b:0;s:31:"cleanpermalink-googlesitesearch";b:0;s:15:"cleanreplytocom";b:0;s:10:"cleanslugs";b:1;s:18:"redirectattachment";b:0;s:17:"stripcategorybase";b:0;s:13:"trailingslash";b:0;}', 'yes'),
(142, 'wpseo_titles', 'a:53:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-dash";s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page not found %%sep%% %%sitename%%";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:13:"showdate-post";b:0;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:1;}', 'yes'),
(143, 'wpseo_social', 'a:20:{s:9:"fb_admins";a:0:{}s:12:"fbconnectkey";s:32:"d6f2c8071b510b2dc11dacaa284539f6";s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:14:"plus-publisher";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:19:"summary_large_image";s:11:"youtube_url";s:0:"";s:15:"google_plus_url";s:0:"";s:10:"fbadminapp";s:0:"";}', 'yes'),
(144, 'wpseo_rss', 'a:2:{s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";}', 'yes'),
(145, 'wpseo_internallinks', 'a:10:{s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:23:"breadcrumbs-blog-remove";b:0;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:1;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:1:"|";s:23:"post_types-post-maintax";i:0;}', 'yes'),
(146, 'wpseo_xml', 'a:16:{s:22:"disable_author_sitemap";b:1;s:22:"disable_author_noposts";b:1;s:16:"enablexmlsitemap";b:1;s:16:"entries-per-page";i:1000;s:14:"excluded-posts";s:0:"";s:38:"user_role-administrator-not_in_sitemap";b:0;s:31:"user_role-editor-not_in_sitemap";b:0;s:31:"user_role-author-not_in_sitemap";b:0;s:36:"user_role-contributor-not_in_sitemap";b:0;s:35:"user_role-subscriber-not_in_sitemap";b:0;s:30:"post_types-post-not_in_sitemap";b:0;s:30:"post_types-page-not_in_sitemap";b:0;s:36:"post_types-attachment-not_in_sitemap";b:1;s:34:"taxonomies-category-not_in_sitemap";b:0;s:34:"taxonomies-post_tag-not_in_sitemap";b:0;s:37:"taxonomies-post_format-not_in_sitemap";b:0;}', 'yes'),
(147, 'wpseo_flush_rewrite', '1', 'yes'),
(150, 'widget_gform_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(151, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes'),
(152, 'gform_pending_installation', '', 'yes'),
(153, 'gform_enable_background_updates', '1', 'yes'),
(154, 'rg_gforms_key', '5c75c377901243663d9ac040b0ff3905', 'yes'),
(155, 'rg_gforms_message', '<!--GFM-->', 'yes'),
(158, 'rg_form_version', '2.2.5', 'yes'),
(161, 'acf_version', '5.6.7', 'yes'),
(165, 'gf_is_upgrading', '0', 'yes'),
(166, 'gf_previous_db_version', '0', 'yes'),
(167, 'gf_db_version', '2.2.5', 'yes'),
(168, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3MjoiYjNKa1pYSmZhV1E5TlRJeE9EbDhkSGx3WlQxa1pYWmxiRzl3WlhKOFpHRjBaVDB5TURFMUxUQXpMVEUzSURFMU9qRTJPakl5IjtzOjM6InVybCI7czo0MToiaHR0cDovL2xvY2FsaG9zdDo4ODg4L2pvZWtyb2xsYnVpbGRlci5jb20iO30=', 'yes'),
(170, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1513256912;}', 'no'),
(175, 'theme_mods_twentyseventeen', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1512685425;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(202, 'current_theme', 'Makespace Theme', 'yes'),
(203, 'theme_mods_makespace-child', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:2;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(204, 'theme_switched', '', 'yes'),
(209, 'gf_imported_theme_file', 'a:1:{s:19:"makespace-framework";b:1;}', 'yes'),
(210, 'makespace_theme_config', 'a:2:{s:20:"populated_post_types";a:2:{i:0;s:4:"post";i:1;s:9:"portfolio";}s:21:"did_install_framework";i:1;}', 'yes'),
(211, 'rg_gforms_disable_css', '1', 'yes'),
(212, 'rg_gforms_enable_html5', '1', 'yes'),
(213, 'wpseo_sitemap_1_cache_validator', '3kE1n', 'no'),
(214, 'wpseo_sitemap_page_cache_validator', '3kE1o', 'no'),
(215, 'wpseo_sitemap_category_cache_validator', '6PmSL', 'no'),
(216, 'wpseo_sitemap_post_cache_validator', '6PmXs', 'no'),
(237, 'options_msw_ses_send_via_amazon', '1', 'yes'),
(238, '_options_msw_ses_send_via_amazon', 'field_56cbac4a15c80', 'yes'),
(239, 'options_msw_ses_sender_name', 'WordPress', 'yes'),
(240, '_options_msw_ses_sender_name', 'field_56e221da427ab', 'yes'),
(241, 'options_msw_ses_sender_email', 'wp@makespaceweb.com', 'yes'),
(242, '_options_msw_ses_sender_email', 'field_56cbadc4102fe', 'yes'),
(243, 'options_msw_google_map_api_key', 'AIzaSyAhUquEmRF0RqSrAwrsblx3BWSr4wX0atk', 'yes'),
(244, '_options_msw_google_map_api_key', 'field_57baf557b0230', 'yes'),
(245, 'options_site_logo', '24', 'yes'),
(246, '_options_site_logo', 'field_56c53575b5a60', 'yes'),
(247, 'options_favicon', '', 'yes'),
(248, '_options_favicon', 'field_56c53593b5a61', 'yes'),
(249, 'options_menu_type', 'ocn', 'yes'),
(250, '_options_menu_type', 'field_56c7ebe15394e', 'yes'),
(251, 'options_contact_information', '1', 'yes'),
(252, '_options_contact_information', 'field_56c53a165ed97', 'yes'),
(253, 'options_header_javascript', '', 'yes'),
(254, '_options_header_javascript', 'field_56c535d1f0ce4', 'yes'),
(255, 'options_footer_javascript', '', 'yes'),
(256, '_options_footer_javascript', 'field_56c53b93f1877', 'yes'),
(274, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(331, 'wpseo_sitemap_cache_validator_global', '6hl2O', 'no'),
(397, 'upload_path', '', 'yes'),
(398, 'upload_url_path', '', 'yes'),
(421, 'options_contact_information_0_map', '', 'yes'),
(422, '_options_contact_information_0_map', 'field_56c53a895ed99', 'yes'),
(423, 'options_contact_information_0_address', '', 'yes'),
(424, '_options_contact_information_0_address', 'field_56c7e13924c55', 'yes'),
(425, 'options_contact_information_0_map_marker', '', 'yes'),
(426, '_options_contact_information_0_map_marker', 'field_56c8795c3d137', 'yes'),
(427, 'options_contact_information_0_location_name', '', 'yes'),
(428, '_options_contact_information_0_location_name', 'field_56c7e20b24c5a', 'yes'),
(429, 'options_contact_information_0_phone_number', '(502) 419-4325', 'yes'),
(430, '_options_contact_information_0_phone_number', 'field_56c7e1b924c57', 'yes'),
(431, 'options_contact_information_0_email_address', 'info@joekrollbuilder.com', 'yes'),
(432, '_options_contact_information_0_email_address', 'field_56c7e1dd24c59', 'yes'),
(433, 'options_contact_information_0_fax_number', '', 'yes'),
(434, '_options_contact_information_0_fax_number', 'field_56c7e1cd24c58', 'yes'),
(435, 'options_contact_information_0_social_media_links_0_site', 'Facebook', 'yes'),
(436, '_options_contact_information_0_social_media_links_0_site', 'field_56c87a89702e1', 'yes'),
(437, 'options_contact_information_0_social_media_links_0_url', 'http://facebook.com', 'yes'),
(438, '_options_contact_information_0_social_media_links_0_url', 'field_56c87a97702e2', 'yes'),
(439, 'options_contact_information_0_social_media_links_0_class', 'facebook-official', 'yes'),
(440, '_options_contact_information_0_social_media_links_0_class', 'field_57bb0a976cbb8', 'yes'),
(441, 'options_contact_information_0_social_media_links_1_site', 'Youtube', 'yes'),
(442, '_options_contact_information_0_social_media_links_1_site', 'field_56c87a89702e1', 'yes'),
(443, 'options_contact_information_0_social_media_links_1_url', 'http://youtube.com', 'yes'),
(444, '_options_contact_information_0_social_media_links_1_url', 'field_56c87a97702e2', 'yes'),
(445, 'options_contact_information_0_social_media_links_1_class', 'youtube-square', 'yes'),
(446, '_options_contact_information_0_social_media_links_1_class', 'field_57bb0a976cbb8', 'yes'),
(447, 'options_contact_information_0_social_media_links', '2', 'yes'),
(448, '_options_contact_information_0_social_media_links', 'field_56c87a7c702e0', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(458, 'rg_gforms_enable_akismet', '1', 'yes'),
(459, 'rg_gforms_currency', 'USD', 'yes'),
(460, 'gform_enable_toolbar_menu', '1', 'yes'),
(466, 'options_msw_post_type_0_plural_name', 'Portfolio', 'yes'),
(467, '_options_msw_post_type_0_plural_name', 'field_56c5498aae42c', 'yes'),
(468, 'options_msw_post_type_0_singular_name', 'Case Study', 'yes'),
(469, '_options_msw_post_type_0_singular_name', 'field_56c5497aae42b', 'yes'),
(470, 'options_msw_post_type_0_slug', 'portfolio', 'yes'),
(471, '_options_msw_post_type_0_slug', 'field_56c54a1467543', 'yes'),
(472, 'options_msw_post_type_0_dashicon', 'dashicons-admin-generic', 'yes'),
(473, '_options_msw_post_type_0_dashicon', 'field_56c54a9667544', 'yes'),
(474, 'options_msw_post_type_0_menu_position', '5', 'yes'),
(475, '_options_msw_post_type_0_menu_position', 'field_56c54cf3c6d10', 'yes'),
(476, 'options_msw_post_type_0_menu_name', 'Portfolio', 'yes'),
(477, '_options_msw_post_type_0_menu_name', 'field_56e2260b0fc86', 'yes'),
(478, 'options_msw_post_type_0_options_supports', 'a:5:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:9:"thumbnail";i:3;s:7:"excerpt";i:4;s:15:"page-attributes";}', 'yes'),
(479, '_options_msw_post_type_0_options_supports', 'field_56c54ac44d70c', 'yes'),
(480, 'options_msw_post_type_0_public_information', 'a:1:{i:0;s:11:"has_archive";}', 'yes'),
(481, '_options_msw_post_type_0_public_information', 'field_56c54bd4c6d0f', 'yes'),
(482, 'options_msw_post_type_0_taxonomies', '1', 'yes'),
(483, '_options_msw_post_type_0_taxonomies', 'field_56c54d8780da9', 'yes'),
(484, 'options_msw_post_type', '1', 'yes'),
(485, '_options_msw_post_type', 'field_56c54957ae42a', 'yes'),
(486, 'wpseo_sitemap_portfolio_cache_validator', 'i5wA', 'no'),
(487, 'options_msw_post_type_0_taxonomies_0_plural_name', 'Portfolio categories', 'yes'),
(488, '_options_msw_post_type_0_taxonomies_0_plural_name', 'field_56c54d9380daa', 'yes'),
(489, 'options_msw_post_type_0_taxonomies_0_singular_name', 'Portfolio category', 'yes'),
(490, '_options_msw_post_type_0_taxonomies_0_singular_name', 'field_56c54df580dab', 'yes'),
(491, 'options_msw_post_type_0_taxonomies_0_slug', 'portfolio-category', 'yes'),
(492, '_options_msw_post_type_0_taxonomies_0_slug', 'field_56c54e1080dac', 'yes'),
(493, 'options_msw_post_type_0_taxonomies_0_type', 'yes', 'yes'),
(494, '_options_msw_post_type_0_taxonomies_0_type', 'field_56c54e1f80dad', 'yes'),
(499, 'category_children', 'a:0:{}', 'yes'),
(570, 'options_footer_cta_image', '148', 'yes'),
(571, '_options_footer_cta_image', 'field_5a3042aa37de1', 'yes'),
(572, 'options_footer_cta_text', 'You have the <strong>vision</strong>. We have the <strong>experience</strong>. Let’s build your <strong>dream</strong> together.', 'yes'),
(573, '_options_footer_cta_text', 'field_5a3042bc37de2', 'yes'),
(574, 'options_footer_cta_link_text', 'Contact Us Today', 'yes'),
(575, '_options_footer_cta_link_text', 'field_5a3042c637de3', 'yes'),
(576, 'options_footer_cta_link', '6', 'yes'),
(577, '_options_footer_cta_link', 'field_5a3042d437de4', 'yes'),
(623, 'options_header_image', '165', 'yes'),
(624, '_options_header_image', 'field_5a30694cefffa', 'yes'),
(677, 'wpseo_sitemap_54_cache_validator', '6nqs', 'no'),
(711, 'widget_a2a_share_save_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(712, 'widget_a2a_follow_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(726, 'addtoany_options', 'a:35:{s:8:"position";s:6:"bottom";s:30:"display_in_posts_on_front_page";s:2:"-1";s:33:"display_in_posts_on_archive_pages";s:2:"-1";s:19:"display_in_excerpts";s:2:"-1";s:16:"display_in_posts";s:2:"-1";s:16:"display_in_pages";s:2:"-1";s:22:"display_in_attachments";s:2:"-1";s:15:"display_in_feed";s:2:"-1";s:7:"onclick";s:2:"-1";s:9:"icon_size";s:2:"32";s:7:"icon_bg";s:8:"original";s:13:"icon_bg_color";s:7:"#2a2a2a";s:7:"icon_fg";s:8:"original";s:13:"icon_fg_color";s:7:"#ffffff";s:6:"button";s:10:"A2A_SVG_32";s:13:"button_custom";s:0:"";s:17:"button_show_count";s:2:"-1";s:6:"header";s:0:"";s:23:"additional_js_variables";s:0:"";s:14:"additional_css";s:0:"";s:12:"custom_icons";s:2:"-1";s:16:"custom_icons_url";s:1:"/";s:17:"custom_icons_type";s:3:"png";s:18:"custom_icons_width";s:0:"";s:19:"custom_icons_height";s:0:"";s:5:"cache";s:2:"-1";s:24:"display_in_cpt_portfolio";s:2:"-1";s:11:"button_text";s:5:"Share";s:24:"special_facebook_options";a:1:{s:10:"show_count";s:2:"-1";}s:15:"active_services";a:3:{i:0;s:8:"facebook";i:1;s:7:"twitter";i:2;s:11:"google_plus";}s:29:"special_facebook_like_options";a:1:{s:4:"verb";s:4:"like";}s:29:"special_twitter_tweet_options";a:1:{s:10:"show_count";s:2:"-1";}s:30:"special_google_plusone_options";a:1:{s:10:"show_count";s:2:"-1";}s:33:"special_google_plus_share_options";a:1:{s:10:"show_count";s:2:"-1";}s:29:"special_pinterest_pin_options";a:1:{s:10:"show_count";s:2:"-1";}}', 'yes'),
(735, 'options_portfolio_header_image', '17', 'no'),
(736, '_options_portfolio_header_image', 'field_5a30807f213c8', 'no'),
(737, 'options_portfolio_archive_intro_text', 'Nulla porttitor accumsan tincidunt. Cras ultricies ligula sed magna dictum porta. Sed porttitor lectus nibh. Lorem ipsum dolor sit amet, consectetur adipiscing elit.\r\n\r\nDonec sollicitudin molestie malesuada. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Pellentesque in ipsum id orci porta dapibus.', 'no'),
(738, '_options_portfolio_archive_intro_text', 'field_5a3071d3b4cdb', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=1231 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 6, '_wp_page_template', 'page_contact.php'),
(4, 11, '_wp_attached_file', '2017/12/unsplash-2.jpeg'),
(5, 11, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:800;s:4:"file";s:23:"2017/12/unsplash-2.jpeg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"unsplash-2-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"unsplash-2-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"unsplash-2-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"unsplash-2-1024x683.jpeg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(6, 10, '_thumbnail_id', '11'),
(8, 13, '_wp_attached_file', '2017/12/unsplash-3.jpeg'),
(9, 13, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:800;s:4:"file";s:23:"2017/12/unsplash-3.jpeg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"unsplash-3-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"unsplash-3-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"unsplash-3-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"unsplash-3-1024x683.jpeg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(10, 12, '_thumbnail_id', '13'),
(14, 17, '_wp_attached_file', '2017/12/unsplash-4.jpeg'),
(15, 17, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:800;s:4:"file";s:23:"2017/12/unsplash-4.jpeg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"unsplash-4-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"unsplash-4-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"unsplash-4-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"unsplash-4-1024x683.jpeg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(16, 16, '_thumbnail_id', '17'),
(17, 24, '_wp_attached_file', '2017/12/logo-1.svg'),
(18, 25, '_edit_last', '1'),
(19, 25, '_wp_page_template', 'default'),
(20, 25, '_yoast_wpseo_content_score', '60'),
(21, 25, '_edit_lock', '1513123245:1'),
(22, 27, '_edit_last', '1'),
(23, 27, '_wp_page_template', 'page_home-building-process.php'),
(24, 27, '_yoast_wpseo_content_score', '30'),
(25, 27, '_edit_lock', '1513241613:1'),
(30, 31, '_menu_item_type', 'post_type'),
(31, 31, '_menu_item_menu_item_parent', '0'),
(32, 31, '_menu_item_object_id', '4'),
(33, 31, '_menu_item_object', 'page'),
(34, 31, '_menu_item_target', ''),
(35, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(36, 31, '_menu_item_xfn', ''),
(37, 31, '_menu_item_url', ''),
(38, 31, '_menu_item_orphaned', '1512813346'),
(39, 32, '_menu_item_type', 'post_type'),
(40, 32, '_menu_item_menu_item_parent', '0'),
(41, 32, '_menu_item_object_id', '25'),
(42, 32, '_menu_item_object', 'page'),
(43, 32, '_menu_item_target', ''),
(44, 32, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(45, 32, '_menu_item_xfn', ''),
(46, 32, '_menu_item_url', ''),
(47, 32, '_menu_item_orphaned', '1512813347'),
(48, 33, '_menu_item_type', 'post_type'),
(49, 33, '_menu_item_menu_item_parent', '0'),
(50, 33, '_menu_item_object_id', '27'),
(51, 33, '_menu_item_object', 'page'),
(52, 33, '_menu_item_target', ''),
(53, 33, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(54, 33, '_menu_item_xfn', ''),
(55, 33, '_menu_item_url', ''),
(56, 33, '_menu_item_orphaned', '1512813348'),
(57, 34, '_menu_item_type', 'post_type'),
(58, 34, '_menu_item_menu_item_parent', '0'),
(59, 34, '_menu_item_object_id', '4'),
(60, 34, '_menu_item_object', 'page'),
(61, 34, '_menu_item_target', ''),
(62, 34, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(63, 34, '_menu_item_xfn', ''),
(64, 34, '_menu_item_url', ''),
(65, 34, '_menu_item_orphaned', '1512813348'),
(75, 36, '_menu_item_type', 'post_type'),
(76, 36, '_menu_item_menu_item_parent', '0'),
(77, 36, '_menu_item_object_id', '5'),
(78, 36, '_menu_item_object', 'page'),
(79, 36, '_menu_item_target', ''),
(80, 36, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(81, 36, '_menu_item_xfn', ''),
(82, 36, '_menu_item_url', ''),
(83, 36, '_menu_item_orphaned', '1512813350'),
(84, 37, '_menu_item_type', 'post_type'),
(85, 37, '_menu_item_menu_item_parent', '0'),
(86, 37, '_menu_item_object_id', '6'),
(87, 37, '_menu_item_object', 'page'),
(88, 37, '_menu_item_target', ''),
(89, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(90, 37, '_menu_item_xfn', ''),
(91, 37, '_menu_item_url', ''),
(92, 37, '_menu_item_orphaned', '1512813351'),
(93, 38, '_menu_item_type', 'post_type'),
(94, 38, '_menu_item_menu_item_parent', '0'),
(95, 38, '_menu_item_object_id', '7'),
(96, 38, '_menu_item_object', 'page'),
(97, 38, '_menu_item_target', ''),
(98, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(99, 38, '_menu_item_xfn', ''),
(100, 38, '_menu_item_url', ''),
(101, 38, '_menu_item_orphaned', '1512813352'),
(102, 39, '_menu_item_type', 'post_type'),
(103, 39, '_menu_item_menu_item_parent', '0'),
(104, 39, '_menu_item_object_id', '8'),
(105, 39, '_menu_item_object', 'page'),
(106, 39, '_menu_item_target', ''),
(107, 39, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(108, 39, '_menu_item_xfn', ''),
(109, 39, '_menu_item_url', ''),
(110, 39, '_menu_item_orphaned', '1512813352'),
(111, 40, '_menu_item_type', 'post_type'),
(112, 40, '_menu_item_menu_item_parent', '0'),
(113, 40, '_menu_item_object_id', '9'),
(114, 40, '_menu_item_object', 'page'),
(115, 40, '_menu_item_target', ''),
(116, 40, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(117, 40, '_menu_item_xfn', ''),
(118, 40, '_menu_item_url', ''),
(119, 40, '_menu_item_orphaned', '1512813353') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(120, 41, '_menu_item_type', 'post_type'),
(121, 41, '_menu_item_menu_item_parent', '0'),
(122, 41, '_menu_item_object_id', '4'),
(123, 41, '_menu_item_object', 'page'),
(124, 41, '_menu_item_target', ''),
(125, 41, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(126, 41, '_menu_item_xfn', ''),
(127, 41, '_menu_item_url', ''),
(128, 41, '_menu_item_orphaned', '1512813362'),
(129, 42, '_menu_item_type', 'post_type'),
(130, 42, '_menu_item_menu_item_parent', '0'),
(131, 42, '_menu_item_object_id', '25'),
(132, 42, '_menu_item_object', 'page'),
(133, 42, '_menu_item_target', ''),
(134, 42, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(135, 42, '_menu_item_xfn', ''),
(136, 42, '_menu_item_url', ''),
(137, 42, '_menu_item_orphaned', '1512813363'),
(138, 43, '_menu_item_type', 'post_type'),
(139, 43, '_menu_item_menu_item_parent', '0'),
(140, 43, '_menu_item_object_id', '27'),
(141, 43, '_menu_item_object', 'page'),
(142, 43, '_menu_item_target', ''),
(143, 43, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(144, 43, '_menu_item_xfn', ''),
(145, 43, '_menu_item_url', ''),
(146, 43, '_menu_item_orphaned', '1512813363'),
(147, 44, '_menu_item_type', 'post_type'),
(148, 44, '_menu_item_menu_item_parent', '0'),
(149, 44, '_menu_item_object_id', '4'),
(150, 44, '_menu_item_object', 'page'),
(151, 44, '_menu_item_target', ''),
(152, 44, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(153, 44, '_menu_item_xfn', ''),
(154, 44, '_menu_item_url', ''),
(155, 44, '_menu_item_orphaned', '1512813364'),
(165, 46, '_menu_item_type', 'post_type'),
(166, 46, '_menu_item_menu_item_parent', '0'),
(167, 46, '_menu_item_object_id', '5'),
(168, 46, '_menu_item_object', 'page'),
(169, 46, '_menu_item_target', ''),
(170, 46, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(171, 46, '_menu_item_xfn', ''),
(172, 46, '_menu_item_url', ''),
(173, 46, '_menu_item_orphaned', '1512813366'),
(174, 47, '_menu_item_type', 'post_type'),
(175, 47, '_menu_item_menu_item_parent', '0'),
(176, 47, '_menu_item_object_id', '6'),
(177, 47, '_menu_item_object', 'page'),
(178, 47, '_menu_item_target', ''),
(179, 47, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(180, 47, '_menu_item_xfn', ''),
(181, 47, '_menu_item_url', ''),
(182, 47, '_menu_item_orphaned', '1512813366'),
(183, 48, '_menu_item_type', 'post_type'),
(184, 48, '_menu_item_menu_item_parent', '0'),
(185, 48, '_menu_item_object_id', '7'),
(186, 48, '_menu_item_object', 'page'),
(187, 48, '_menu_item_target', ''),
(188, 48, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(189, 48, '_menu_item_xfn', ''),
(190, 48, '_menu_item_url', ''),
(191, 48, '_menu_item_orphaned', '1512813367'),
(192, 49, '_menu_item_type', 'post_type'),
(193, 49, '_menu_item_menu_item_parent', '0'),
(194, 49, '_menu_item_object_id', '8'),
(195, 49, '_menu_item_object', 'page'),
(196, 49, '_menu_item_target', ''),
(197, 49, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(198, 49, '_menu_item_xfn', ''),
(199, 49, '_menu_item_url', ''),
(200, 49, '_menu_item_orphaned', '1512813368'),
(201, 50, '_menu_item_type', 'post_type'),
(202, 50, '_menu_item_menu_item_parent', '0'),
(203, 50, '_menu_item_object_id', '9'),
(204, 50, '_menu_item_object', 'page'),
(205, 50, '_menu_item_target', ''),
(206, 50, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(207, 50, '_menu_item_xfn', ''),
(208, 50, '_menu_item_url', ''),
(209, 50, '_menu_item_orphaned', '1512813368'),
(210, 51, '_menu_item_type', 'post_type'),
(211, 51, '_menu_item_menu_item_parent', '0'),
(212, 51, '_menu_item_object_id', '27'),
(213, 51, '_menu_item_object', 'page'),
(214, 51, '_menu_item_target', ''),
(215, 51, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(216, 51, '_menu_item_xfn', ''),
(217, 51, '_menu_item_url', ''),
(219, 52, '_menu_item_type', 'post_type'),
(220, 52, '_menu_item_menu_item_parent', '0'),
(221, 52, '_menu_item_object_id', '25'),
(222, 52, '_menu_item_object', 'page'),
(223, 52, '_menu_item_target', ''),
(224, 52, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(225, 52, '_menu_item_xfn', ''),
(226, 52, '_menu_item_url', ''),
(228, 53, '_menu_item_type', 'post_type'),
(229, 53, '_menu_item_menu_item_parent', '0'),
(230, 53, '_menu_item_object_id', '4') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(231, 53, '_menu_item_object', 'page'),
(232, 53, '_menu_item_target', ''),
(233, 53, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(234, 53, '_menu_item_xfn', ''),
(235, 53, '_menu_item_url', ''),
(246, 55, '_menu_item_type', 'post_type'),
(247, 55, '_menu_item_menu_item_parent', '0'),
(248, 55, '_menu_item_object_id', '6'),
(249, 55, '_menu_item_object', 'page'),
(250, 55, '_menu_item_target', ''),
(251, 55, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(252, 55, '_menu_item_xfn', ''),
(253, 55, '_menu_item_url', ''),
(255, 4, '_edit_lock', '1513239406:1'),
(256, 4, '_edit_last', '1'),
(257, 4, '_wp_page_template', 'default'),
(258, 4, '_yoast_wpseo_content_score', '30'),
(259, 6, '_edit_lock', '1513110132:1'),
(260, 6, '_edit_last', '1'),
(261, 6, '_yoast_wpseo_content_score', '30'),
(262, 60, '_wp_attached_file', '2017/12/joe-e1512935590373.png'),
(263, 60, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:300;s:6:"height";i:470;s:4:"file";s:30:"2017/12/joe-e1512935590373.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"joe-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:15:"joe-575x900.png";s:5:"width";i:575;s:6:"height";i:900;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(264, 60, '_wp_attachment_backup_sizes', 'a:1:{s:9:"full-orig";a:3:{s:5:"width";i:643;s:6:"height";i:1007;s:4:"file";s:7:"joe.png";}}'),
(265, 65, '_edit_last', '1'),
(266, 65, '_wp_page_template', 'page_trusted-partners.php'),
(267, 65, '_yoast_wpseo_content_score', '90'),
(268, 65, '_edit_lock', '1513122794:1'),
(269, 72, '_wp_attached_file', '2017/12/unsplash-5.jpeg'),
(270, 72, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:800;s:4:"file";s:23:"2017/12/unsplash-5.jpeg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"unsplash-5-300x300.jpeg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"unsplash-5-900x600.jpeg";s:5:"width";i:900;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"unsplash-5-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(271, 71, '_thumbnail_id', '72'),
(272, 74, '_wp_attached_file', '2017/12/unsplash-6.jpeg'),
(273, 74, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:800;s:4:"file";s:23:"2017/12/unsplash-6.jpeg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"unsplash-6-300x300.jpeg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"unsplash-6-900x600.jpeg";s:5:"width";i:900;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"unsplash-6-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(274, 73, '_thumbnail_id', '74'),
(275, 77, '_wp_attached_file', '2017/12/unsplash-7.jpeg'),
(276, 77, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:800;s:4:"file";s:23:"2017/12/unsplash-7.jpeg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"unsplash-7-300x300.jpeg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"unsplash-7-900x600.jpeg";s:5:"width";i:900;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"unsplash-7-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(277, 76, '_thumbnail_id', '77'),
(278, 86, '_wp_attached_file', '2017/12/unsplash-8.jpeg'),
(279, 86, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:800;s:4:"file";s:23:"2017/12/unsplash-8.jpeg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"unsplash-8-300x300.jpeg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"unsplash-8-900x600.jpeg";s:5:"width";i:900;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"unsplash-8-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(280, 85, '_thumbnail_id', '86'),
(281, 90, '_wp_attached_file', '2017/12/unsplash-9.jpeg'),
(282, 90, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:800;s:4:"file";s:23:"2017/12/unsplash-9.jpeg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"unsplash-9-300x300.jpeg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"unsplash-9-900x600.jpeg";s:5:"width";i:900;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"unsplash-9-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(283, 89, '_thumbnail_id', '90'),
(284, 95, '_wp_attached_file', '2017/12/unsplash-10.jpeg'),
(285, 95, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:800;s:4:"file";s:24:"2017/12/unsplash-10.jpeg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"unsplash-10-300x300.jpeg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"unsplash-10-900x600.jpeg";s:5:"width";i:900;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:24:"unsplash-10-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(286, 94, '_thumbnail_id', '95'),
(287, 99, '_edit_last', '1'),
(288, 99, '_edit_lock', '1513256760:1'),
(289, 4, 'hero_slides', '2'),
(290, 4, '_hero_slides', 'field_5a303bf5e8f78'),
(291, 107, 'hero_slides', ''),
(292, 107, '_hero_slides', 'field_5a303bf5e8f78'),
(293, 4, 'intro_section_title', 'Right at Home in  Jefferson and Oldham Counties'),
(294, 4, '_intro_section_title', 'field_5a303dc5aa8fe'),
(295, 4, 'intro_section_text', 'Ipsum vitae sollicitudin interdum felis ipsum convallis lorem acscele risque leo dolor slim trebor lehcar mailliw.'),
(296, 4, '_intro_section_text', 'field_5a303dd3aa8ff'),
(297, 4, 'intro_section_link_text', 'Learn more'),
(298, 4, '_intro_section_link_text', 'field_5a303de8aa900'),
(299, 4, 'intro_section_link', '25'),
(300, 4, '_intro_section_link', 'field_5a303e01aa901'),
(301, 4, 'about_section_title', 'Why Choose Joe Kroll to Build Your Home?'),
(302, 4, '_about_section_title', 'field_5a303ea8f153d'),
(303, 4, 'about_section_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit nulla facilisis dolor quis est suspen disse potenti phasellus et diam donec metus donec mi ante, vestibulum ut ornare non risque leo dolor slim trebor lehcar mailliw.'),
(304, 4, '_about_section_text', 'field_5a303eb1f153e'),
(305, 4, 'about_section_link_text', 'Learn more about us'),
(306, 4, '_about_section_link_text', 'field_5a303ec0f153f'),
(307, 4, 'about_section_link', '25'),
(308, 4, '_about_section_link', 'field_5a303ecff1540'),
(309, 4, 'about_section_image', '132'),
(310, 4, '_about_section_image', 'field_5a303ee0f1541'),
(311, 4, 'joes_partners', '9'),
(312, 4, '_joes_partners', 'field_5a303efaf1542'),
(313, 4, 'joes_partners_link_text', 'SEE All of OUR TRUSTED PARTNERS'),
(314, 4, '_joes_partners_link_text', 'field_5a303f29f1544'),
(315, 4, 'joes_partners_link', '65'),
(316, 4, '_joes_partners_link', 'field_5a303f32f1545'),
(317, 4, 'how_it_works_title', 'Here’s How It Works'),
(318, 4, '_how_it_works_title', 'field_5a303f6a8330b'),
(319, 4, 'how_it_works_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit nulla facilisis dolor quis est suspen disse potenti phasellus et diam donec ornare non risque leo dolor slim trebor lehcar mailliw.'),
(320, 4, '_how_it_works_text', 'field_5a303f768330c'),
(321, 4, 'how_it_works_steps', '5'),
(322, 4, '_how_it_works_steps', 'field_5a303f818330d'),
(323, 4, 'how_it_works_link_text', 'Learn more'),
(324, 4, '_how_it_works_link_text', 'field_5a303fce8e468'),
(325, 4, 'how_it_works_link', ''),
(326, 4, '_how_it_works_link', 'field_5a303fd78e469'),
(327, 131, 'hero_slides', ''),
(328, 131, '_hero_slides', 'field_5a303bf5e8f78'),
(329, 131, 'intro_section_title', 'Right at Home in  Jefferson and Oldham Counties'),
(330, 131, '_intro_section_title', 'field_5a303dc5aa8fe'),
(331, 131, 'intro_section_text', 'Ipsum vitae sollicitudin interdum felis ipsum convallis lorem acscele risque leo dolor slim trebor lehcar mailliw.'),
(332, 131, '_intro_section_text', 'field_5a303dd3aa8ff'),
(333, 131, 'intro_section_link_text', 'Learn more'),
(334, 131, '_intro_section_link_text', 'field_5a303de8aa900'),
(335, 131, 'intro_section_link', '25'),
(336, 131, '_intro_section_link', 'field_5a303e01aa901'),
(337, 131, 'about_section_title', ''),
(338, 131, '_about_section_title', 'field_5a303ea8f153d'),
(339, 131, 'about_section_text', ''),
(340, 131, '_about_section_text', 'field_5a303eb1f153e'),
(341, 131, 'about_section_link_text', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(342, 131, '_about_section_link_text', 'field_5a303ec0f153f'),
(343, 131, 'about_section_link', ''),
(344, 131, '_about_section_link', 'field_5a303ecff1540'),
(345, 131, 'about_section_image', ''),
(346, 131, '_about_section_image', 'field_5a303ee0f1541'),
(347, 131, 'joes_partners', ''),
(348, 131, '_joes_partners', 'field_5a303efaf1542'),
(349, 131, 'joes_partners_link_text', ''),
(350, 131, '_joes_partners_link_text', 'field_5a303f29f1544'),
(351, 131, 'joes_partners_link', ''),
(352, 131, '_joes_partners_link', 'field_5a303f32f1545'),
(353, 131, 'how_it_works_title', ''),
(354, 131, '_how_it_works_title', 'field_5a303f6a8330b'),
(355, 131, 'how_it_works_text', ''),
(356, 131, '_how_it_works_text', 'field_5a303f768330c'),
(357, 131, 'how_it_works_steps', ''),
(358, 131, '_how_it_works_steps', 'field_5a303f818330d'),
(359, 131, 'how_it_works_link_text', ''),
(360, 131, '_how_it_works_link_text', 'field_5a303fce8e468'),
(361, 131, 'how_it_works_link', ''),
(362, 131, '_how_it_works_link', 'field_5a303fd78e469'),
(363, 132, '_wp_attached_file', '2017/12/joe-1.png'),
(364, 132, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:643;s:6:"height";i:1007;s:4:"file";s:17:"2017/12/joe-1.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"joe-1-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:17:"joe-1-575x900.png";s:5:"width";i:575;s:6:"height";i:900;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(365, 4, 'joes_partners_0_partner_name', 'New century plumbing'),
(366, 4, '_joes_partners_0_partner_name', 'field_5a303f1df1543'),
(367, 4, 'joes_partners_1_partner_name', 'KME Electric'),
(368, 4, '_joes_partners_1_partner_name', 'field_5a303f1df1543'),
(369, 4, 'joes_partners_2_partner_name', 'Chapman Heating & Cooling'),
(370, 4, '_joes_partners_2_partner_name', 'field_5a303f1df1543'),
(371, 4, 'joes_partners_3_partner_name', 'Century Entertainment'),
(372, 4, '_joes_partners_3_partner_name', 'field_5a303f1df1543'),
(373, 4, 'joes_partners_4_partner_name', 'Premiere Flooring'),
(374, 4, '_joes_partners_4_partner_name', 'field_5a303f1df1543'),
(375, 4, 'joes_partners_5_partner_name', 'Willis-Klein'),
(376, 4, '_joes_partners_5_partner_name', 'field_5a303f1df1543'),
(377, 4, 'joes_partners_6_partner_name', 'PC Lumber'),
(378, 4, '_joes_partners_6_partner_name', 'field_5a303f1df1543'),
(379, 4, 'joes_partners_7_partner_name', 'Jennifer Bergin'),
(380, 4, '_joes_partners_7_partner_name', 'field_5a303f1df1543'),
(381, 4, 'joes_partners_8_partner_name', 'Cindy Druin'),
(382, 4, '_joes_partners_8_partner_name', 'field_5a303f1df1543'),
(383, 133, 'hero_slides', ''),
(384, 133, '_hero_slides', 'field_5a303bf5e8f78'),
(385, 133, 'intro_section_title', 'Right at Home in  Jefferson and Oldham Counties'),
(386, 133, '_intro_section_title', 'field_5a303dc5aa8fe'),
(387, 133, 'intro_section_text', 'Ipsum vitae sollicitudin interdum felis ipsum convallis lorem acscele risque leo dolor slim trebor lehcar mailliw.'),
(388, 133, '_intro_section_text', 'field_5a303dd3aa8ff'),
(389, 133, 'intro_section_link_text', 'Learn more'),
(390, 133, '_intro_section_link_text', 'field_5a303de8aa900'),
(391, 133, 'intro_section_link', '25'),
(392, 133, '_intro_section_link', 'field_5a303e01aa901'),
(393, 133, 'about_section_title', 'Why Choose Joe Kroll to Build Your Home?'),
(394, 133, '_about_section_title', 'field_5a303ea8f153d'),
(395, 133, 'about_section_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit nulla facilisis dolor quis est suspen disse potenti phasellus et diam donec metus donec mi ante, vestibulum ut ornare non risque leo dolor slim trebor lehcar mailliw.'),
(396, 133, '_about_section_text', 'field_5a303eb1f153e'),
(397, 133, 'about_section_link_text', 'Learn more about us'),
(398, 133, '_about_section_link_text', 'field_5a303ec0f153f'),
(399, 133, 'about_section_link', ''),
(400, 133, '_about_section_link', 'field_5a303ecff1540'),
(401, 133, 'about_section_image', '132'),
(402, 133, '_about_section_image', 'field_5a303ee0f1541'),
(403, 133, 'joes_partners', '9'),
(404, 133, '_joes_partners', 'field_5a303efaf1542'),
(405, 133, 'joes_partners_link_text', 'SEE All of OUR TRUSTED PARTNERS'),
(406, 133, '_joes_partners_link_text', 'field_5a303f29f1544'),
(407, 133, 'joes_partners_link', '65'),
(408, 133, '_joes_partners_link', 'field_5a303f32f1545'),
(409, 133, 'how_it_works_title', ''),
(410, 133, '_how_it_works_title', 'field_5a303f6a8330b'),
(411, 133, 'how_it_works_text', ''),
(412, 133, '_how_it_works_text', 'field_5a303f768330c'),
(413, 133, 'how_it_works_steps', ''),
(414, 133, '_how_it_works_steps', 'field_5a303f818330d'),
(415, 133, 'how_it_works_link_text', ''),
(416, 133, '_how_it_works_link_text', 'field_5a303fce8e468'),
(417, 133, 'how_it_works_link', ''),
(418, 133, '_how_it_works_link', 'field_5a303fd78e469'),
(419, 133, 'joes_partners_0_partner_name', 'New century plumbing'),
(420, 133, '_joes_partners_0_partner_name', 'field_5a303f1df1543'),
(421, 133, 'joes_partners_1_partner_name', 'KME Electric'),
(422, 133, '_joes_partners_1_partner_name', 'field_5a303f1df1543'),
(423, 133, 'joes_partners_2_partner_name', 'Chapman Heating & Cooling'),
(424, 133, '_joes_partners_2_partner_name', 'field_5a303f1df1543'),
(425, 133, 'joes_partners_3_partner_name', 'Century Entertainment'),
(426, 133, '_joes_partners_3_partner_name', 'field_5a303f1df1543'),
(427, 133, 'joes_partners_4_partner_name', 'Premiere Flooring'),
(428, 133, '_joes_partners_4_partner_name', 'field_5a303f1df1543'),
(429, 133, 'joes_partners_5_partner_name', 'Willis-Klein'),
(430, 133, '_joes_partners_5_partner_name', 'field_5a303f1df1543'),
(431, 133, 'joes_partners_6_partner_name', 'PC Lumber'),
(432, 133, '_joes_partners_6_partner_name', 'field_5a303f1df1543'),
(433, 133, 'joes_partners_7_partner_name', 'Jennifer Bergin'),
(434, 133, '_joes_partners_7_partner_name', 'field_5a303f1df1543'),
(435, 133, 'joes_partners_8_partner_name', 'Cindy Druin'),
(436, 133, '_joes_partners_8_partner_name', 'field_5a303f1df1543'),
(437, 134, 'hero_slides', ''),
(438, 134, '_hero_slides', 'field_5a303bf5e8f78'),
(439, 134, 'intro_section_title', 'Right at Home in  Jefferson and Oldham Counties'),
(440, 134, '_intro_section_title', 'field_5a303dc5aa8fe'),
(441, 134, 'intro_section_text', 'Ipsum vitae sollicitudin interdum felis ipsum convallis lorem acscele risque leo dolor slim trebor lehcar mailliw.') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(442, 134, '_intro_section_text', 'field_5a303dd3aa8ff'),
(443, 134, 'intro_section_link_text', 'Learn more'),
(444, 134, '_intro_section_link_text', 'field_5a303de8aa900'),
(445, 134, 'intro_section_link', '25'),
(446, 134, '_intro_section_link', 'field_5a303e01aa901'),
(447, 134, 'about_section_title', 'Why Choose Joe Kroll to Build Your Home?'),
(448, 134, '_about_section_title', 'field_5a303ea8f153d'),
(449, 134, 'about_section_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit nulla facilisis dolor quis est suspen disse potenti phasellus et diam donec metus donec mi ante, vestibulum ut ornare non risque leo dolor slim trebor lehcar mailliw.'),
(450, 134, '_about_section_text', 'field_5a303eb1f153e'),
(451, 134, 'about_section_link_text', 'Learn more about us'),
(452, 134, '_about_section_link_text', 'field_5a303ec0f153f'),
(453, 134, 'about_section_link', '25'),
(454, 134, '_about_section_link', 'field_5a303ecff1540'),
(455, 134, 'about_section_image', '132'),
(456, 134, '_about_section_image', 'field_5a303ee0f1541'),
(457, 134, 'joes_partners', '9'),
(458, 134, '_joes_partners', 'field_5a303efaf1542'),
(459, 134, 'joes_partners_link_text', 'SEE All of OUR TRUSTED PARTNERS'),
(460, 134, '_joes_partners_link_text', 'field_5a303f29f1544'),
(461, 134, 'joes_partners_link', '65'),
(462, 134, '_joes_partners_link', 'field_5a303f32f1545'),
(463, 134, 'how_it_works_title', ''),
(464, 134, '_how_it_works_title', 'field_5a303f6a8330b'),
(465, 134, 'how_it_works_text', ''),
(466, 134, '_how_it_works_text', 'field_5a303f768330c'),
(467, 134, 'how_it_works_steps', ''),
(468, 134, '_how_it_works_steps', 'field_5a303f818330d'),
(469, 134, 'how_it_works_link_text', ''),
(470, 134, '_how_it_works_link_text', 'field_5a303fce8e468'),
(471, 134, 'how_it_works_link', ''),
(472, 134, '_how_it_works_link', 'field_5a303fd78e469'),
(473, 134, 'joes_partners_0_partner_name', 'New century plumbing'),
(474, 134, '_joes_partners_0_partner_name', 'field_5a303f1df1543'),
(475, 134, 'joes_partners_1_partner_name', 'KME Electric'),
(476, 134, '_joes_partners_1_partner_name', 'field_5a303f1df1543'),
(477, 134, 'joes_partners_2_partner_name', 'Chapman Heating & Cooling'),
(478, 134, '_joes_partners_2_partner_name', 'field_5a303f1df1543'),
(479, 134, 'joes_partners_3_partner_name', 'Century Entertainment'),
(480, 134, '_joes_partners_3_partner_name', 'field_5a303f1df1543'),
(481, 134, 'joes_partners_4_partner_name', 'Premiere Flooring'),
(482, 134, '_joes_partners_4_partner_name', 'field_5a303f1df1543'),
(483, 134, 'joes_partners_5_partner_name', 'Willis-Klein'),
(484, 134, '_joes_partners_5_partner_name', 'field_5a303f1df1543'),
(485, 134, 'joes_partners_6_partner_name', 'PC Lumber'),
(486, 134, '_joes_partners_6_partner_name', 'field_5a303f1df1543'),
(487, 134, 'joes_partners_7_partner_name', 'Jennifer Bergin'),
(488, 134, '_joes_partners_7_partner_name', 'field_5a303f1df1543'),
(489, 134, 'joes_partners_8_partner_name', 'Cindy Druin'),
(490, 134, '_joes_partners_8_partner_name', 'field_5a303f1df1543'),
(491, 135, '_wp_attached_file', '2017/12/step-1.svg'),
(492, 136, '_wp_attached_file', '2017/12/step-5.svg'),
(493, 137, '_wp_attached_file', '2017/12/step-4.svg'),
(494, 138, '_wp_attached_file', '2017/12/step-3.svg'),
(495, 139, '_wp_attached_file', '2017/12/step-2.svg'),
(496, 4, 'how_it_works_steps_0_step_icon', '135'),
(497, 4, '_how_it_works_steps_0_step_icon', 'field_5a303fa08330e'),
(498, 4, 'how_it_works_steps_0_step_text', '1) Plan Your Budget'),
(499, 4, '_how_it_works_steps_0_step_text', 'field_5a303faf8330f'),
(500, 4, 'how_it_works_steps_1_step_icon', '139'),
(501, 4, '_how_it_works_steps_1_step_icon', 'field_5a303fa08330e'),
(502, 4, 'how_it_works_steps_1_step_text', '2) Choose Your Lot'),
(503, 4, '_how_it_works_steps_1_step_text', 'field_5a303faf8330f'),
(504, 4, 'how_it_works_steps_2_step_icon', '138'),
(505, 4, '_how_it_works_steps_2_step_icon', 'field_5a303fa08330e'),
(506, 4, 'how_it_works_steps_2_step_text', '3) Line Up Your Team'),
(507, 4, '_how_it_works_steps_2_step_text', 'field_5a303faf8330f'),
(508, 4, 'how_it_works_steps_3_step_icon', '137'),
(509, 4, '_how_it_works_steps_3_step_icon', 'field_5a303fa08330e'),
(510, 4, 'how_it_works_steps_3_step_text', '4) Pick A Plan'),
(511, 4, '_how_it_works_steps_3_step_text', 'field_5a303faf8330f'),
(512, 4, 'how_it_works_steps_4_step_icon', '136'),
(513, 4, '_how_it_works_steps_4_step_icon', 'field_5a303fa08330e'),
(514, 4, 'how_it_works_steps_4_step_text', '5) Negotiate A Contract'),
(515, 4, '_how_it_works_steps_4_step_text', 'field_5a303faf8330f'),
(516, 140, 'hero_slides', ''),
(517, 140, '_hero_slides', 'field_5a303bf5e8f78'),
(518, 140, 'intro_section_title', 'Right at Home in  Jefferson and Oldham Counties'),
(519, 140, '_intro_section_title', 'field_5a303dc5aa8fe'),
(520, 140, 'intro_section_text', 'Ipsum vitae sollicitudin interdum felis ipsum convallis lorem acscele risque leo dolor slim trebor lehcar mailliw.'),
(521, 140, '_intro_section_text', 'field_5a303dd3aa8ff'),
(522, 140, 'intro_section_link_text', 'Learn more'),
(523, 140, '_intro_section_link_text', 'field_5a303de8aa900'),
(524, 140, 'intro_section_link', '25'),
(525, 140, '_intro_section_link', 'field_5a303e01aa901'),
(526, 140, 'about_section_title', 'Why Choose Joe Kroll to Build Your Home?'),
(527, 140, '_about_section_title', 'field_5a303ea8f153d'),
(528, 140, 'about_section_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit nulla facilisis dolor quis est suspen disse potenti phasellus et diam donec metus donec mi ante, vestibulum ut ornare non risque leo dolor slim trebor lehcar mailliw.'),
(529, 140, '_about_section_text', 'field_5a303eb1f153e'),
(530, 140, 'about_section_link_text', 'Learn more about us'),
(531, 140, '_about_section_link_text', 'field_5a303ec0f153f'),
(532, 140, 'about_section_link', '25'),
(533, 140, '_about_section_link', 'field_5a303ecff1540'),
(534, 140, 'about_section_image', '132'),
(535, 140, '_about_section_image', 'field_5a303ee0f1541'),
(536, 140, 'joes_partners', '9'),
(537, 140, '_joes_partners', 'field_5a303efaf1542'),
(538, 140, 'joes_partners_link_text', 'SEE All of OUR TRUSTED PARTNERS'),
(539, 140, '_joes_partners_link_text', 'field_5a303f29f1544'),
(540, 140, 'joes_partners_link', '65'),
(541, 140, '_joes_partners_link', 'field_5a303f32f1545') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(542, 140, 'how_it_works_title', 'Here’s How It Works'),
(543, 140, '_how_it_works_title', 'field_5a303f6a8330b'),
(544, 140, 'how_it_works_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit nulla facilisis dolor quis est suspen disse potenti phasellus et diam donec ornare non risque leo dolor slim trebor lehcar mailliw.'),
(545, 140, '_how_it_works_text', 'field_5a303f768330c'),
(546, 140, 'how_it_works_steps', '5'),
(547, 140, '_how_it_works_steps', 'field_5a303f818330d'),
(548, 140, 'how_it_works_link_text', 'Learn more'),
(549, 140, '_how_it_works_link_text', 'field_5a303fce8e468'),
(550, 140, 'how_it_works_link', ''),
(551, 140, '_how_it_works_link', 'field_5a303fd78e469'),
(552, 140, 'joes_partners_0_partner_name', 'New century plumbing'),
(553, 140, '_joes_partners_0_partner_name', 'field_5a303f1df1543'),
(554, 140, 'joes_partners_1_partner_name', 'KME Electric'),
(555, 140, '_joes_partners_1_partner_name', 'field_5a303f1df1543'),
(556, 140, 'joes_partners_2_partner_name', 'Chapman Heating & Cooling'),
(557, 140, '_joes_partners_2_partner_name', 'field_5a303f1df1543'),
(558, 140, 'joes_partners_3_partner_name', 'Century Entertainment'),
(559, 140, '_joes_partners_3_partner_name', 'field_5a303f1df1543'),
(560, 140, 'joes_partners_4_partner_name', 'Premiere Flooring'),
(561, 140, '_joes_partners_4_partner_name', 'field_5a303f1df1543'),
(562, 140, 'joes_partners_5_partner_name', 'Willis-Klein'),
(563, 140, '_joes_partners_5_partner_name', 'field_5a303f1df1543'),
(564, 140, 'joes_partners_6_partner_name', 'PC Lumber'),
(565, 140, '_joes_partners_6_partner_name', 'field_5a303f1df1543'),
(566, 140, 'joes_partners_7_partner_name', 'Jennifer Bergin'),
(567, 140, '_joes_partners_7_partner_name', 'field_5a303f1df1543'),
(568, 140, 'joes_partners_8_partner_name', 'Cindy Druin'),
(569, 140, '_joes_partners_8_partner_name', 'field_5a303f1df1543'),
(570, 140, 'how_it_works_steps_0_step_icon', '135'),
(571, 140, '_how_it_works_steps_0_step_icon', 'field_5a303fa08330e'),
(572, 140, 'how_it_works_steps_0_step_text', '1) Plan Your Budget'),
(573, 140, '_how_it_works_steps_0_step_text', 'field_5a303faf8330f'),
(574, 140, 'how_it_works_steps_1_step_icon', '139'),
(575, 140, '_how_it_works_steps_1_step_icon', 'field_5a303fa08330e'),
(576, 140, 'how_it_works_steps_1_step_text', '2) Choose Your Lot'),
(577, 140, '_how_it_works_steps_1_step_text', 'field_5a303faf8330f'),
(578, 140, 'how_it_works_steps_2_step_icon', '138'),
(579, 140, '_how_it_works_steps_2_step_icon', 'field_5a303fa08330e'),
(580, 140, 'how_it_works_steps_2_step_text', '3) Line Up Your Team'),
(581, 140, '_how_it_works_steps_2_step_text', 'field_5a303faf8330f'),
(582, 140, 'how_it_works_steps_3_step_icon', '137'),
(583, 140, '_how_it_works_steps_3_step_icon', 'field_5a303fa08330e'),
(584, 140, 'how_it_works_steps_3_step_text', '4) Pick A Plan'),
(585, 140, '_how_it_works_steps_3_step_text', 'field_5a303faf8330f'),
(586, 140, 'how_it_works_steps_4_step_icon', '136'),
(587, 140, '_how_it_works_steps_4_step_icon', 'field_5a303fa08330e'),
(588, 140, 'how_it_works_steps_4_step_text', '5) Negotiate A Contract'),
(589, 140, '_how_it_works_steps_4_step_text', 'field_5a303faf8330f'),
(590, 141, '_edit_last', '1'),
(591, 141, '_edit_lock', '1513122145:1'),
(592, 4, 'hero_slides_0_hero_slide_image', '90'),
(593, 4, '_hero_slides_0_hero_slide_image', 'field_5a303c34e8f79'),
(594, 4, 'hero_slides_0_hero_slide_title', 'It’s so good to be home.'),
(595, 4, '_hero_slides_0_hero_slide_title', 'field_5a303c7fe8f7a'),
(596, 4, 'hero_slides_0_hero_slide_type', 'Private Residence'),
(597, 4, '_hero_slides_0_hero_slide_type', 'field_5a303c91e8f7b'),
(598, 4, 'hero_slides_0_hero_slide_location', 'Oldham County, Kentucky'),
(599, 4, '_hero_slides_0_hero_slide_location', 'field_5a303ca2e8f7c'),
(600, 4, 'hero_slides_0_hero_slide_link', '71'),
(601, 4, '_hero_slides_0_hero_slide_link', 'field_5a303cc3e8f7d'),
(602, 147, 'hero_slides', '1'),
(603, 147, '_hero_slides', 'field_5a303bf5e8f78'),
(604, 147, 'intro_section_title', 'Right at Home in  Jefferson and Oldham Counties'),
(605, 147, '_intro_section_title', 'field_5a303dc5aa8fe'),
(606, 147, 'intro_section_text', 'Ipsum vitae sollicitudin interdum felis ipsum convallis lorem acscele risque leo dolor slim trebor lehcar mailliw.'),
(607, 147, '_intro_section_text', 'field_5a303dd3aa8ff'),
(608, 147, 'intro_section_link_text', 'Learn more'),
(609, 147, '_intro_section_link_text', 'field_5a303de8aa900'),
(610, 147, 'intro_section_link', '25'),
(611, 147, '_intro_section_link', 'field_5a303e01aa901'),
(612, 147, 'about_section_title', 'Why Choose Joe Kroll to Build Your Home?'),
(613, 147, '_about_section_title', 'field_5a303ea8f153d'),
(614, 147, 'about_section_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit nulla facilisis dolor quis est suspen disse potenti phasellus et diam donec metus donec mi ante, vestibulum ut ornare non risque leo dolor slim trebor lehcar mailliw.'),
(615, 147, '_about_section_text', 'field_5a303eb1f153e'),
(616, 147, 'about_section_link_text', 'Learn more about us'),
(617, 147, '_about_section_link_text', 'field_5a303ec0f153f'),
(618, 147, 'about_section_link', '25'),
(619, 147, '_about_section_link', 'field_5a303ecff1540'),
(620, 147, 'about_section_image', '132'),
(621, 147, '_about_section_image', 'field_5a303ee0f1541'),
(622, 147, 'joes_partners', '9'),
(623, 147, '_joes_partners', 'field_5a303efaf1542'),
(624, 147, 'joes_partners_link_text', 'SEE All of OUR TRUSTED PARTNERS'),
(625, 147, '_joes_partners_link_text', 'field_5a303f29f1544'),
(626, 147, 'joes_partners_link', '65'),
(627, 147, '_joes_partners_link', 'field_5a303f32f1545'),
(628, 147, 'how_it_works_title', 'Here’s How It Works'),
(629, 147, '_how_it_works_title', 'field_5a303f6a8330b'),
(630, 147, 'how_it_works_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit nulla facilisis dolor quis est suspen disse potenti phasellus et diam donec ornare non risque leo dolor slim trebor lehcar mailliw.'),
(631, 147, '_how_it_works_text', 'field_5a303f768330c'),
(632, 147, 'how_it_works_steps', '5'),
(633, 147, '_how_it_works_steps', 'field_5a303f818330d'),
(634, 147, 'how_it_works_link_text', 'Learn more'),
(635, 147, '_how_it_works_link_text', 'field_5a303fce8e468'),
(636, 147, 'how_it_works_link', ''),
(637, 147, '_how_it_works_link', 'field_5a303fd78e469'),
(638, 147, 'joes_partners_0_partner_name', 'New century plumbing'),
(639, 147, '_joes_partners_0_partner_name', 'field_5a303f1df1543'),
(640, 147, 'joes_partners_1_partner_name', 'KME Electric'),
(641, 147, '_joes_partners_1_partner_name', 'field_5a303f1df1543') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(642, 147, 'joes_partners_2_partner_name', 'Chapman Heating & Cooling'),
(643, 147, '_joes_partners_2_partner_name', 'field_5a303f1df1543'),
(644, 147, 'joes_partners_3_partner_name', 'Century Entertainment'),
(645, 147, '_joes_partners_3_partner_name', 'field_5a303f1df1543'),
(646, 147, 'joes_partners_4_partner_name', 'Premiere Flooring'),
(647, 147, '_joes_partners_4_partner_name', 'field_5a303f1df1543'),
(648, 147, 'joes_partners_5_partner_name', 'Willis-Klein'),
(649, 147, '_joes_partners_5_partner_name', 'field_5a303f1df1543'),
(650, 147, 'joes_partners_6_partner_name', 'PC Lumber'),
(651, 147, '_joes_partners_6_partner_name', 'field_5a303f1df1543'),
(652, 147, 'joes_partners_7_partner_name', 'Jennifer Bergin'),
(653, 147, '_joes_partners_7_partner_name', 'field_5a303f1df1543'),
(654, 147, 'joes_partners_8_partner_name', 'Cindy Druin'),
(655, 147, '_joes_partners_8_partner_name', 'field_5a303f1df1543'),
(656, 147, 'how_it_works_steps_0_step_icon', '135'),
(657, 147, '_how_it_works_steps_0_step_icon', 'field_5a303fa08330e'),
(658, 147, 'how_it_works_steps_0_step_text', '1) Plan Your Budget'),
(659, 147, '_how_it_works_steps_0_step_text', 'field_5a303faf8330f'),
(660, 147, 'how_it_works_steps_1_step_icon', '139'),
(661, 147, '_how_it_works_steps_1_step_icon', 'field_5a303fa08330e'),
(662, 147, 'how_it_works_steps_1_step_text', '2) Choose Your Lot'),
(663, 147, '_how_it_works_steps_1_step_text', 'field_5a303faf8330f'),
(664, 147, 'how_it_works_steps_2_step_icon', '138'),
(665, 147, '_how_it_works_steps_2_step_icon', 'field_5a303fa08330e'),
(666, 147, 'how_it_works_steps_2_step_text', '3) Line Up Your Team'),
(667, 147, '_how_it_works_steps_2_step_text', 'field_5a303faf8330f'),
(668, 147, 'how_it_works_steps_3_step_icon', '137'),
(669, 147, '_how_it_works_steps_3_step_icon', 'field_5a303fa08330e'),
(670, 147, 'how_it_works_steps_3_step_text', '4) Pick A Plan'),
(671, 147, '_how_it_works_steps_3_step_text', 'field_5a303faf8330f'),
(672, 147, 'how_it_works_steps_4_step_icon', '136'),
(673, 147, '_how_it_works_steps_4_step_icon', 'field_5a303fa08330e'),
(674, 147, 'how_it_works_steps_4_step_text', '5) Negotiate A Contract'),
(675, 147, '_how_it_works_steps_4_step_text', 'field_5a303faf8330f'),
(676, 147, 'hero_slides_0_hero_slide_image', '90'),
(677, 147, '_hero_slides_0_hero_slide_image', 'field_5a303c34e8f79'),
(678, 147, 'hero_slides_0_hero_slide_title', 'It’s so good to be home.'),
(679, 147, '_hero_slides_0_hero_slide_title', 'field_5a303c7fe8f7a'),
(680, 147, 'hero_slides_0_hero_slide_type', 'Private Residence'),
(681, 147, '_hero_slides_0_hero_slide_type', 'field_5a303c91e8f7b'),
(682, 147, 'hero_slides_0_hero_slide_location', 'Oldham County, Kentucky'),
(683, 147, '_hero_slides_0_hero_slide_location', 'field_5a303ca2e8f7c'),
(684, 147, 'hero_slides_0_hero_slide_link', '71'),
(685, 147, '_hero_slides_0_hero_slide_link', 'field_5a303cc3e8f7d'),
(686, 148, '_wp_attached_file', '2017/12/keys.png'),
(687, 148, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:942;s:6:"height";i:628;s:4:"file";s:16:"2017/12/keys.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"keys-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:16:"keys-900x600.png";s:5:"width";i:900;s:6:"height";i:600;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:16:"keys-768x512.png";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(688, 149, '_edit_last', '1'),
(689, 149, '_edit_lock', '1513121933:1'),
(690, 65, 'trusted_partners_0_partner_image', ''),
(691, 65, '_trusted_partners_0_partner_image', 'field_5a3063e8afd2b'),
(692, 65, 'trusted_partners_0_partner_name', 'New Century Plumbing'),
(693, 65, '_trusted_partners_0_partner_name', 'field_5a306412afd2c'),
(694, 65, 'trusted_partners_0_partner_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'),
(695, 65, '_trusted_partners_0_partner_text', 'field_5a30642dafd2d'),
(696, 65, 'trusted_partners_0_partner_link', 'http://www.google.rs'),
(697, 65, '_trusted_partners_0_partner_link', 'field_5a306444afd2e'),
(698, 65, 'trusted_partners', '6'),
(699, 65, '_trusted_partners', 'field_5a3063c4afd2a'),
(700, 156, 'trusted_partners_0_partner_image', ''),
(701, 156, '_trusted_partners_0_partner_image', 'field_5a3063e8afd2b'),
(702, 156, 'trusted_partners_0_partner_name', 'New Century Plumbing'),
(703, 156, '_trusted_partners_0_partner_name', 'field_5a306412afd2c'),
(704, 156, 'trusted_partners_0_partner_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'),
(705, 156, '_trusted_partners_0_partner_text', 'field_5a30642dafd2d'),
(706, 156, 'trusted_partners_0_partner_link', 'http://www.google.rs'),
(707, 156, '_trusted_partners_0_partner_link', 'field_5a306444afd2e'),
(708, 156, 'trusted_partners', '1'),
(709, 156, '_trusted_partners', 'field_5a3063c4afd2a'),
(710, 65, 'trusted_partners_1_partner_image', ''),
(711, 65, '_trusted_partners_1_partner_image', 'field_5a3063e8afd2b'),
(712, 65, 'trusted_partners_1_partner_name', 'Century Entertainment'),
(713, 65, '_trusted_partners_1_partner_name', 'field_5a306412afd2c'),
(714, 65, 'trusted_partners_1_partner_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'),
(715, 65, '_trusted_partners_1_partner_text', 'field_5a30642dafd2d'),
(716, 65, 'trusted_partners_1_partner_link', ''),
(717, 65, '_trusted_partners_1_partner_link', 'field_5a306444afd2e'),
(718, 157, 'trusted_partners_0_partner_image', ''),
(719, 157, '_trusted_partners_0_partner_image', 'field_5a3063e8afd2b'),
(720, 157, 'trusted_partners_0_partner_name', 'New Century Plumbing'),
(721, 157, '_trusted_partners_0_partner_name', 'field_5a306412afd2c'),
(722, 157, 'trusted_partners_0_partner_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'),
(723, 157, '_trusted_partners_0_partner_text', 'field_5a30642dafd2d'),
(724, 157, 'trusted_partners_0_partner_link', 'http://www.google.rs'),
(725, 157, '_trusted_partners_0_partner_link', 'field_5a306444afd2e'),
(726, 157, 'trusted_partners', '2'),
(727, 157, '_trusted_partners', 'field_5a3063c4afd2a'),
(728, 157, 'trusted_partners_1_partner_image', ''),
(729, 157, '_trusted_partners_1_partner_image', 'field_5a3063e8afd2b'),
(730, 157, 'trusted_partners_1_partner_name', 'Century Entertainment'),
(731, 157, '_trusted_partners_1_partner_name', 'field_5a306412afd2c'),
(732, 157, 'trusted_partners_1_partner_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'),
(733, 157, '_trusted_partners_1_partner_text', 'field_5a30642dafd2d'),
(734, 157, 'trusted_partners_1_partner_link', ''),
(735, 157, '_trusted_partners_1_partner_link', 'field_5a306444afd2e'),
(736, 65, 'trusted_partners_2_partner_image', ''),
(737, 65, '_trusted_partners_2_partner_image', 'field_5a3063e8afd2b'),
(738, 65, 'trusted_partners_2_partner_name', 'PC Lumber'),
(739, 65, '_trusted_partners_2_partner_name', 'field_5a306412afd2c'),
(740, 65, 'trusted_partners_2_partner_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'),
(741, 65, '_trusted_partners_2_partner_text', 'field_5a30642dafd2d') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(742, 65, 'trusted_partners_2_partner_link', ''),
(743, 65, '_trusted_partners_2_partner_link', 'field_5a306444afd2e'),
(744, 65, 'trusted_partners_3_partner_image', ''),
(745, 65, '_trusted_partners_3_partner_image', 'field_5a3063e8afd2b'),
(746, 65, 'trusted_partners_3_partner_name', 'KME Electric'),
(747, 65, '_trusted_partners_3_partner_name', 'field_5a306412afd2c'),
(748, 65, 'trusted_partners_3_partner_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'),
(749, 65, '_trusted_partners_3_partner_text', 'field_5a30642dafd2d'),
(750, 65, 'trusted_partners_3_partner_link', ''),
(751, 65, '_trusted_partners_3_partner_link', 'field_5a306444afd2e'),
(752, 65, 'trusted_partners_4_partner_image', ''),
(753, 65, '_trusted_partners_4_partner_image', 'field_5a3063e8afd2b'),
(754, 65, 'trusted_partners_4_partner_name', 'Premiere Flooring'),
(755, 65, '_trusted_partners_4_partner_name', 'field_5a306412afd2c'),
(756, 65, 'trusted_partners_4_partner_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'),
(757, 65, '_trusted_partners_4_partner_text', 'field_5a30642dafd2d'),
(758, 65, 'trusted_partners_4_partner_link', ''),
(759, 65, '_trusted_partners_4_partner_link', 'field_5a306444afd2e'),
(760, 65, 'trusted_partners_5_partner_image', ''),
(761, 65, '_trusted_partners_5_partner_image', 'field_5a3063e8afd2b'),
(762, 65, 'trusted_partners_5_partner_name', 'Jennifer Bergin'),
(763, 65, '_trusted_partners_5_partner_name', 'field_5a306412afd2c'),
(764, 65, 'trusted_partners_5_partner_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'),
(765, 65, '_trusted_partners_5_partner_text', 'field_5a30642dafd2d'),
(766, 65, 'trusted_partners_5_partner_link', ''),
(767, 65, '_trusted_partners_5_partner_link', 'field_5a306444afd2e'),
(768, 158, 'trusted_partners_0_partner_image', ''),
(769, 158, '_trusted_partners_0_partner_image', 'field_5a3063e8afd2b'),
(770, 158, 'trusted_partners_0_partner_name', 'New Century Plumbing'),
(771, 158, '_trusted_partners_0_partner_name', 'field_5a306412afd2c'),
(772, 158, 'trusted_partners_0_partner_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'),
(773, 158, '_trusted_partners_0_partner_text', 'field_5a30642dafd2d'),
(774, 158, 'trusted_partners_0_partner_link', 'http://www.google.rs'),
(775, 158, '_trusted_partners_0_partner_link', 'field_5a306444afd2e'),
(776, 158, 'trusted_partners', '6'),
(777, 158, '_trusted_partners', 'field_5a3063c4afd2a'),
(778, 158, 'trusted_partners_1_partner_image', ''),
(779, 158, '_trusted_partners_1_partner_image', 'field_5a3063e8afd2b'),
(780, 158, 'trusted_partners_1_partner_name', 'Century Entertainment'),
(781, 158, '_trusted_partners_1_partner_name', 'field_5a306412afd2c'),
(782, 158, 'trusted_partners_1_partner_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'),
(783, 158, '_trusted_partners_1_partner_text', 'field_5a30642dafd2d'),
(784, 158, 'trusted_partners_1_partner_link', ''),
(785, 158, '_trusted_partners_1_partner_link', 'field_5a306444afd2e'),
(786, 158, 'trusted_partners_2_partner_image', ''),
(787, 158, '_trusted_partners_2_partner_image', 'field_5a3063e8afd2b'),
(788, 158, 'trusted_partners_2_partner_name', 'PC Lumber'),
(789, 158, '_trusted_partners_2_partner_name', 'field_5a306412afd2c'),
(790, 158, 'trusted_partners_2_partner_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'),
(791, 158, '_trusted_partners_2_partner_text', 'field_5a30642dafd2d'),
(792, 158, 'trusted_partners_2_partner_link', ''),
(793, 158, '_trusted_partners_2_partner_link', 'field_5a306444afd2e'),
(794, 158, 'trusted_partners_3_partner_image', ''),
(795, 158, '_trusted_partners_3_partner_image', 'field_5a3063e8afd2b'),
(796, 158, 'trusted_partners_3_partner_name', 'KME Electric'),
(797, 158, '_trusted_partners_3_partner_name', 'field_5a306412afd2c'),
(798, 158, 'trusted_partners_3_partner_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'),
(799, 158, '_trusted_partners_3_partner_text', 'field_5a30642dafd2d'),
(800, 158, 'trusted_partners_3_partner_link', ''),
(801, 158, '_trusted_partners_3_partner_link', 'field_5a306444afd2e'),
(802, 158, 'trusted_partners_4_partner_image', ''),
(803, 158, '_trusted_partners_4_partner_image', 'field_5a3063e8afd2b'),
(804, 158, 'trusted_partners_4_partner_name', 'Premiere Flooring'),
(805, 158, '_trusted_partners_4_partner_name', 'field_5a306412afd2c'),
(806, 158, 'trusted_partners_4_partner_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'),
(807, 158, '_trusted_partners_4_partner_text', 'field_5a30642dafd2d'),
(808, 158, 'trusted_partners_4_partner_link', ''),
(809, 158, '_trusted_partners_4_partner_link', 'field_5a306444afd2e'),
(810, 158, 'trusted_partners_5_partner_image', ''),
(811, 158, '_trusted_partners_5_partner_image', 'field_5a3063e8afd2b'),
(812, 158, 'trusted_partners_5_partner_name', 'Jennifer Bergin'),
(813, 158, '_trusted_partners_5_partner_name', 'field_5a306412afd2c'),
(814, 158, 'trusted_partners_5_partner_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'),
(815, 158, '_trusted_partners_5_partner_text', 'field_5a30642dafd2d'),
(816, 158, 'trusted_partners_5_partner_link', ''),
(817, 158, '_trusted_partners_5_partner_link', 'field_5a306444afd2e'),
(818, 159, '_edit_last', '1'),
(819, 159, '_edit_lock', '1513123326:1'),
(820, 165, '_wp_attached_file', '2017/12/bitmap.jpg'),
(821, 165, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2640;s:6:"height";i:662;s:4:"file";s:18:"2017/12/bitmap.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"bitmap-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"bitmap-900x226.jpg";s:5:"width";i:900;s:6:"height";i:226;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:18:"bitmap-768x193.jpg";s:5:"width";i:768;s:6:"height";i:193;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:19:"bitmap-2048x514.jpg";s:5:"width";i:2048;s:6:"height";i:514;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:19:"bitmap-2048x514.jpg";s:5:"width";i:2048;s:6:"height";i:514;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(822, 65, 'header_image', '86'),
(823, 65, '_header_image', 'field_5a3067bc4990b'),
(824, 166, 'trusted_partners_0_partner_image', ''),
(825, 166, '_trusted_partners_0_partner_image', 'field_5a3063e8afd2b'),
(826, 166, 'trusted_partners_0_partner_name', 'New Century Plumbing'),
(827, 166, '_trusted_partners_0_partner_name', 'field_5a306412afd2c'),
(828, 166, 'trusted_partners_0_partner_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'),
(829, 166, '_trusted_partners_0_partner_text', 'field_5a30642dafd2d'),
(830, 166, 'trusted_partners_0_partner_link', 'http://www.google.rs'),
(831, 166, '_trusted_partners_0_partner_link', 'field_5a306444afd2e'),
(832, 166, 'trusted_partners', '6'),
(833, 166, '_trusted_partners', 'field_5a3063c4afd2a'),
(834, 166, 'trusted_partners_1_partner_image', ''),
(835, 166, '_trusted_partners_1_partner_image', 'field_5a3063e8afd2b'),
(836, 166, 'trusted_partners_1_partner_name', 'Century Entertainment'),
(837, 166, '_trusted_partners_1_partner_name', 'field_5a306412afd2c'),
(838, 166, 'trusted_partners_1_partner_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'),
(839, 166, '_trusted_partners_1_partner_text', 'field_5a30642dafd2d'),
(840, 166, 'trusted_partners_1_partner_link', ''),
(841, 166, '_trusted_partners_1_partner_link', 'field_5a306444afd2e') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(842, 166, 'trusted_partners_2_partner_image', ''),
(843, 166, '_trusted_partners_2_partner_image', 'field_5a3063e8afd2b'),
(844, 166, 'trusted_partners_2_partner_name', 'PC Lumber'),
(845, 166, '_trusted_partners_2_partner_name', 'field_5a306412afd2c'),
(846, 166, 'trusted_partners_2_partner_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'),
(847, 166, '_trusted_partners_2_partner_text', 'field_5a30642dafd2d'),
(848, 166, 'trusted_partners_2_partner_link', ''),
(849, 166, '_trusted_partners_2_partner_link', 'field_5a306444afd2e'),
(850, 166, 'trusted_partners_3_partner_image', ''),
(851, 166, '_trusted_partners_3_partner_image', 'field_5a3063e8afd2b'),
(852, 166, 'trusted_partners_3_partner_name', 'KME Electric'),
(853, 166, '_trusted_partners_3_partner_name', 'field_5a306412afd2c'),
(854, 166, 'trusted_partners_3_partner_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'),
(855, 166, '_trusted_partners_3_partner_text', 'field_5a30642dafd2d'),
(856, 166, 'trusted_partners_3_partner_link', ''),
(857, 166, '_trusted_partners_3_partner_link', 'field_5a306444afd2e'),
(858, 166, 'trusted_partners_4_partner_image', ''),
(859, 166, '_trusted_partners_4_partner_image', 'field_5a3063e8afd2b'),
(860, 166, 'trusted_partners_4_partner_name', 'Premiere Flooring'),
(861, 166, '_trusted_partners_4_partner_name', 'field_5a306412afd2c'),
(862, 166, 'trusted_partners_4_partner_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'),
(863, 166, '_trusted_partners_4_partner_text', 'field_5a30642dafd2d'),
(864, 166, 'trusted_partners_4_partner_link', ''),
(865, 166, '_trusted_partners_4_partner_link', 'field_5a306444afd2e'),
(866, 166, 'trusted_partners_5_partner_image', ''),
(867, 166, '_trusted_partners_5_partner_image', 'field_5a3063e8afd2b'),
(868, 166, 'trusted_partners_5_partner_name', 'Jennifer Bergin'),
(869, 166, '_trusted_partners_5_partner_name', 'field_5a306412afd2c'),
(870, 166, 'trusted_partners_5_partner_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.'),
(871, 166, '_trusted_partners_5_partner_text', 'field_5a30642dafd2d'),
(872, 166, 'trusted_partners_5_partner_link', ''),
(873, 166, '_trusted_partners_5_partner_link', 'field_5a306444afd2e'),
(874, 166, 'header_image', '86'),
(875, 166, '_header_image', 'field_5a3067bc4990b'),
(876, 25, 'header_image', ''),
(877, 25, '_header_image', 'field_5a3067bc4990b'),
(878, 25, 'footer_cta_image', '13'),
(879, 25, '_footer_cta_image', 'field_5a3069c095b74'),
(880, 25, 'footer_cta_text', 'Sample About us text FOOTER CTA'),
(881, 25, '_footer_cta_text', 'field_5a3069c695b76'),
(882, 25, 'footer_cta_link_text', 'See more'),
(883, 25, '_footer_cta_link_text', 'field_5a3069c395b75'),
(884, 25, 'footer_cta_link', 'http://localhost/joekrollbuilder.com'),
(885, 25, '_footer_cta_link', 'field_5a3069c995b77'),
(886, 64, 'header_image', ''),
(887, 64, '_header_image', 'field_5a3067bc4990b'),
(888, 64, 'footer_cta_image', ''),
(889, 64, '_footer_cta_image', 'field_5a3069c095b74'),
(890, 64, 'footer_cta_text', ''),
(891, 64, '_footer_cta_text', 'field_5a3069c695b76'),
(892, 64, 'footer_cta_link_text', ''),
(893, 64, '_footer_cta_link_text', 'field_5a3069c395b75'),
(894, 64, 'footer_cta_link', ''),
(895, 64, '_footer_cta_link', 'field_5a3069c995b77'),
(896, 172, 'header_image', ''),
(897, 172, '_header_image', 'field_5a3067bc4990b'),
(898, 172, 'footer_cta_image', ''),
(899, 172, '_footer_cta_image', 'field_5a3069c095b74'),
(900, 172, 'footer_cta_text', ''),
(901, 172, '_footer_cta_text', 'field_5a3069c695b76'),
(902, 172, 'footer_cta_link_text', ''),
(903, 172, '_footer_cta_link_text', 'field_5a3069c395b75'),
(904, 172, 'footer_cta_link', ''),
(905, 172, '_footer_cta_link', 'field_5a3069c995b77'),
(906, 173, 'header_image', ''),
(907, 173, '_header_image', 'field_5a3067bc4990b'),
(908, 173, 'footer_cta_image', '13'),
(909, 173, '_footer_cta_image', 'field_5a3069c095b74'),
(910, 173, 'footer_cta_text', 'Sample About us text FOOTER CTA'),
(911, 173, '_footer_cta_text', 'field_5a3069c695b76'),
(912, 173, 'footer_cta_link_text', 'See more'),
(913, 173, '_footer_cta_link_text', 'field_5a3069c395b75'),
(914, 173, 'footer_cta_link', 'http://localhost/joekrollbuilder.com'),
(915, 173, '_footer_cta_link', 'field_5a3069c995b77'),
(916, 174, '_edit_last', '1'),
(917, 174, '_edit_lock', '1513124143:1'),
(918, 27, 'home_building_process_steps_0_step_icon', '135'),
(919, 27, '_home_building_process_steps_0_step_icon', 'field_5a306e19a4346'),
(920, 27, 'home_building_process_steps_0_step_title', 'Plan Your Budget'),
(921, 27, '_home_building_process_steps_0_step_title', 'field_5a306e23a4347'),
(922, 27, 'home_building_process_steps_0_step_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.'),
(923, 27, '_home_building_process_steps_0_step_text', 'field_5a306e29a4348'),
(924, 27, 'home_building_process_steps_1_step_icon', '139'),
(925, 27, '_home_building_process_steps_1_step_icon', 'field_5a306e19a4346'),
(926, 27, 'home_building_process_steps_1_step_title', 'Choose your lot'),
(927, 27, '_home_building_process_steps_1_step_title', 'field_5a306e23a4347'),
(928, 27, 'home_building_process_steps_1_step_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.'),
(929, 27, '_home_building_process_steps_1_step_text', 'field_5a306e29a4348'),
(930, 27, 'home_building_process_steps_2_step_icon', '138'),
(931, 27, '_home_building_process_steps_2_step_icon', 'field_5a306e19a4346'),
(932, 27, 'home_building_process_steps_2_step_title', 'Line up your team'),
(933, 27, '_home_building_process_steps_2_step_title', 'field_5a306e23a4347'),
(934, 27, 'home_building_process_steps_2_step_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.'),
(935, 27, '_home_building_process_steps_2_step_text', 'field_5a306e29a4348'),
(936, 27, 'home_building_process_steps', '5'),
(937, 27, '_home_building_process_steps', 'field_5a306e09a4345'),
(938, 27, 'header_image', ''),
(939, 27, '_header_image', 'field_5a3067bc4990b'),
(940, 27, 'footer_cta_image', ''),
(941, 27, '_footer_cta_image', 'field_5a3069c095b74') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(942, 27, 'footer_cta_text', ''),
(943, 27, '_footer_cta_text', 'field_5a3069c695b76'),
(944, 27, 'footer_cta_link_text', ''),
(945, 27, '_footer_cta_link_text', 'field_5a3069c395b75'),
(946, 27, 'footer_cta_link', ''),
(947, 27, '_footer_cta_link', 'field_5a3069c995b77'),
(948, 180, 'home_building_process_steps_0_step_icon', '135'),
(949, 180, '_home_building_process_steps_0_step_icon', 'field_5a306e19a4346'),
(950, 180, 'home_building_process_steps_0_step_title', '1. Plan Your Budget'),
(951, 180, '_home_building_process_steps_0_step_title', 'field_5a306e23a4347'),
(952, 180, 'home_building_process_steps_0_step_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.'),
(953, 180, '_home_building_process_steps_0_step_text', 'field_5a306e29a4348'),
(954, 180, 'home_building_process_steps_1_step_icon', '139'),
(955, 180, '_home_building_process_steps_1_step_icon', 'field_5a306e19a4346'),
(956, 180, 'home_building_process_steps_1_step_title', '2. Choose your lot'),
(957, 180, '_home_building_process_steps_1_step_title', 'field_5a306e23a4347'),
(958, 180, 'home_building_process_steps_1_step_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.'),
(959, 180, '_home_building_process_steps_1_step_text', 'field_5a306e29a4348'),
(960, 180, 'home_building_process_steps_2_step_icon', '138'),
(961, 180, '_home_building_process_steps_2_step_icon', 'field_5a306e19a4346'),
(962, 180, 'home_building_process_steps_2_step_title', '3. Line up your team'),
(963, 180, '_home_building_process_steps_2_step_title', 'field_5a306e23a4347'),
(964, 180, 'home_building_process_steps_2_step_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.'),
(965, 180, '_home_building_process_steps_2_step_text', 'field_5a306e29a4348'),
(966, 180, 'home_building_process_steps', '3'),
(967, 180, '_home_building_process_steps', 'field_5a306e09a4345'),
(968, 180, 'header_image', ''),
(969, 180, '_header_image', 'field_5a3067bc4990b'),
(970, 180, 'footer_cta_image', ''),
(971, 180, '_footer_cta_image', 'field_5a3069c095b74'),
(972, 180, 'footer_cta_text', ''),
(973, 180, '_footer_cta_text', 'field_5a3069c695b76'),
(974, 180, 'footer_cta_link_text', ''),
(975, 180, '_footer_cta_link_text', 'field_5a3069c395b75'),
(976, 180, 'footer_cta_link', ''),
(977, 180, '_footer_cta_link', 'field_5a3069c995b77'),
(978, 27, 'home_building_process_steps_3_step_icon', '137'),
(979, 27, '_home_building_process_steps_3_step_icon', 'field_5a306e19a4346'),
(980, 27, 'home_building_process_steps_3_step_title', 'Step'),
(981, 27, '_home_building_process_steps_3_step_title', 'field_5a306e23a4347'),
(982, 27, 'home_building_process_steps_3_step_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.'),
(983, 27, '_home_building_process_steps_3_step_text', 'field_5a306e29a4348'),
(984, 27, 'home_building_process_steps_4_step_icon', '136'),
(985, 27, '_home_building_process_steps_4_step_icon', 'field_5a306e19a4346'),
(986, 27, 'home_building_process_steps_4_step_title', 'Step'),
(987, 27, '_home_building_process_steps_4_step_title', 'field_5a306e23a4347'),
(988, 27, 'home_building_process_steps_4_step_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.'),
(989, 27, '_home_building_process_steps_4_step_text', 'field_5a306e29a4348'),
(990, 181, 'home_building_process_steps_0_step_icon', '135'),
(991, 181, '_home_building_process_steps_0_step_icon', 'field_5a306e19a4346'),
(992, 181, 'home_building_process_steps_0_step_title', '1. Plan Your Budget'),
(993, 181, '_home_building_process_steps_0_step_title', 'field_5a306e23a4347'),
(994, 181, 'home_building_process_steps_0_step_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.'),
(995, 181, '_home_building_process_steps_0_step_text', 'field_5a306e29a4348'),
(996, 181, 'home_building_process_steps_1_step_icon', '139'),
(997, 181, '_home_building_process_steps_1_step_icon', 'field_5a306e19a4346'),
(998, 181, 'home_building_process_steps_1_step_title', '2. Choose your lot'),
(999, 181, '_home_building_process_steps_1_step_title', 'field_5a306e23a4347'),
(1000, 181, 'home_building_process_steps_1_step_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.'),
(1001, 181, '_home_building_process_steps_1_step_text', 'field_5a306e29a4348'),
(1002, 181, 'home_building_process_steps_2_step_icon', '138'),
(1003, 181, '_home_building_process_steps_2_step_icon', 'field_5a306e19a4346'),
(1004, 181, 'home_building_process_steps_2_step_title', '3. Line up your team'),
(1005, 181, '_home_building_process_steps_2_step_title', 'field_5a306e23a4347'),
(1006, 181, 'home_building_process_steps_2_step_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.'),
(1007, 181, '_home_building_process_steps_2_step_text', 'field_5a306e29a4348'),
(1008, 181, 'home_building_process_steps', '5'),
(1009, 181, '_home_building_process_steps', 'field_5a306e09a4345'),
(1010, 181, 'header_image', ''),
(1011, 181, '_header_image', 'field_5a3067bc4990b'),
(1012, 181, 'footer_cta_image', ''),
(1013, 181, '_footer_cta_image', 'field_5a3069c095b74'),
(1014, 181, 'footer_cta_text', ''),
(1015, 181, '_footer_cta_text', 'field_5a3069c695b76'),
(1016, 181, 'footer_cta_link_text', ''),
(1017, 181, '_footer_cta_link_text', 'field_5a3069c395b75'),
(1018, 181, 'footer_cta_link', ''),
(1019, 181, '_footer_cta_link', 'field_5a3069c995b77'),
(1020, 181, 'home_building_process_steps_3_step_icon', '137'),
(1021, 181, '_home_building_process_steps_3_step_icon', 'field_5a306e19a4346'),
(1022, 181, 'home_building_process_steps_3_step_title', '4. Step'),
(1023, 181, '_home_building_process_steps_3_step_title', 'field_5a306e23a4347'),
(1024, 181, 'home_building_process_steps_3_step_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.'),
(1025, 181, '_home_building_process_steps_3_step_text', 'field_5a306e29a4348'),
(1026, 181, 'home_building_process_steps_4_step_icon', '136'),
(1027, 181, '_home_building_process_steps_4_step_icon', 'field_5a306e19a4346'),
(1028, 181, 'home_building_process_steps_4_step_title', '5. Step'),
(1029, 181, '_home_building_process_steps_4_step_title', 'field_5a306e23a4347'),
(1030, 181, 'home_building_process_steps_4_step_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.'),
(1031, 181, '_home_building_process_steps_4_step_text', 'field_5a306e29a4348'),
(1032, 182, '_edit_last', '1'),
(1033, 182, '_edit_lock', '1513128089:1'),
(1037, 184, '_edit_last', '1'),
(1038, 184, '_edit_lock', '1513239931:1'),
(1039, 71, '_edit_lock', '1513239843:1'),
(1040, 71, '_edit_last', '1'),
(1041, 71, 'block_content', '2'),
(1042, 71, '_block_content', 'field_5a3075171f7ee'),
(1043, 71, 'testimonial_text', 'Joe took the time to explain lobortis velit phasellus suscipit selim and class aptent taciti sociosqu litora torquent conubia nostra inceptos hymenaeos.'),
(1044, 71, '_testimonial_text', 'field_5a30756ba2524') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1045, 71, 'testimonial_author', 'Testimonial author'),
(1046, 71, '_testimonial_author', 'field_5a307576a2525'),
(1047, 71, 'testimonial_author_location', 'Location, Country'),
(1048, 71, '_testimonial_author_location', 'field_5a307585a2526'),
(1049, 71, 'second_block_content', ''),
(1050, 71, '_second_block_content', 'field_5a30759ba2528'),
(1051, 71, 'specs', '10'),
(1052, 71, '_specs', 'field_5a30760f216f7'),
(1053, 71, 'additional_details', 'Fusce placerat dignissim lacus. Suspendisse cursus nunc ut ante. Phasellus pulvinar viverra nunc. Ut convallis dui et augue. Sed felis neque viverra in eleifend ac pharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae. Fusce varius risus dapibus dolor. Donec tristique faucibus velit aliquam erat volutpat integer sed felis. Quisque odio lacus tincidunt fringilla iaculis vitae dictum a quam cras consectetuer interdum odio pellentesque ideros nulla atenim. '),
(1054, 71, '_additional_details', 'field_5a3075e4216f6'),
(1055, 71, '_yoast_wpseo_primary_portfolio-category', ''),
(1056, 71, '_yoast_wpseo_content_score', '60'),
(1057, 71, 'block_content_0_block_image', '95'),
(1058, 71, '_block_content_0_block_image', 'field_5a3075291f7ef'),
(1059, 71, 'block_content_0_block_text', 'This is description of this image'),
(1060, 71, '_block_content_0_block_text', 'field_5a30753b1f7f0'),
(1061, 71, 'block_content_1_block_image', '74'),
(1062, 71, '_block_content_1_block_image', 'field_5a3075291f7ef'),
(1063, 71, 'block_content_1_block_text', 'This is description of this image 2'),
(1064, 71, '_block_content_1_block_text', 'field_5a30753b1f7f0'),
(1065, 71, 'specs_0_spec_name', 'Accumsan'),
(1066, 71, '_specs_0_spec_name', 'field_5a307622216f8'),
(1067, 71, 'specs_1_spec_name', 'Sed Sapien '),
(1068, 71, '_specs_1_spec_name', 'field_5a307622216f8'),
(1069, 71, 'specs_2_spec_name', 'Suspendisse '),
(1070, 71, '_specs_2_spec_name', 'field_5a307622216f8'),
(1071, 71, 'specs_3_spec_name', 'Potenti '),
(1072, 71, '_specs_3_spec_name', 'field_5a307622216f8'),
(1073, 71, 'specs_4_spec_name', 'Trebor'),
(1074, 71, '_specs_4_spec_name', 'field_5a307622216f8'),
(1075, 71, 'specs_5_spec_name', 'Sed Luctus '),
(1076, 71, '_specs_5_spec_name', 'field_5a307622216f8'),
(1077, 71, 'specs_6_spec_name', 'Dolor '),
(1078, 71, '_specs_6_spec_name', 'field_5a307622216f8'),
(1079, 71, 'specs_7_spec_name', 'Aliquet '),
(1080, 71, '_specs_7_spec_name', 'field_5a307622216f8'),
(1081, 71, 'specs_8_spec_name', 'Quam '),
(1082, 71, '_specs_8_spec_name', 'field_5a307622216f8'),
(1083, 71, 'specs_9_spec_name', 'Proin'),
(1084, 71, '_specs_9_spec_name', 'field_5a307622216f8'),
(1085, 4, 'hero_slides_1_hero_slide_image', '77'),
(1086, 4, '_hero_slides_1_hero_slide_image', 'field_5a303c34e8f79'),
(1087, 4, 'hero_slides_1_hero_slide_title', 'Second slide project'),
(1088, 4, '_hero_slides_1_hero_slide_title', 'field_5a303c7fe8f7a'),
(1089, 4, 'hero_slides_1_hero_slide_type', 'Business venue'),
(1090, 4, '_hero_slides_1_hero_slide_type', 'field_5a303c91e8f7b'),
(1091, 4, 'hero_slides_1_hero_slide_location', 'Louisville, USA'),
(1092, 4, '_hero_slides_1_hero_slide_location', 'field_5a303ca2e8f7c'),
(1093, 4, 'hero_slides_1_hero_slide_link', '15'),
(1094, 4, '_hero_slides_1_hero_slide_link', 'field_5a303cc3e8f7d'),
(1095, 203, 'hero_slides', '2'),
(1096, 203, '_hero_slides', 'field_5a303bf5e8f78'),
(1097, 203, 'intro_section_title', 'Right at Home in  Jefferson and Oldham Counties'),
(1098, 203, '_intro_section_title', 'field_5a303dc5aa8fe'),
(1099, 203, 'intro_section_text', 'Ipsum vitae sollicitudin interdum felis ipsum convallis lorem acscele risque leo dolor slim trebor lehcar mailliw.'),
(1100, 203, '_intro_section_text', 'field_5a303dd3aa8ff'),
(1101, 203, 'intro_section_link_text', 'Learn more'),
(1102, 203, '_intro_section_link_text', 'field_5a303de8aa900'),
(1103, 203, 'intro_section_link', '25'),
(1104, 203, '_intro_section_link', 'field_5a303e01aa901'),
(1105, 203, 'about_section_title', 'Why Choose Joe Kroll to Build Your Home?'),
(1106, 203, '_about_section_title', 'field_5a303ea8f153d'),
(1107, 203, 'about_section_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit nulla facilisis dolor quis est suspen disse potenti phasellus et diam donec metus donec mi ante, vestibulum ut ornare non risque leo dolor slim trebor lehcar mailliw.'),
(1108, 203, '_about_section_text', 'field_5a303eb1f153e'),
(1109, 203, 'about_section_link_text', 'Learn more about us'),
(1110, 203, '_about_section_link_text', 'field_5a303ec0f153f'),
(1111, 203, 'about_section_link', '25'),
(1112, 203, '_about_section_link', 'field_5a303ecff1540'),
(1113, 203, 'about_section_image', '132'),
(1114, 203, '_about_section_image', 'field_5a303ee0f1541'),
(1115, 203, 'joes_partners', '9'),
(1116, 203, '_joes_partners', 'field_5a303efaf1542'),
(1117, 203, 'joes_partners_link_text', 'SEE All of OUR TRUSTED PARTNERS'),
(1118, 203, '_joes_partners_link_text', 'field_5a303f29f1544'),
(1119, 203, 'joes_partners_link', '65'),
(1120, 203, '_joes_partners_link', 'field_5a303f32f1545'),
(1121, 203, 'how_it_works_title', 'Here’s How It Works'),
(1122, 203, '_how_it_works_title', 'field_5a303f6a8330b'),
(1123, 203, 'how_it_works_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit nulla facilisis dolor quis est suspen disse potenti phasellus et diam donec ornare non risque leo dolor slim trebor lehcar mailliw.'),
(1124, 203, '_how_it_works_text', 'field_5a303f768330c'),
(1125, 203, 'how_it_works_steps', '5'),
(1126, 203, '_how_it_works_steps', 'field_5a303f818330d'),
(1127, 203, 'how_it_works_link_text', 'Learn more'),
(1128, 203, '_how_it_works_link_text', 'field_5a303fce8e468'),
(1129, 203, 'how_it_works_link', ''),
(1130, 203, '_how_it_works_link', 'field_5a303fd78e469'),
(1131, 203, 'joes_partners_0_partner_name', 'New century plumbing'),
(1132, 203, '_joes_partners_0_partner_name', 'field_5a303f1df1543'),
(1133, 203, 'joes_partners_1_partner_name', 'KME Electric'),
(1134, 203, '_joes_partners_1_partner_name', 'field_5a303f1df1543'),
(1135, 203, 'joes_partners_2_partner_name', 'Chapman Heating & Cooling'),
(1136, 203, '_joes_partners_2_partner_name', 'field_5a303f1df1543'),
(1137, 203, 'joes_partners_3_partner_name', 'Century Entertainment'),
(1138, 203, '_joes_partners_3_partner_name', 'field_5a303f1df1543'),
(1139, 203, 'joes_partners_4_partner_name', 'Premiere Flooring'),
(1140, 203, '_joes_partners_4_partner_name', 'field_5a303f1df1543'),
(1141, 203, 'joes_partners_5_partner_name', 'Willis-Klein'),
(1142, 203, '_joes_partners_5_partner_name', 'field_5a303f1df1543'),
(1143, 203, 'joes_partners_6_partner_name', 'PC Lumber'),
(1144, 203, '_joes_partners_6_partner_name', 'field_5a303f1df1543') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1145, 203, 'joes_partners_7_partner_name', 'Jennifer Bergin'),
(1146, 203, '_joes_partners_7_partner_name', 'field_5a303f1df1543'),
(1147, 203, 'joes_partners_8_partner_name', 'Cindy Druin'),
(1148, 203, '_joes_partners_8_partner_name', 'field_5a303f1df1543'),
(1149, 203, 'how_it_works_steps_0_step_icon', '135'),
(1150, 203, '_how_it_works_steps_0_step_icon', 'field_5a303fa08330e'),
(1151, 203, 'how_it_works_steps_0_step_text', '1) Plan Your Budget'),
(1152, 203, '_how_it_works_steps_0_step_text', 'field_5a303faf8330f'),
(1153, 203, 'how_it_works_steps_1_step_icon', '139'),
(1154, 203, '_how_it_works_steps_1_step_icon', 'field_5a303fa08330e'),
(1155, 203, 'how_it_works_steps_1_step_text', '2) Choose Your Lot'),
(1156, 203, '_how_it_works_steps_1_step_text', 'field_5a303faf8330f'),
(1157, 203, 'how_it_works_steps_2_step_icon', '138'),
(1158, 203, '_how_it_works_steps_2_step_icon', 'field_5a303fa08330e'),
(1159, 203, 'how_it_works_steps_2_step_text', '3) Line Up Your Team'),
(1160, 203, '_how_it_works_steps_2_step_text', 'field_5a303faf8330f'),
(1161, 203, 'how_it_works_steps_3_step_icon', '137'),
(1162, 203, '_how_it_works_steps_3_step_icon', 'field_5a303fa08330e'),
(1163, 203, 'how_it_works_steps_3_step_text', '4) Pick A Plan'),
(1164, 203, '_how_it_works_steps_3_step_text', 'field_5a303faf8330f'),
(1165, 203, 'how_it_works_steps_4_step_icon', '136'),
(1166, 203, '_how_it_works_steps_4_step_icon', 'field_5a303fa08330e'),
(1167, 203, 'how_it_works_steps_4_step_text', '5) Negotiate A Contract'),
(1168, 203, '_how_it_works_steps_4_step_text', 'field_5a303faf8330f'),
(1169, 203, 'hero_slides_0_hero_slide_image', '90'),
(1170, 203, '_hero_slides_0_hero_slide_image', 'field_5a303c34e8f79'),
(1171, 203, 'hero_slides_0_hero_slide_title', 'It’s so good to be home.'),
(1172, 203, '_hero_slides_0_hero_slide_title', 'field_5a303c7fe8f7a'),
(1173, 203, 'hero_slides_0_hero_slide_type', 'Private Residence'),
(1174, 203, '_hero_slides_0_hero_slide_type', 'field_5a303c91e8f7b'),
(1175, 203, 'hero_slides_0_hero_slide_location', 'Oldham County, Kentucky'),
(1176, 203, '_hero_slides_0_hero_slide_location', 'field_5a303ca2e8f7c'),
(1177, 203, 'hero_slides_0_hero_slide_link', '71'),
(1178, 203, '_hero_slides_0_hero_slide_link', 'field_5a303cc3e8f7d'),
(1179, 203, 'hero_slides_1_hero_slide_image', '77'),
(1180, 203, '_hero_slides_1_hero_slide_image', 'field_5a303c34e8f79'),
(1181, 203, 'hero_slides_1_hero_slide_title', 'Second slide project'),
(1182, 203, '_hero_slides_1_hero_slide_title', 'field_5a303c7fe8f7a'),
(1183, 203, 'hero_slides_1_hero_slide_type', 'Business venue'),
(1184, 203, '_hero_slides_1_hero_slide_type', 'field_5a303c91e8f7b'),
(1185, 203, 'hero_slides_1_hero_slide_location', 'Louisville, USA'),
(1186, 203, '_hero_slides_1_hero_slide_location', 'field_5a303ca2e8f7c'),
(1187, 203, 'hero_slides_1_hero_slide_link', '15'),
(1188, 203, '_hero_slides_1_hero_slide_link', 'field_5a303cc3e8f7d'),
(1189, 205, 'home_building_process_steps_0_step_icon', '135'),
(1190, 205, '_home_building_process_steps_0_step_icon', 'field_5a306e19a4346'),
(1191, 205, 'home_building_process_steps_0_step_title', 'Plan Your Budget'),
(1192, 205, '_home_building_process_steps_0_step_title', 'field_5a306e23a4347'),
(1193, 205, 'home_building_process_steps_0_step_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.'),
(1194, 205, '_home_building_process_steps_0_step_text', 'field_5a306e29a4348'),
(1195, 205, 'home_building_process_steps_1_step_icon', '139'),
(1196, 205, '_home_building_process_steps_1_step_icon', 'field_5a306e19a4346'),
(1197, 205, 'home_building_process_steps_1_step_title', 'Choose your lot'),
(1198, 205, '_home_building_process_steps_1_step_title', 'field_5a306e23a4347'),
(1199, 205, 'home_building_process_steps_1_step_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.'),
(1200, 205, '_home_building_process_steps_1_step_text', 'field_5a306e29a4348'),
(1201, 205, 'home_building_process_steps_2_step_icon', '138'),
(1202, 205, '_home_building_process_steps_2_step_icon', 'field_5a306e19a4346'),
(1203, 205, 'home_building_process_steps_2_step_title', 'Line up your team'),
(1204, 205, '_home_building_process_steps_2_step_title', 'field_5a306e23a4347'),
(1205, 205, 'home_building_process_steps_2_step_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.'),
(1206, 205, '_home_building_process_steps_2_step_text', 'field_5a306e29a4348'),
(1207, 205, 'home_building_process_steps', '5'),
(1208, 205, '_home_building_process_steps', 'field_5a306e09a4345'),
(1209, 205, 'header_image', ''),
(1210, 205, '_header_image', 'field_5a3067bc4990b'),
(1211, 205, 'footer_cta_image', ''),
(1212, 205, '_footer_cta_image', 'field_5a3069c095b74'),
(1213, 205, 'footer_cta_text', ''),
(1214, 205, '_footer_cta_text', 'field_5a3069c695b76'),
(1215, 205, 'footer_cta_link_text', ''),
(1216, 205, '_footer_cta_link_text', 'field_5a3069c395b75'),
(1217, 205, 'footer_cta_link', ''),
(1218, 205, '_footer_cta_link', 'field_5a3069c995b77'),
(1219, 205, 'home_building_process_steps_3_step_icon', '137'),
(1220, 205, '_home_building_process_steps_3_step_icon', 'field_5a306e19a4346'),
(1221, 205, 'home_building_process_steps_3_step_title', 'Step'),
(1222, 205, '_home_building_process_steps_3_step_title', 'field_5a306e23a4347'),
(1223, 205, 'home_building_process_steps_3_step_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.'),
(1224, 205, '_home_building_process_steps_3_step_text', 'field_5a306e29a4348'),
(1225, 205, 'home_building_process_steps_4_step_icon', '136'),
(1226, 205, '_home_building_process_steps_4_step_icon', 'field_5a306e19a4346'),
(1227, 205, 'home_building_process_steps_4_step_title', 'Step'),
(1228, 205, '_home_building_process_steps_4_step_title', 'field_5a306e23a4347'),
(1229, 205, 'home_building_process_steps_4_step_text', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.'),
(1230, 205, '_home_building_process_steps_4_step_text', 'field_5a306e29a4348') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=206 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(4, 1, '2017-12-07 22:23:46', '2017-12-07 22:23:46', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home-page', '', '', '2017-12-14 03:18:51', '2017-12-14 08:18:51', '', 0, 'http://localhost/joekrollbuilder.com/?page_id=4', 0, 'page', '', 0),
(5, 1, '2017-12-07 22:23:47', '2017-12-07 22:23:47', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2017-12-07 22:23:47', '2017-12-07 22:23:47', '', 0, 'http://localhost/joekrollbuilder.com/?page_id=5', 10, 'page', '', 0),
(6, 1, '2017-12-07 22:23:49', '2017-12-07 22:23:49', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus selim at mattis condimentum, quam enim auctor nunc.', 'Contact Joe', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2017-12-12 15:20:31', '2017-12-12 20:20:31', '', 0, 'http://localhost/joekrollbuilder.com/?page_id=6', 20, 'page', '', 0),
(7, 1, '2017-12-07 22:23:49', '2017-12-07 22:23:49', 'Throughout this Online Privacy Policy, &quot;we&quot;, &quot;us&quot;, or &quot;our&quot; refers to Joe Kroll Builder, and Site refers to this website.\n\nWe are dedicated to protecting your privacy while you are using or accessing this Site. This Online Privacy Policy applies solely to the Site. Once you enter another web site, via a link provided on the Site or by other methods, we are no longer responsible for the privacy practices of the linked site. You should review the privacy statements of those web sites as posted on the individual web sites. We reserve the right to collect use and user statistics from the Site. Use and user statistics will be used to track information such as visitor interests, which may be used to enhance and improve the Site in the future; however, such use and user statistics do not include personally identifiable information. Generally, no personally identifiable information is tracked or collected on the generally accessible portions of the Site, unless you voluntarily provide such information to us via web forms or surveys on the Site. However, if you access certain portions of the Site by using a particular account authorized by us and/or a user name and password, certain information including your user name and password will be collected and identified with the information we have on file for that user name, and the information and materials you access and actions you take while logged on with that user name, will be tracked by us.\n\nWe do not sell or otherwise distribute names or other personally identifiable information to third parties for direct marketing, sales or any other purposes. Except as noted herein, any personally identifiable information received by us is used solely for internal purposes and is not shared with any nonaffiliated organizations unless required to do so by law, upon governmental request or in response to a court order.\n\nThe Site is not designed or intended to attract children under the age of 13. We do not collect any personally identifiable information, whether or not such information is voluntarily provided, from any person we actually know is under the age of 13. If a parent or guardian accesses the Site on behalf of a person under the age of 13, that parent or guardian is responsible for protecting that child’s personally identifiable information.\n\nFor questions, comments or assistance, please contact us.', 'Online Privacy Policy', '', 'publish', 'closed', 'closed', '', 'privacy-policy', '', '', '2017-12-07 22:23:49', '2017-12-07 22:23:49', '', 0, 'http://localhost/joekrollbuilder.com/?page_id=7', 97, 'page', '', 0),
(8, 1, '2017-12-07 22:23:50', '2017-12-07 22:23:50', 'All information on this website is property of <strong>Joe Kroll Builder</strong> &copy;2017.\n\nAll material at this website, such as text, images, markup, CSS, programming, TITLE tag content, META element tag content, and design, is &copy;2017 to <strong>Joe Kroll Builder</strong> and may not be reproduced elsewhere in any way without our express written permission.\n<h2>Responsive Design, Images, and Artwork Cannot Be Reproduced</h2>\nThis <a title="responsive web design" href="https://www.makespaceweb.com/services/louisville-website-design/" target="_blank">responsive web design</a> and unique combination of images, colors, sizes, typography, positioning, CSS, HTML and other markup and programming is &copy;2017 to <strong>Joe Kroll Builder</strong> and cannot be reproduced or used anywhere else, whether in part or in whole. No exceptions.\n<h2>Website Design and Development</h2>\nThis website was created, designed and developed by the <a title="Louisville web design company Makespace" href="https://www.makespaceweb.com/" target="_blank">Louisville web design company Makespace</a>. Any inquiries about this <a title="web design" href="https://www.makespaceweb.com/services/louisville-website-design" target="_blank">website design</a>, <a title="WordPress development" href="https://www.makespaceweb.com/services/louisville-website-design/index.html#anchor-dev" target="_blank">WordPress development</a>, and other <a title="digital marketing services" href="https://www.makespaceweb.com/services/" target="_blank">digital marketing services</a> of this website should be directed to <a href="&#109;&#97;&#105;&#108;&#116;&#111;&#58;&#105;&#110;&#102;&#111;&#64;&#109;&#97;&#107;&#101;&#115;&#112;&#97;&#99;&#101;&#119;&#101;&#98;&#46;&#99;&#111;&#109;" target="_blank">&#105;&#110;&#102;&#111;&#64;&#109;&#97;&#107;&#101;&#115;&#112;&#97;&#99;&#101;&#119;&#101;&#98;&#46;&#99;&#111;&#109;</a>, or you may stop by our Louisville office or our <a href="https://www.makespaceweb.com/Orlando_Web_Design" target="_blank">Orlando web design</a> location.\n\nYou can visit the Louisville web design company online at <a title="www.makespaceweb.com" href="https://www.makespaceweb.com/" target="_blank">www.makespaceweb.com</a>. Makespace reserves the right to use this website in its <a title="web design portfolio" href="https://www.makespaceweb.com/web-design-portfolio/" target="_blank">web design portfolio</a>.\n<h2>Logo and Branding</h2>\nThis website&#8217;s <a href="https://www.oohology.com/Services/Branding" target="_blank">logo and branding</a> may have been created by Oohology - <a href="https://www.oohology.com" target="_blank">Louisville&#8217;s #1 branding, advertising, and digital ad agency</a>. If so, all rights and ownership of the brand assets belong to <strong>Joe Kroll Builder</strong> and you should contact <strong>Joe Kroll Builder</strong> for usage rights. If unsure, you may call <a href="https://www.oohology.com/" target="_blank">Oohology</a> to learn more.', 'Site Info', '', 'publish', 'closed', 'closed', '', 'site-info', '', '', '2017-12-07 22:23:50', '2017-12-07 22:23:50', '', 0, 'http://localhost/joekrollbuilder.com/?page_id=8', 98, 'page', '', 0),
(9, 1, '2017-12-07 22:23:51', '2017-12-07 22:23:51', '[makespace_sitemap]', 'Site Map', '', 'publish', 'closed', 'closed', '', 'site-map', '', '', '2017-12-07 22:23:51', '2017-12-07 22:23:51', '', 0, 'http://localhost/joekrollbuilder.com/?page_id=9', 99, 'page', '', 0),
(10, 1, '2017-12-06 22:23:57', '2017-12-07 03:23:57', '<h1>Lorem Ipsum</h1>\n\n<blockquote>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit..."\n"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain..."</blockquote>\n\n<h2>What is Lorem Ipsum?</h2>\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<h3>Why do we use it?</h3>\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>', 'This Post Has a Very Long Title and Should Look Great on All Devices', '', 'publish', 'closed', 'closed', '', 'this-post-has-a-very-long-title-and-should-look-great-on-all-devices', '', '', '2017-12-06 22:23:57', '2017-12-07 03:23:57', '', 0, 'http://localhost/joekrollbuilder.com/?p=10', 0, 'post', '', 0),
(11, 1, '2017-12-07 17:23:58', '2017-12-07 22:23:58', '', 'Sample Image #1', '', 'inherit', 'closed', 'closed', '', 'sample-image-1', '', '', '2017-12-07 17:23:58', '2017-12-07 22:23:58', '', 10, 'http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/unsplash-2.jpeg', 0, 'attachment', 'image/jpeg', 0),
(12, 1, '2017-12-05 22:24:00', '2017-12-06 03:24:00', '<h1>Lorem Ipsum</h1>\n\n<blockquote>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit..."\n"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain..."</blockquote>\n\n<h2>What is Lorem Ipsum?</h2>\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<h3>Why do we use it?</h3>\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>', 'Short Article Title', '', 'publish', 'closed', 'closed', '', 'short-article-title', '', '', '2017-12-05 22:24:00', '2017-12-06 03:24:00', '', 0, 'http://localhost/joekrollbuilder.com/?p=12', 0, 'post', '', 0),
(13, 1, '2017-12-07 17:24:01', '2017-12-07 22:24:01', '', 'Sample Image #2', '', 'inherit', 'closed', 'closed', '', 'sample-image-2', '', '', '2017-12-12 18:57:25', '2017-12-12 23:57:25', '', 12, 'http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/unsplash-3.jpeg', 0, 'attachment', 'image/jpeg', 0),
(14, 1, '2017-12-04 22:24:02', '2017-12-05 03:24:02', '<h2>Headings</h2>\n<h1>Header one</h1>\n<h2>Header two</h2>\n<h3>Header three</h3>\n<h4>Header four</h4>\n<h5>Header five</h5>\n<h6>Header six</h6>\n<h2>Blockquotes</h2>\nSingle line blockquote:\n<blockquote>Stay hungry. Stay foolish.</blockquote>\nMulti line blockquote with a cite reference:\n<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things.</blockquote>\n<cite>Steve Jobs</cite> - Apple Worldwide Developers\' Conference, 1997\n<h2>Tables</h2>\n<table>\n<thead>\n<tr>\n<th>Employee</th>\n<th>Salary</th>\n<th></th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<th><a href="http://example.org/">John Doe</a></th>\n<td>$1</td>\n<td>Because that\'s all Steve Jobs needed for a salary.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Doe</a></th>\n<td>$100K</td>\n<td>For all the blogging she does.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Fred Bloggs</a></th>\n<td>$100M</td>\n<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Bloggs</a></th>\n<td>$100B</td>\n<td>With hair like that?! Enough said...</td>\n</tr>\n</tbody>\n</table>\n<h2>Definition Lists</h2>\n<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>\n<h2>Unordered Lists (Nested)</h2>\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n<h2>Ordered List (Nested)</h2>\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n<h2>HTML Tags</h2>\nThese supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.\n\n<strong>Address Tag</strong>\n\n<address>1 Infinite Loop\nCupertino, CA 95014\nUnited States</address><strong>Anchor Tag (aka. Link)</strong>\n\nThis is an example of a <a title="Apple" href="http://apple.com">link</a>.\n\n<strong>Abbreviation Tag</strong>\n\nThe abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".\n\n<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>\n\nThe acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".\n\n<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThese tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.\n\n<strong>Cite Tag</strong>\n\n"Code is poetry." --<cite>Automattic</cite>\n\n<strong>Code Tag</strong>\n\nYou will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.\n\n<strong>Delete Tag</strong>\n\nThis tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).\n\n<strong>Emphasize Tag</strong>\n\nThe emphasize tag should <em>italicize</em> text.\n\n<strong>Insert Tag</strong>\n\nThis tag should denote <ins>inserted</ins> text.\n\n<strong>Keyboard Tag</strong>\n\nThis scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Preformatted Tag</strong>\n\nThis tag styles large blocks of code.\n<pre>.post-title {\n	margin: 0 0 5px;\n	font-weight: bold;\n	font-size: 38px;\n	line-height: 1.2;\n	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;\n}</pre>\n<strong>Quote Tag</strong>\n\n<q>Developers, developers, developers...</q> --Steve Ballmer\n\n<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis tag shows <span style="text-decoration: line-through;">strike-through text</span>\n\n<strong>Strong Tag</strong>\n\nThis tag shows <strong>bold<strong> text.</strong></strong>\n\n<strong>Subscript Tag</strong>\n\nGetting our science styling on with H<sub>2</sub>O, which should push the "2" down.\n\n<strong>Superscript Tag</strong>\n\nStill sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.\n\n<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Variable Tag</strong>\n\nThis allows you to denote <var>variables</var>.', 'This Is a Fascinating Article About Us', '', 'publish', 'closed', 'closed', '', 'this-is-a-fascinating-article-about-us', '', '', '2017-12-04 22:24:02', '2017-12-05 03:24:02', '', 0, 'http://localhost/joekrollbuilder.com/?p=14', 0, 'post', '', 0),
(15, 1, '2017-12-03 22:24:03', '2017-12-04 03:24:03', '<h1>Lorem Ipsum</h1>\n\n<blockquote>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit..."\n"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain..."</blockquote>\n\n<h2>What is Lorem Ipsum?</h2>\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<h3>Why do we use it?</h3>\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>', 'Post About What Is Happening In Our Industry', '', 'publish', 'closed', 'closed', '', 'post-about-what-is-happening-in-our-industry', '', '', '2017-12-03 22:24:03', '2017-12-04 03:24:03', '', 0, 'http://localhost/joekrollbuilder.com/?p=15', 0, 'post', '', 0),
(16, 1, '2017-12-02 22:24:05', '2017-12-03 03:24:05', '<h2>Headings</h2>\n<h1>Header one</h1>\n<h2>Header two</h2>\n<h3>Header three</h3>\n<h4>Header four</h4>\n<h5>Header five</h5>\n<h6>Header six</h6>\n<h2>Blockquotes</h2>\nSingle line blockquote:\n<blockquote>Stay hungry. Stay foolish.</blockquote>\nMulti line blockquote with a cite reference:\n<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things.</blockquote>\n<cite>Steve Jobs</cite> - Apple Worldwide Developers\' Conference, 1997\n<h2>Tables</h2>\n<table>\n<thead>\n<tr>\n<th>Employee</th>\n<th>Salary</th>\n<th></th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<th><a href="http://example.org/">John Doe</a></th>\n<td>$1</td>\n<td>Because that\'s all Steve Jobs needed for a salary.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Doe</a></th>\n<td>$100K</td>\n<td>For all the blogging she does.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Fred Bloggs</a></th>\n<td>$100M</td>\n<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Bloggs</a></th>\n<td>$100B</td>\n<td>With hair like that?! Enough said...</td>\n</tr>\n</tbody>\n</table>\n<h2>Definition Lists</h2>\n<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>\n<h2>Unordered Lists (Nested)</h2>\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n<h2>Ordered List (Nested)</h2>\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n<h2>HTML Tags</h2>\nThese supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.\n\n<strong>Address Tag</strong>\n\n<address>1 Infinite Loop\nCupertino, CA 95014\nUnited States</address><strong>Anchor Tag (aka. Link)</strong>\n\nThis is an example of a <a title="Apple" href="http://apple.com">link</a>.\n\n<strong>Abbreviation Tag</strong>\n\nThe abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".\n\n<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>\n\nThe acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".\n\n<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThese tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.\n\n<strong>Cite Tag</strong>\n\n"Code is poetry." --<cite>Automattic</cite>\n\n<strong>Code Tag</strong>\n\nYou will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.\n\n<strong>Delete Tag</strong>\n\nThis tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).\n\n<strong>Emphasize Tag</strong>\n\nThe emphasize tag should <em>italicize</em> text.\n\n<strong>Insert Tag</strong>\n\nThis tag should denote <ins>inserted</ins> text.\n\n<strong>Keyboard Tag</strong>\n\nThis scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Preformatted Tag</strong>\n\nThis tag styles large blocks of code.\n<pre>.post-title {\n	margin: 0 0 5px;\n	font-weight: bold;\n	font-size: 38px;\n	line-height: 1.2;\n	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;\n}</pre>\n<strong>Quote Tag</strong>\n\n<q>Developers, developers, developers...</q> --Steve Ballmer\n\n<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis tag shows <span style="text-decoration: line-through;">strike-through text</span>\n\n<strong>Strong Tag</strong>\n\nThis tag shows <strong>bold<strong> text.</strong></strong>\n\n<strong>Subscript Tag</strong>\n\nGetting our science styling on with H<sub>2</sub>O, which should push the "2" down.\n\n<strong>Superscript Tag</strong>\n\nStill sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.\n\n<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Variable Tag</strong>\n\nThis allows you to denote <var>variables</var>.', 'Ten Things We Say In Sample Blog Posts', '', 'publish', 'closed', 'closed', '', 'ten-things-we-say-in-sample-blog-posts', '', '', '2017-12-02 22:24:05', '2017-12-03 03:24:05', '', 0, 'http://localhost/joekrollbuilder.com/?p=16', 0, 'post', '', 0),
(17, 1, '2017-12-07 17:24:08', '2017-12-07 22:24:08', '', 'Sample Image #5', '', 'inherit', 'closed', 'closed', '', 'sample-image-5', '', '', '2017-12-12 20:24:03', '2017-12-13 01:24:03', '', 16, 'http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/unsplash-4.jpeg', 0, 'attachment', 'image/jpeg', 0),
(18, 1, '2017-12-01 22:24:08', '2017-12-02 03:24:08', '<h1>Lorem Ipsum</h1>\n\n<blockquote>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit..."\n"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain..."</blockquote>\n\n<h2>What is Lorem Ipsum?</h2>\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<h3>Why do we use it?</h3>\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>', 'This Post Has a Very Long Title and Should Look Great on All Devices', '', 'publish', 'closed', 'closed', '', 'this-post-has-a-very-long-title-and-should-look-great-on-all-devices-2', '', '', '2017-12-01 22:24:08', '2017-12-02 03:24:08', '', 0, 'http://localhost/joekrollbuilder.com/?p=18', 0, 'post', '', 0),
(19, 1, '2017-11-30 22:24:09', '2017-12-01 03:24:09', '<h2>Headings</h2>\n<h1>Header one</h1>\n<h2>Header two</h2>\n<h3>Header three</h3>\n<h4>Header four</h4>\n<h5>Header five</h5>\n<h6>Header six</h6>\n<h2>Blockquotes</h2>\nSingle line blockquote:\n<blockquote>Stay hungry. Stay foolish.</blockquote>\nMulti line blockquote with a cite reference:\n<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things.</blockquote>\n<cite>Steve Jobs</cite> - Apple Worldwide Developers\' Conference, 1997\n<h2>Tables</h2>\n<table>\n<thead>\n<tr>\n<th>Employee</th>\n<th>Salary</th>\n<th></th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<th><a href="http://example.org/">John Doe</a></th>\n<td>$1</td>\n<td>Because that\'s all Steve Jobs needed for a salary.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Doe</a></th>\n<td>$100K</td>\n<td>For all the blogging she does.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Fred Bloggs</a></th>\n<td>$100M</td>\n<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Bloggs</a></th>\n<td>$100B</td>\n<td>With hair like that?! Enough said...</td>\n</tr>\n</tbody>\n</table>\n<h2>Definition Lists</h2>\n<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>\n<h2>Unordered Lists (Nested)</h2>\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n<h2>Ordered List (Nested)</h2>\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n<h2>HTML Tags</h2>\nThese supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.\n\n<strong>Address Tag</strong>\n\n<address>1 Infinite Loop\nCupertino, CA 95014\nUnited States</address><strong>Anchor Tag (aka. Link)</strong>\n\nThis is an example of a <a title="Apple" href="http://apple.com">link</a>.\n\n<strong>Abbreviation Tag</strong>\n\nThe abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".\n\n<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>\n\nThe acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".\n\n<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThese tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.\n\n<strong>Cite Tag</strong>\n\n"Code is poetry." --<cite>Automattic</cite>\n\n<strong>Code Tag</strong>\n\nYou will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.\n\n<strong>Delete Tag</strong>\n\nThis tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).\n\n<strong>Emphasize Tag</strong>\n\nThe emphasize tag should <em>italicize</em> text.\n\n<strong>Insert Tag</strong>\n\nThis tag should denote <ins>inserted</ins> text.\n\n<strong>Keyboard Tag</strong>\n\nThis scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Preformatted Tag</strong>\n\nThis tag styles large blocks of code.\n<pre>.post-title {\n	margin: 0 0 5px;\n	font-weight: bold;\n	font-size: 38px;\n	line-height: 1.2;\n	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;\n}</pre>\n<strong>Quote Tag</strong>\n\n<q>Developers, developers, developers...</q> --Steve Ballmer\n\n<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis tag shows <span style="text-decoration: line-through;">strike-through text</span>\n\n<strong>Strong Tag</strong>\n\nThis tag shows <strong>bold<strong> text.</strong></strong>\n\n<strong>Subscript Tag</strong>\n\nGetting our science styling on with H<sub>2</sub>O, which should push the "2" down.\n\n<strong>Superscript Tag</strong>\n\nStill sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.\n\n<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Variable Tag</strong>\n\nThis allows you to denote <var>variables</var>.', 'Short Article Title', '', 'publish', 'closed', 'closed', '', 'short-article-title-2', '', '', '2017-11-30 22:24:09', '2017-12-01 03:24:09', '', 0, 'http://localhost/joekrollbuilder.com/?p=19', 0, 'post', '', 0),
(20, 1, '2017-11-29 22:24:11', '2017-11-30 03:24:11', '<h2>Headings</h2>\n<h1>Header one</h1>\n<h2>Header two</h2>\n<h3>Header three</h3>\n<h4>Header four</h4>\n<h5>Header five</h5>\n<h6>Header six</h6>\n<h2>Blockquotes</h2>\nSingle line blockquote:\n<blockquote>Stay hungry. Stay foolish.</blockquote>\nMulti line blockquote with a cite reference:\n<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things.</blockquote>\n<cite>Steve Jobs</cite> - Apple Worldwide Developers\' Conference, 1997\n<h2>Tables</h2>\n<table>\n<thead>\n<tr>\n<th>Employee</th>\n<th>Salary</th>\n<th></th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<th><a href="http://example.org/">John Doe</a></th>\n<td>$1</td>\n<td>Because that\'s all Steve Jobs needed for a salary.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Doe</a></th>\n<td>$100K</td>\n<td>For all the blogging she does.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Fred Bloggs</a></th>\n<td>$100M</td>\n<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Bloggs</a></th>\n<td>$100B</td>\n<td>With hair like that?! Enough said...</td>\n</tr>\n</tbody>\n</table>\n<h2>Definition Lists</h2>\n<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>\n<h2>Unordered Lists (Nested)</h2>\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n<h2>Ordered List (Nested)</h2>\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n<h2>HTML Tags</h2>\nThese supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.\n\n<strong>Address Tag</strong>\n\n<address>1 Infinite Loop\nCupertino, CA 95014\nUnited States</address><strong>Anchor Tag (aka. Link)</strong>\n\nThis is an example of a <a title="Apple" href="http://apple.com">link</a>.\n\n<strong>Abbreviation Tag</strong>\n\nThe abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".\n\n<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>\n\nThe acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".\n\n<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThese tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.\n\n<strong>Cite Tag</strong>\n\n"Code is poetry." --<cite>Automattic</cite>\n\n<strong>Code Tag</strong>\n\nYou will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.\n\n<strong>Delete Tag</strong>\n\nThis tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).\n\n<strong>Emphasize Tag</strong>\n\nThe emphasize tag should <em>italicize</em> text.\n\n<strong>Insert Tag</strong>\n\nThis tag should denote <ins>inserted</ins> text.\n\n<strong>Keyboard Tag</strong>\n\nThis scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Preformatted Tag</strong>\n\nThis tag styles large blocks of code.\n<pre>.post-title {\n	margin: 0 0 5px;\n	font-weight: bold;\n	font-size: 38px;\n	line-height: 1.2;\n	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;\n}</pre>\n<strong>Quote Tag</strong>\n\n<q>Developers, developers, developers...</q> --Steve Ballmer\n\n<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis tag shows <span style="text-decoration: line-through;">strike-through text</span>\n\n<strong>Strong Tag</strong>\n\nThis tag shows <strong>bold<strong> text.</strong></strong>\n\n<strong>Subscript Tag</strong>\n\nGetting our science styling on with H<sub>2</sub>O, which should push the "2" down.\n\n<strong>Superscript Tag</strong>\n\nStill sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.\n\n<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Variable Tag</strong>\n\nThis allows you to denote <var>variables</var>.', 'This Is a Fascinating Article About Us', '', 'publish', 'closed', 'closed', '', 'this-is-a-fascinating-article-about-us-2', '', '', '2017-11-29 22:24:11', '2017-11-30 03:24:11', '', 0, 'http://localhost/joekrollbuilder.com/?p=20', 0, 'post', '', 0),
(21, 1, '2017-11-28 22:24:13', '2017-11-29 03:24:13', 'Welcome to image alignment! The best way to demonstrate the ebb and flow of the various image positioning options is to nestle them snuggly among an ocean of words. Grab a paddle and let\'s get started.\n\nOn the topic of alignment, it should be noted that users can choose from the options of <em>None</em>, <em>Left</em>, <em>Right, </em>and <em>Center</em>. In addition, they also get the options of <em>Thumbnail</em>, <em>Medium</em>, <em>Large</em> &amp; <em>Fullsize</em>.\n<p style="text-align:center;"><img class="size-full wp-image-906 aligncenter" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /></p>\nThe image above happens to be <em><strong>centered</strong></em>.\n\n<strong><img class="size-full wp-image-904 alignleft" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n<img class="alignnone wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" />\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n<img class="size-full wp-image-905 alignright" title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" />\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd just when you thought we were done, we\'re going to do them all over again with captions!\n\n[caption id="attachment_906" align="aligncenter" width="580"]<img class="size-full wp-image-906" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /> Look at 580x300 getting some <a title="Image Settings" href="http://en.support.wordpress.com/images/image-settings/">caption</a> love.[/caption]\n\nThe image above happens to be <em><strong>centered</strong></em>. The caption also has a link in it, just to see if it does anything funky.\n\n[caption id="attachment_904" align="alignleft" width="150"]<img class="size-full wp-image-904" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /> Itty-bitty caption.[/caption]\n\n<strong></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n[caption id="attachment_907" align="alignnone" width="1200"]<img class=" wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" /> Massive image comment for your eyeballs.[/caption]\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n[caption id="attachment_905" align="alignright" width="300"]<img class="size-full wp-image-905 " title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" /> Feels good to be right all the time.[/caption]\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd that\'s a wrap, yo! You survived the tumultuous waters of alignment. Image alignment achievement unlocked!', 'Post About What Is Happening In Our Industry', '', 'publish', 'closed', 'closed', '', 'post-about-what-is-happening-in-our-industry-2', '', '', '2017-11-28 22:24:13', '2017-11-29 03:24:13', '', 0, 'http://localhost/joekrollbuilder.com/?p=21', 0, 'post', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(22, 1, '2017-11-27 22:24:14', '2017-11-28 03:24:14', '<h1>Lorem Ipsum</h1>\n\n<blockquote>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit..."\n"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain..."</blockquote>\n\n<h2>What is Lorem Ipsum?</h2>\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<h3>Why do we use it?</h3>\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>', 'Ten Things We Say In Sample Blog Posts', '', 'publish', 'closed', 'closed', '', 'ten-things-we-say-in-sample-blog-posts-2', '', '', '2017-11-27 22:24:14', '2017-11-28 03:24:14', '', 0, 'http://localhost/joekrollbuilder.com/?p=22', 0, 'post', '', 0),
(23, 1, '2017-11-26 22:24:15', '2017-11-27 03:24:15', '<h1>Lorem Ipsum</h1>\n\n<blockquote>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit..."\n"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain..."</blockquote>\n\n<h2>What is Lorem Ipsum?</h2>\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<h3>Why do we use it?</h3>\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>', 'This Post Has a Very Long Title and Should Look Great on All Devices', '', 'publish', 'closed', 'closed', '', 'this-post-has-a-very-long-title-and-should-look-great-on-all-devices-3', '', '', '2017-11-26 22:24:15', '2017-11-27 03:24:15', '', 0, 'http://localhost/joekrollbuilder.com/?p=23', 0, 'post', '', 0),
(24, 1, '2017-12-09 04:44:25', '2017-12-09 09:44:25', '', 'logo', '', 'inherit', 'closed', 'closed', '', 'logo', '', '', '2017-12-09 04:44:25', '2017-12-09 09:44:25', '', 0, 'http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/logo-1.svg', 0, 'attachment', 'image/svg+xml', 0),
(25, 1, '2017-12-09 04:52:08', '2017-12-09 09:52:08', 'Ipsum vitae sollicitudin interdum felis ipsum convallis lorem acscele risque leo dolor slim trebor lehcar mailliw. Condimentum tempus nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem. Nulla lacinia, ipsum vitae sollicitudin interdum, felis ipsum convallis lorem, ac scelerisque leo turpis in lorem. Cras et purus vel arcu ultricies eleifend. Etiam convallis massa sed dolor.\r\n\r\n<img class="alignleft wp-image-60 size-full" src="http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/joe-e1512935590373.png" alt="" width="300" height="470" />\r\n<h2>Who is Joe Kroll?</h2>\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit nulla facilisis dolor quis est suspen disse potenti phasellus et diam donec metus donec mi ante, vestibulum ut ornare non risque leo dolor slim trebor lehcar mailliw.\r\n\r\nFusce placerat dignissim lacus. Suspendisse cursus nunc ut ante. Phasellus pulvinar viverra nunc. Ut convallis dui et augue. Sed felis neque viverra in eleifend ac pharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.\r\n\r\nFusce placerat dignissim lacus. Suspendisse cursus nunc ut ante. Phasellus pulvinar viverra nunc. Ut convallis dui et augue. Sed felis neque viverra in eleifend ac pharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.\r\n\r\nFusce placerat dignissim lacus. Suspendisse cursus nunc ut ante. Phasellus pulvinar viverra nunc. Ut convallis dui et augue. Sed felis neque viverra in eleifend ac pharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.\r\n\r\nFusce placerat dignissim lacus. Suspendisse cursus nunc ut ante. Phasellus pulvinar viverra nunc. Ut convallis dui et augue. Sed felis neque viverra in eleifend ac pharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.\r\n\r\n\r\n\r\n				<div class="partners-list">\r\n					<h2>Joe’s Partners</h2>\r\n					<ul>\r\n						<li>New Century Plumbing</li>\r\n						<li>KME Electric</li>\r\n						<li>Chapman Heating & Cooling</li>\r\n						<li>Century Entertainment</li>\r\n						<li>Premiere Flooring</li>\r\n						<li>Willis-Klein</li>\r\n						<li>PC Lumber</li>\r\n						<li>Jennifer Bergin</li>\r\n						<li>Cindy Druin</li>\r\n					</ul>\r\n					<a href="/about-us/trusted-partners/" class="read-more">See our trusted partners <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>\r\n				</div><!-- /.partners-list -->', 'About Us', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2017-12-12 18:57:43', '2017-12-12 23:57:43', '', 0, 'http://localhost/joekrollbuilder.com/?page_id=25', 0, 'page', '', 0),
(26, 1, '2017-12-09 04:52:08', '2017-12-09 09:52:08', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2017-12-09 04:52:08', '2017-12-09 09:52:08', '', 25, 'http://localhost/joekrollbuilder.com/?p=26', 0, 'revision', '', 0),
(27, 1, '2017-12-09 04:52:33', '2017-12-09 09:52:33', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.', 'Home Building Process', '', 'publish', 'closed', 'closed', '', 'home-building-process', '', '', '2017-12-14 03:55:49', '2017-12-14 08:55:49', '', 0, 'http://localhost/joekrollbuilder.com/?page_id=27', 0, 'page', '', 0),
(28, 1, '2017-12-09 04:52:33', '2017-12-09 09:52:33', '', 'Home Building Process', '', 'inherit', 'closed', 'closed', '', '27-revision-v1', '', '', '2017-12-09 04:52:33', '2017-12-09 09:52:33', '', 27, 'http://localhost/joekrollbuilder.com/?p=28', 0, 'revision', '', 0),
(31, 1, '2017-12-09 04:55:45', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-09 04:55:45', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?p=31', 1, 'nav_menu_item', '', 0),
(32, 1, '2017-12-09 04:55:46', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-09 04:55:46', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?p=32', 1, 'nav_menu_item', '', 0),
(33, 1, '2017-12-09 04:55:47', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-09 04:55:47', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?p=33', 1, 'nav_menu_item', '', 0),
(34, 1, '2017-12-09 04:55:48', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-09 04:55:48', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?p=34', 1, 'nav_menu_item', '', 0),
(36, 1, '2017-12-09 04:55:49', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-09 04:55:49', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?p=36', 1, 'nav_menu_item', '', 0),
(37, 1, '2017-12-09 04:55:50', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-09 04:55:50', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?p=37', 1, 'nav_menu_item', '', 0),
(38, 1, '2017-12-09 04:55:51', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-09 04:55:51', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?p=38', 1, 'nav_menu_item', '', 0),
(39, 1, '2017-12-09 04:55:52', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-09 04:55:52', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?p=39', 1, 'nav_menu_item', '', 0),
(40, 1, '2017-12-09 04:55:52', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-09 04:55:52', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?p=40', 1, 'nav_menu_item', '', 0),
(41, 1, '2017-12-09 04:56:01', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-09 04:56:01', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?p=41', 1, 'nav_menu_item', '', 0),
(42, 1, '2017-12-09 04:56:02', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-09 04:56:02', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?p=42', 1, 'nav_menu_item', '', 0),
(43, 1, '2017-12-09 04:56:03', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-09 04:56:03', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?p=43', 1, 'nav_menu_item', '', 0),
(44, 1, '2017-12-09 04:56:03', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-09 04:56:03', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?p=44', 1, 'nav_menu_item', '', 0),
(46, 1, '2017-12-09 04:56:05', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-09 04:56:05', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?p=46', 1, 'nav_menu_item', '', 0),
(47, 1, '2017-12-09 04:56:06', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-09 04:56:06', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?p=47', 1, 'nav_menu_item', '', 0),
(48, 1, '2017-12-09 04:56:06', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-09 04:56:06', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?p=48', 1, 'nav_menu_item', '', 0),
(49, 1, '2017-12-09 04:56:07', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-09 04:56:07', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?p=49', 1, 'nav_menu_item', '', 0),
(50, 1, '2017-12-09 04:56:08', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2017-12-09 04:56:08', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?p=50', 1, 'nav_menu_item', '', 0),
(51, 1, '2017-12-09 04:57:32', '2017-12-09 09:57:32', ' ', '', '', 'publish', 'closed', 'closed', '', '51', '', '', '2017-12-11 03:20:48', '2017-12-11 08:20:48', '', 0, 'http://localhost/joekrollbuilder.com/?p=51', 3, 'nav_menu_item', '', 0),
(52, 1, '2017-12-09 04:57:31', '2017-12-09 09:57:31', ' ', '', '', 'publish', 'closed', 'closed', '', '52', '', '', '2017-12-11 03:20:48', '2017-12-11 08:20:48', '', 0, 'http://localhost/joekrollbuilder.com/?p=52', 2, 'nav_menu_item', '', 0),
(53, 1, '2017-12-09 04:57:31', '2017-12-09 09:57:31', ' ', '', '', 'publish', 'closed', 'closed', '', '53', '', '', '2017-12-11 03:20:48', '2017-12-11 08:20:48', '', 0, 'http://localhost/joekrollbuilder.com/?p=53', 1, 'nav_menu_item', '', 0),
(55, 1, '2017-12-09 04:57:32', '2017-12-09 09:57:32', ' ', '', '', 'publish', 'closed', 'closed', '', '55', '', '', '2017-12-11 03:20:48', '2017-12-11 08:20:48', '', 0, 'http://localhost/joekrollbuilder.com/?p=55', 5, 'nav_menu_item', '', 0),
(56, 1, '2017-12-09 04:58:47', '2017-12-09 09:58:47', '', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2017-12-09 04:58:47', '2017-12-09 09:58:47', '', 4, 'http://localhost/joekrollbuilder.com/4-revision-v1/', 0, 'revision', '', 0),
(57, 1, '2017-12-09 04:59:39', '2017-12-09 09:59:39', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2017-12-09 04:59:39', '2017-12-09 09:59:39', '', 6, 'http://localhost/joekrollbuilder.com/6-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2017-12-10 14:54:35', '2017-12-10 19:54:35', 'Ipsum vitae sollicitudin interdum felis ipsum convallis lorem acscele risque leo dolor slim trebor lehcar mailliw. Condimentum tempus nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem. Nulla lacinia, ipsum vitae sollicitudin interdum, felis ipsum convallis lorem, ac scelerisque leo turpis in lorem. Cras et purus vel arcu ultricies eleifend. Etiam convallis massa sed dolor.\n\n<img class="alignleft wp-image-60 size-full" src="http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/joe-e1512935590373.png" alt="" width="300" height="470" />\n<h2>Who is Joe Kroll?</h2>\nLorem ipsum dolor sit amet, consectetuer adipiscing elit nulla facilisis dolor quis est suspen disse potenti phasellus et diam donec metus donec mi ante, vestibulum ut ornare non risque leo dolor slim trebor lehcar mailliw.\n\nFusce placerat dignissim lacus. Suspendisse cursus nunc ut ante. Phasellus pulvinar viverra nunc. Ut convallis dui et augue. Sed felis neque viverra in eleifend ac pharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.\n\n<h2>Joe’s Partners</h2>', 'About Us', '', 'inherit', 'closed', 'closed', '', '25-autosave-v1', '', '', '2017-12-10 14:54:35', '2017-12-10 19:54:35', '', 25, 'http://localhost/joekrollbuilder.com/25-autosave-v1/', 0, 'revision', '', 0),
(59, 1, '2017-12-10 14:49:31', '2017-12-10 19:49:31', 'Ipsum vitae sollicitudin interdum felis ipsum convallis lorem acscele risque leo dolor slim trebor lehcar mailliw. Condimentum tempus nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem. Nulla lacinia, ipsum vitae sollicitudin interdum, felis ipsum convallis lorem, ac scelerisque leo turpis in lorem. Cras et purus vel arcu ultricies eleifend. Etiam convallis massa sed dolor.', 'About Us', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2017-12-10 14:49:31', '2017-12-10 19:49:31', '', 25, 'http://localhost/joekrollbuilder.com/25-revision-v1/', 0, 'revision', '', 0),
(60, 1, '2017-12-10 14:50:45', '2017-12-10 19:50:45', '', 'joe', '', 'inherit', 'closed', 'closed', '', 'joe', '', '', '2017-12-10 14:50:45', '2017-12-10 19:50:45', '', 25, 'http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/joe.png', 0, 'attachment', 'image/png', 0),
(61, 1, '2017-12-10 14:52:23', '2017-12-10 19:52:23', 'Ipsum vitae sollicitudin interdum felis ipsum convallis lorem acscele risque leo dolor slim trebor lehcar mailliw. Condimentum tempus nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem. Nulla lacinia, ipsum vitae sollicitudin interdum, felis ipsum convallis lorem, ac scelerisque leo turpis in lorem. Cras et purus vel arcu ultricies eleifend. Etiam convallis massa sed dolor.\r\n\r\n<img class="alignleft wp-image-60 size-thumbnail" src="http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/joe-300x300.png" alt="" width="300" height="300" />\r\n<h2>Who is Joe Kroll?</h2>\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit nulla facilisis dolor quis est suspen disse potenti phasellus et diam donec metus donec mi ante, vestibulum ut ornare non risque leo dolor slim trebor lehcar mailliw.\r\n\r\nFusce placerat dignissim lacus. Suspendisse cursus nunc ut ante. Phasellus pulvinar viverra nunc. Ut convallis dui et augue. Sed felis neque viverra in eleifend ac pharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.', 'About Us', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2017-12-10 14:52:23', '2017-12-10 19:52:23', '', 25, 'http://localhost/joekrollbuilder.com/25-revision-v1/', 0, 'revision', '', 0),
(62, 1, '2017-12-10 14:53:30', '2017-12-10 19:53:30', 'Ipsum vitae sollicitudin interdum felis ipsum convallis lorem acscele risque leo dolor slim trebor lehcar mailliw. Condimentum tempus nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem. Nulla lacinia, ipsum vitae sollicitudin interdum, felis ipsum convallis lorem, ac scelerisque leo turpis in lorem. Cras et purus vel arcu ultricies eleifend. Etiam convallis massa sed dolor.\r\n\r\n<img class="alignleft wp-image-60 size-full" src="http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/joe-e1512935590373.png" alt="" width="300" height="470" />\r\n<h2>Who is Joe Kroll?</h2>\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit nulla facilisis dolor quis est suspen disse potenti phasellus et diam donec metus donec mi ante, vestibulum ut ornare non risque leo dolor slim trebor lehcar mailliw.\r\n\r\nFusce placerat dignissim lacus. Suspendisse cursus nunc ut ante. Phasellus pulvinar viverra nunc. Ut convallis dui et augue. Sed felis neque viverra in eleifend ac pharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.', 'About Us', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2017-12-10 14:53:30', '2017-12-10 19:53:30', '', 25, 'http://localhost/joekrollbuilder.com/25-revision-v1/', 0, 'revision', '', 0),
(63, 1, '2017-12-10 14:55:10', '2017-12-10 19:55:10', 'Ipsum vitae sollicitudin interdum felis ipsum convallis lorem acscele risque leo dolor slim trebor lehcar mailliw. Condimentum tempus nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem. Nulla lacinia, ipsum vitae sollicitudin interdum, felis ipsum convallis lorem, ac scelerisque leo turpis in lorem. Cras et purus vel arcu ultricies eleifend. Etiam convallis massa sed dolor.\r\n\r\n<img class="alignleft wp-image-60 size-full" src="http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/joe-e1512935590373.png" alt="" width="300" height="470" />\r\n<h2>Who is Joe Kroll?</h2>\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit nulla facilisis dolor quis est suspen disse potenti phasellus et diam donec metus donec mi ante, vestibulum ut ornare non risque leo dolor slim trebor lehcar mailliw.\r\n\r\nFusce placerat dignissim lacus. Suspendisse cursus nunc ut ante. Phasellus pulvinar viverra nunc. Ut convallis dui et augue. Sed felis neque viverra in eleifend ac pharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.\r\n\r\n<h2>Joe’s Partners</h2>\r\nNew Century Plumbing,  KME Electric,  Chapman Heating & Cooling, Century Entertainment, Premiere Flooring, Willis-Klein, PC Lumber, Jennifer Bergin, Cindy Druin ', 'About Us', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2017-12-10 14:55:10', '2017-12-10 19:55:10', '', 25, 'http://localhost/joekrollbuilder.com/25-revision-v1/', 0, 'revision', '', 0),
(64, 1, '2017-12-10 14:56:14', '2017-12-10 19:56:14', 'Ipsum vitae sollicitudin interdum felis ipsum convallis lorem acscele risque leo dolor slim trebor lehcar mailliw. Condimentum tempus nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem. Nulla lacinia, ipsum vitae sollicitudin interdum, felis ipsum convallis lorem, ac scelerisque leo turpis in lorem. Cras et purus vel arcu ultricies eleifend. Etiam convallis massa sed dolor.\r\n\r\n<img class="alignleft wp-image-60 size-full" src="http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/joe-e1512935590373.png" alt="" width="300" height="470" />\r\n<h2>Who is Joe Kroll?</h2>\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit nulla facilisis dolor quis est suspen disse potenti phasellus et diam donec metus donec mi ante, vestibulum ut ornare non risque leo dolor slim trebor lehcar mailliw.\r\n\r\nFusce placerat dignissim lacus. Suspendisse cursus nunc ut ante. Phasellus pulvinar viverra nunc. Ut convallis dui et augue. Sed felis neque viverra in eleifend ac pharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.\r\n\r\nFusce placerat dignissim lacus. Suspendisse cursus nunc ut ante. Phasellus pulvinar viverra nunc. Ut convallis dui et augue. Sed felis neque viverra in eleifend ac pharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.\r\n\r\nFusce placerat dignissim lacus. Suspendisse cursus nunc ut ante. Phasellus pulvinar viverra nunc. Ut convallis dui et augue. Sed felis neque viverra in eleifend ac pharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.\r\n\r\nFusce placerat dignissim lacus. Suspendisse cursus nunc ut ante. Phasellus pulvinar viverra nunc. Ut convallis dui et augue. Sed felis neque viverra in eleifend ac pharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.\r\n<h2>Joe’s Partners</h2>\r\nNew Century Plumbing, KME Electric, Chapman Heating &amp; Cooling, Century Entertainment, Premiere Flooring, Willis-Klein, PC Lumber, Jennifer Bergin, Cindy Druin', 'About Us', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2017-12-10 14:56:14', '2017-12-10 19:56:14', '', 25, 'http://localhost/joekrollbuilder.com/25-revision-v1/', 0, 'revision', '', 0),
(65, 1, '2017-12-10 15:23:38', '2017-12-10 20:23:38', 'We have picked Louisville’s top performers; however, if you have a vendor you would like to work with, bring to our attention.', 'Trusted Partners', '', 'publish', 'closed', 'closed', '', 'trusted-partners', '', '', '2017-12-12 18:43:09', '2017-12-12 23:43:09', '', 25, 'http://localhost/joekrollbuilder.com/?page_id=65', 0, 'page', '', 0),
(66, 1, '2017-12-10 15:23:38', '2017-12-10 20:23:38', '', 'Trusted Partners', '', 'inherit', 'closed', 'closed', '', '65-revision-v1', '', '', '2017-12-10 15:23:38', '2017-12-10 20:23:38', '', 65, 'http://localhost/joekrollbuilder.com/65-revision-v1/', 0, 'revision', '', 0),
(67, 1, '2017-12-10 15:25:12', '2017-12-10 20:25:12', 'We have picked Louisville’s top performers; however, if you have a vendor you would like to work with, bring to our attention.', 'Trusted Partners', '', 'inherit', 'closed', 'closed', '', '65-revision-v1', '', '', '2017-12-10 15:25:12', '2017-12-10 20:25:12', '', 65, 'http://localhost/joekrollbuilder.com/65-revision-v1/', 0, 'revision', '', 0),
(68, 1, '2017-12-10 17:40:17', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2017-12-10 17:40:17', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?page_id=68', 0, 'page', '', 0),
(69, 1, '2017-12-10 17:41:04', '2017-12-10 22:41:04', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.', 'Home Building Process', '', 'inherit', 'closed', 'closed', '', '27-revision-v1', '', '', '2017-12-10 17:41:04', '2017-12-10 22:41:04', '', 27, 'http://localhost/joekrollbuilder.com/27-revision-v1/', 0, 'revision', '', 0),
(70, 1, '2017-12-12 15:20:31', '2017-12-12 20:20:31', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus selim at mattis condimentum, quam enim auctor nunc.', 'Contact Joe', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2017-12-12 15:20:31', '2017-12-12 20:20:31', '', 6, 'http://localhost/joekrollbuilder.com/6-revision-v1/', 0, 'revision', '', 0),
(71, 1, '2017-12-11 20:27:26', '2017-12-12 01:27:26', '<h1>Lorem Ipsum</h1>\r\n\r\nNeque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit. There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain.', 'This Post Has a Very Long Title and Should Look Great on All Devices', '', 'publish', 'closed', 'closed', '', 'this-post-has-a-very-long-title-and-should-look-great-on-all-devices', '', '', '2017-12-12 20:04:35', '2017-12-13 01:04:35', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/this-post-has-a-very-long-title-and-should-look-great-on-all-devices/', 1, 'portfolio', '', 0),
(72, 1, '2017-12-12 15:27:26', '2017-12-12 20:27:26', '', 'Sample Image #1', '', 'inherit', 'closed', 'closed', '', 'sample-image-1-2', '', '', '2017-12-12 15:27:26', '2017-12-12 20:27:26', '', 71, 'http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/unsplash-5.jpeg', 0, 'attachment', 'image/jpeg', 0),
(73, 1, '2017-12-10 20:27:26', '2017-12-11 01:27:26', '<h1>Lorem Ipsum</h1>\n\n<blockquote>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit..."\n"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain..."</blockquote>\n\n<h2>What is Lorem Ipsum?</h2>\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<h3>Why do we use it?</h3>\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>', 'Short Article Title', '', 'publish', 'closed', 'closed', '', 'short-article-title', '', '', '2017-12-10 20:27:26', '2017-12-11 01:27:26', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/short-article-title/', 2, 'portfolio', '', 0),
(74, 1, '2017-12-12 15:27:26', '2017-12-12 20:27:26', '', 'Sample Image #2', '', 'inherit', 'closed', 'closed', '', 'sample-image-2-2', '', '', '2017-12-12 19:39:51', '2017-12-13 00:39:51', '', 73, 'http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/unsplash-6.jpeg', 0, 'attachment', 'image/jpeg', 0),
(75, 1, '2017-12-09 20:27:26', '2017-12-10 01:27:26', '<h2>Headings</h2>\n<h1>Header one</h1>\n<h2>Header two</h2>\n<h3>Header three</h3>\n<h4>Header four</h4>\n<h5>Header five</h5>\n<h6>Header six</h6>\n<h2>Blockquotes</h2>\nSingle line blockquote:\n<blockquote>Stay hungry. Stay foolish.</blockquote>\nMulti line blockquote with a cite reference:\n<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things.</blockquote>\n<cite>Steve Jobs</cite> - Apple Worldwide Developers\' Conference, 1997\n<h2>Tables</h2>\n<table>\n<thead>\n<tr>\n<th>Employee</th>\n<th>Salary</th>\n<th></th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<th><a href="http://example.org/">John Doe</a></th>\n<td>$1</td>\n<td>Because that\'s all Steve Jobs needed for a salary.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Doe</a></th>\n<td>$100K</td>\n<td>For all the blogging she does.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Fred Bloggs</a></th>\n<td>$100M</td>\n<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Bloggs</a></th>\n<td>$100B</td>\n<td>With hair like that?! Enough said...</td>\n</tr>\n</tbody>\n</table>\n<h2>Definition Lists</h2>\n<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>\n<h2>Unordered Lists (Nested)</h2>\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n<h2>Ordered List (Nested)</h2>\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n<h2>HTML Tags</h2>\nThese supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.\n\n<strong>Address Tag</strong>\n\n<address>1 Infinite Loop\nCupertino, CA 95014\nUnited States</address><strong>Anchor Tag (aka. Link)</strong>\n\nThis is an example of a <a title="Apple" href="http://apple.com">link</a>.\n\n<strong>Abbreviation Tag</strong>\n\nThe abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".\n\n<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>\n\nThe acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".\n\n<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThese tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.\n\n<strong>Cite Tag</strong>\n\n"Code is poetry." --<cite>Automattic</cite>\n\n<strong>Code Tag</strong>\n\nYou will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.\n\n<strong>Delete Tag</strong>\n\nThis tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).\n\n<strong>Emphasize Tag</strong>\n\nThe emphasize tag should <em>italicize</em> text.\n\n<strong>Insert Tag</strong>\n\nThis tag should denote <ins>inserted</ins> text.\n\n<strong>Keyboard Tag</strong>\n\nThis scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Preformatted Tag</strong>\n\nThis tag styles large blocks of code.\n<pre>.post-title {\n	margin: 0 0 5px;\n	font-weight: bold;\n	font-size: 38px;\n	line-height: 1.2;\n	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;\n}</pre>\n<strong>Quote Tag</strong>\n\n<q>Developers, developers, developers...</q> --Steve Ballmer\n\n<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis tag shows <span style="text-decoration: line-through;">strike-through text</span>\n\n<strong>Strong Tag</strong>\n\nThis tag shows <strong>bold<strong> text.</strong></strong>\n\n<strong>Subscript Tag</strong>\n\nGetting our science styling on with H<sub>2</sub>O, which should push the "2" down.\n\n<strong>Superscript Tag</strong>\n\nStill sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.\n\n<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Variable Tag</strong>\n\nThis allows you to denote <var>variables</var>.', 'This Is a Fascinating Article About Us', '', 'publish', 'closed', 'closed', '', 'this-is-a-fascinating-article-about-us', '', '', '2017-12-09 20:27:26', '2017-12-10 01:27:26', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/this-is-a-fascinating-article-about-us/', 3, 'portfolio', '', 0),
(76, 1, '2017-12-08 20:27:26', '2017-12-09 01:27:26', '<h1>Lorem Ipsum</h1>\n\n<blockquote>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit..."\n"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain..."</blockquote>\n\n<h2>What is Lorem Ipsum?</h2>\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<h3>Why do we use it?</h3>\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>', 'Post About What Is Happening In Our Industry', '', 'publish', 'closed', 'closed', '', 'post-about-what-is-happening-in-our-industry', '', '', '2017-12-08 20:27:26', '2017-12-09 01:27:26', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/post-about-what-is-happening-in-our-industry/', 4, 'portfolio', '', 0),
(77, 1, '2017-12-12 15:27:26', '2017-12-12 20:27:26', '', 'Sample Image #4', '', 'inherit', 'closed', 'closed', '', 'sample-image-4', '', '', '2017-12-14 03:18:46', '2017-12-14 08:18:46', '', 76, 'http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/unsplash-7.jpeg', 0, 'attachment', 'image/jpeg', 0),
(78, 1, '2017-12-07 20:27:27', '2017-12-08 01:27:27', 'Welcome to image alignment! The best way to demonstrate the ebb and flow of the various image positioning options is to nestle them snuggly among an ocean of words. Grab a paddle and let\'s get started.\n\nOn the topic of alignment, it should be noted that users can choose from the options of <em>None</em>, <em>Left</em>, <em>Right, </em>and <em>Center</em>. In addition, they also get the options of <em>Thumbnail</em>, <em>Medium</em>, <em>Large</em> &amp; <em>Fullsize</em>.\n<p style="text-align:center;"><img class="size-full wp-image-906 aligncenter" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /></p>\nThe image above happens to be <em><strong>centered</strong></em>.\n\n<strong><img class="size-full wp-image-904 alignleft" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n<img class="alignnone wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" />\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n<img class="size-full wp-image-905 alignright" title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" />\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd just when you thought we were done, we\'re going to do them all over again with captions!\n\n[caption id="attachment_906" align="aligncenter" width="580"]<img class="size-full wp-image-906" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /> Look at 580x300 getting some <a title="Image Settings" href="http://en.support.wordpress.com/images/image-settings/">caption</a> love.[/caption]\n\nThe image above happens to be <em><strong>centered</strong></em>. The caption also has a link in it, just to see if it does anything funky.\n\n[caption id="attachment_904" align="alignleft" width="150"]<img class="size-full wp-image-904" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /> Itty-bitty caption.[/caption]\n\n<strong></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n[caption id="attachment_907" align="alignnone" width="1200"]<img class=" wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" /> Massive image comment for your eyeballs.[/caption]\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n[caption id="attachment_905" align="alignright" width="300"]<img class="size-full wp-image-905 " title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" /> Feels good to be right all the time.[/caption]\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd that\'s a wrap, yo! You survived the tumultuous waters of alignment. Image alignment achievement unlocked!', 'Ten Things We Say In Sample Blog Posts', '', 'publish', 'closed', 'closed', '', 'ten-things-we-say-in-sample-blog-posts', '', '', '2017-12-07 20:27:27', '2017-12-08 01:27:27', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/ten-things-we-say-in-sample-blog-posts/', 5, 'portfolio', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(79, 1, '2017-12-06 20:27:27', '2017-12-07 01:27:27', '<h2>Headings</h2>\n<h1>Header one</h1>\n<h2>Header two</h2>\n<h3>Header three</h3>\n<h4>Header four</h4>\n<h5>Header five</h5>\n<h6>Header six</h6>\n<h2>Blockquotes</h2>\nSingle line blockquote:\n<blockquote>Stay hungry. Stay foolish.</blockquote>\nMulti line blockquote with a cite reference:\n<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things.</blockquote>\n<cite>Steve Jobs</cite> - Apple Worldwide Developers\' Conference, 1997\n<h2>Tables</h2>\n<table>\n<thead>\n<tr>\n<th>Employee</th>\n<th>Salary</th>\n<th></th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<th><a href="http://example.org/">John Doe</a></th>\n<td>$1</td>\n<td>Because that\'s all Steve Jobs needed for a salary.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Doe</a></th>\n<td>$100K</td>\n<td>For all the blogging she does.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Fred Bloggs</a></th>\n<td>$100M</td>\n<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Bloggs</a></th>\n<td>$100B</td>\n<td>With hair like that?! Enough said...</td>\n</tr>\n</tbody>\n</table>\n<h2>Definition Lists</h2>\n<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>\n<h2>Unordered Lists (Nested)</h2>\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n<h2>Ordered List (Nested)</h2>\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n<h2>HTML Tags</h2>\nThese supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.\n\n<strong>Address Tag</strong>\n\n<address>1 Infinite Loop\nCupertino, CA 95014\nUnited States</address><strong>Anchor Tag (aka. Link)</strong>\n\nThis is an example of a <a title="Apple" href="http://apple.com">link</a>.\n\n<strong>Abbreviation Tag</strong>\n\nThe abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".\n\n<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>\n\nThe acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".\n\n<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThese tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.\n\n<strong>Cite Tag</strong>\n\n"Code is poetry." --<cite>Automattic</cite>\n\n<strong>Code Tag</strong>\n\nYou will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.\n\n<strong>Delete Tag</strong>\n\nThis tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).\n\n<strong>Emphasize Tag</strong>\n\nThe emphasize tag should <em>italicize</em> text.\n\n<strong>Insert Tag</strong>\n\nThis tag should denote <ins>inserted</ins> text.\n\n<strong>Keyboard Tag</strong>\n\nThis scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Preformatted Tag</strong>\n\nThis tag styles large blocks of code.\n<pre>.post-title {\n	margin: 0 0 5px;\n	font-weight: bold;\n	font-size: 38px;\n	line-height: 1.2;\n	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;\n}</pre>\n<strong>Quote Tag</strong>\n\n<q>Developers, developers, developers...</q> --Steve Ballmer\n\n<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis tag shows <span style="text-decoration: line-through;">strike-through text</span>\n\n<strong>Strong Tag</strong>\n\nThis tag shows <strong>bold<strong> text.</strong></strong>\n\n<strong>Subscript Tag</strong>\n\nGetting our science styling on with H<sub>2</sub>O, which should push the "2" down.\n\n<strong>Superscript Tag</strong>\n\nStill sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.\n\n<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Variable Tag</strong>\n\nThis allows you to denote <var>variables</var>.', 'This Post Has a Very Long Title and Should Look Great on All Devices', '', 'publish', 'closed', 'closed', '', 'this-post-has-a-very-long-title-and-should-look-great-on-all-devices-2', '', '', '2017-12-06 20:27:27', '2017-12-07 01:27:27', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/this-post-has-a-very-long-title-and-should-look-great-on-all-devices-2/', 6, 'portfolio', '', 0),
(80, 1, '2017-12-05 20:27:27', '2017-12-06 01:27:27', '<h2>Headings</h2>\n<h1>Header one</h1>\n<h2>Header two</h2>\n<h3>Header three</h3>\n<h4>Header four</h4>\n<h5>Header five</h5>\n<h6>Header six</h6>\n<h2>Blockquotes</h2>\nSingle line blockquote:\n<blockquote>Stay hungry. Stay foolish.</blockquote>\nMulti line blockquote with a cite reference:\n<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things.</blockquote>\n<cite>Steve Jobs</cite> - Apple Worldwide Developers\' Conference, 1997\n<h2>Tables</h2>\n<table>\n<thead>\n<tr>\n<th>Employee</th>\n<th>Salary</th>\n<th></th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<th><a href="http://example.org/">John Doe</a></th>\n<td>$1</td>\n<td>Because that\'s all Steve Jobs needed for a salary.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Doe</a></th>\n<td>$100K</td>\n<td>For all the blogging she does.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Fred Bloggs</a></th>\n<td>$100M</td>\n<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Bloggs</a></th>\n<td>$100B</td>\n<td>With hair like that?! Enough said...</td>\n</tr>\n</tbody>\n</table>\n<h2>Definition Lists</h2>\n<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>\n<h2>Unordered Lists (Nested)</h2>\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n<h2>Ordered List (Nested)</h2>\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n<h2>HTML Tags</h2>\nThese supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.\n\n<strong>Address Tag</strong>\n\n<address>1 Infinite Loop\nCupertino, CA 95014\nUnited States</address><strong>Anchor Tag (aka. Link)</strong>\n\nThis is an example of a <a title="Apple" href="http://apple.com">link</a>.\n\n<strong>Abbreviation Tag</strong>\n\nThe abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".\n\n<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>\n\nThe acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".\n\n<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThese tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.\n\n<strong>Cite Tag</strong>\n\n"Code is poetry." --<cite>Automattic</cite>\n\n<strong>Code Tag</strong>\n\nYou will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.\n\n<strong>Delete Tag</strong>\n\nThis tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).\n\n<strong>Emphasize Tag</strong>\n\nThe emphasize tag should <em>italicize</em> text.\n\n<strong>Insert Tag</strong>\n\nThis tag should denote <ins>inserted</ins> text.\n\n<strong>Keyboard Tag</strong>\n\nThis scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Preformatted Tag</strong>\n\nThis tag styles large blocks of code.\n<pre>.post-title {\n	margin: 0 0 5px;\n	font-weight: bold;\n	font-size: 38px;\n	line-height: 1.2;\n	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;\n}</pre>\n<strong>Quote Tag</strong>\n\n<q>Developers, developers, developers...</q> --Steve Ballmer\n\n<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis tag shows <span style="text-decoration: line-through;">strike-through text</span>\n\n<strong>Strong Tag</strong>\n\nThis tag shows <strong>bold<strong> text.</strong></strong>\n\n<strong>Subscript Tag</strong>\n\nGetting our science styling on with H<sub>2</sub>O, which should push the "2" down.\n\n<strong>Superscript Tag</strong>\n\nStill sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.\n\n<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Variable Tag</strong>\n\nThis allows you to denote <var>variables</var>.', 'Short Article Title', '', 'publish', 'closed', 'closed', '', 'short-article-title-2', '', '', '2017-12-05 20:27:27', '2017-12-06 01:27:27', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/short-article-title-2/', 7, 'portfolio', '', 0),
(81, 1, '2017-12-04 20:27:27', '2017-12-05 01:27:27', 'Welcome to image alignment! The best way to demonstrate the ebb and flow of the various image positioning options is to nestle them snuggly among an ocean of words. Grab a paddle and let\'s get started.\n\nOn the topic of alignment, it should be noted that users can choose from the options of <em>None</em>, <em>Left</em>, <em>Right, </em>and <em>Center</em>. In addition, they also get the options of <em>Thumbnail</em>, <em>Medium</em>, <em>Large</em> &amp; <em>Fullsize</em>.\n<p style="text-align:center;"><img class="size-full wp-image-906 aligncenter" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /></p>\nThe image above happens to be <em><strong>centered</strong></em>.\n\n<strong><img class="size-full wp-image-904 alignleft" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n<img class="alignnone wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" />\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n<img class="size-full wp-image-905 alignright" title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" />\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd just when you thought we were done, we\'re going to do them all over again with captions!\n\n[caption id="attachment_906" align="aligncenter" width="580"]<img class="size-full wp-image-906" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /> Look at 580x300 getting some <a title="Image Settings" href="http://en.support.wordpress.com/images/image-settings/">caption</a> love.[/caption]\n\nThe image above happens to be <em><strong>centered</strong></em>. The caption also has a link in it, just to see if it does anything funky.\n\n[caption id="attachment_904" align="alignleft" width="150"]<img class="size-full wp-image-904" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /> Itty-bitty caption.[/caption]\n\n<strong></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n[caption id="attachment_907" align="alignnone" width="1200"]<img class=" wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" /> Massive image comment for your eyeballs.[/caption]\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n[caption id="attachment_905" align="alignright" width="300"]<img class="size-full wp-image-905 " title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" /> Feels good to be right all the time.[/caption]\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd that\'s a wrap, yo! You survived the tumultuous waters of alignment. Image alignment achievement unlocked!', 'This Is a Fascinating Article About Us', '', 'publish', 'closed', 'closed', '', 'this-is-a-fascinating-article-about-us-2', '', '', '2017-12-04 20:27:27', '2017-12-05 01:27:27', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/this-is-a-fascinating-article-about-us-2/', 8, 'portfolio', '', 0),
(82, 1, '2017-12-03 20:27:27', '2017-12-04 01:27:27', '<h2>Headings</h2>\n<h1>Header one</h1>\n<h2>Header two</h2>\n<h3>Header three</h3>\n<h4>Header four</h4>\n<h5>Header five</h5>\n<h6>Header six</h6>\n<h2>Blockquotes</h2>\nSingle line blockquote:\n<blockquote>Stay hungry. Stay foolish.</blockquote>\nMulti line blockquote with a cite reference:\n<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things.</blockquote>\n<cite>Steve Jobs</cite> - Apple Worldwide Developers\' Conference, 1997\n<h2>Tables</h2>\n<table>\n<thead>\n<tr>\n<th>Employee</th>\n<th>Salary</th>\n<th></th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<th><a href="http://example.org/">John Doe</a></th>\n<td>$1</td>\n<td>Because that\'s all Steve Jobs needed for a salary.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Doe</a></th>\n<td>$100K</td>\n<td>For all the blogging she does.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Fred Bloggs</a></th>\n<td>$100M</td>\n<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Bloggs</a></th>\n<td>$100B</td>\n<td>With hair like that?! Enough said...</td>\n</tr>\n</tbody>\n</table>\n<h2>Definition Lists</h2>\n<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>\n<h2>Unordered Lists (Nested)</h2>\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n<h2>Ordered List (Nested)</h2>\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n<h2>HTML Tags</h2>\nThese supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.\n\n<strong>Address Tag</strong>\n\n<address>1 Infinite Loop\nCupertino, CA 95014\nUnited States</address><strong>Anchor Tag (aka. Link)</strong>\n\nThis is an example of a <a title="Apple" href="http://apple.com">link</a>.\n\n<strong>Abbreviation Tag</strong>\n\nThe abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".\n\n<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>\n\nThe acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".\n\n<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThese tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.\n\n<strong>Cite Tag</strong>\n\n"Code is poetry." --<cite>Automattic</cite>\n\n<strong>Code Tag</strong>\n\nYou will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.\n\n<strong>Delete Tag</strong>\n\nThis tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).\n\n<strong>Emphasize Tag</strong>\n\nThe emphasize tag should <em>italicize</em> text.\n\n<strong>Insert Tag</strong>\n\nThis tag should denote <ins>inserted</ins> text.\n\n<strong>Keyboard Tag</strong>\n\nThis scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Preformatted Tag</strong>\n\nThis tag styles large blocks of code.\n<pre>.post-title {\n	margin: 0 0 5px;\n	font-weight: bold;\n	font-size: 38px;\n	line-height: 1.2;\n	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;\n}</pre>\n<strong>Quote Tag</strong>\n\n<q>Developers, developers, developers...</q> --Steve Ballmer\n\n<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis tag shows <span style="text-decoration: line-through;">strike-through text</span>\n\n<strong>Strong Tag</strong>\n\nThis tag shows <strong>bold<strong> text.</strong></strong>\n\n<strong>Subscript Tag</strong>\n\nGetting our science styling on with H<sub>2</sub>O, which should push the "2" down.\n\n<strong>Superscript Tag</strong>\n\nStill sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.\n\n<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Variable Tag</strong>\n\nThis allows you to denote <var>variables</var>.', 'Post About What Is Happening In Our Industry', '', 'publish', 'closed', 'closed', '', 'post-about-what-is-happening-in-our-industry-2', '', '', '2017-12-03 20:27:27', '2017-12-04 01:27:27', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/post-about-what-is-happening-in-our-industry-2/', 9, 'portfolio', '', 0),
(83, 1, '2017-12-02 20:27:27', '2017-12-03 01:27:27', 'Welcome to image alignment! The best way to demonstrate the ebb and flow of the various image positioning options is to nestle them snuggly among an ocean of words. Grab a paddle and let\'s get started.\n\nOn the topic of alignment, it should be noted that users can choose from the options of <em>None</em>, <em>Left</em>, <em>Right, </em>and <em>Center</em>. In addition, they also get the options of <em>Thumbnail</em>, <em>Medium</em>, <em>Large</em> &amp; <em>Fullsize</em>.\n<p style="text-align:center;"><img class="size-full wp-image-906 aligncenter" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /></p>\nThe image above happens to be <em><strong>centered</strong></em>.\n\n<strong><img class="size-full wp-image-904 alignleft" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n<img class="alignnone wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" />\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n<img class="size-full wp-image-905 alignright" title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" />\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd just when you thought we were done, we\'re going to do them all over again with captions!\n\n[caption id="attachment_906" align="aligncenter" width="580"]<img class="size-full wp-image-906" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /> Look at 580x300 getting some <a title="Image Settings" href="http://en.support.wordpress.com/images/image-settings/">caption</a> love.[/caption]\n\nThe image above happens to be <em><strong>centered</strong></em>. The caption also has a link in it, just to see if it does anything funky.\n\n[caption id="attachment_904" align="alignleft" width="150"]<img class="size-full wp-image-904" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /> Itty-bitty caption.[/caption]\n\n<strong></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n[caption id="attachment_907" align="alignnone" width="1200"]<img class=" wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" /> Massive image comment for your eyeballs.[/caption]\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n[caption id="attachment_905" align="alignright" width="300"]<img class="size-full wp-image-905 " title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" /> Feels good to be right all the time.[/caption]\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd that\'s a wrap, yo! You survived the tumultuous waters of alignment. Image alignment achievement unlocked!', 'Ten Things We Say In Sample Blog Posts', '', 'publish', 'closed', 'closed', '', 'ten-things-we-say-in-sample-blog-posts-2', '', '', '2017-12-02 20:27:27', '2017-12-03 01:27:27', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/ten-things-we-say-in-sample-blog-posts-2/', 10, 'portfolio', '', 0),
(84, 1, '2017-12-01 20:27:27', '2017-12-02 01:27:27', '<h1>Lorem Ipsum</h1>\n\n<blockquote>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit..."\n"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain..."</blockquote>\n\n<h2>What is Lorem Ipsum?</h2>\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<h3>Why do we use it?</h3>\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>', 'This Post Has a Very Long Title and Should Look Great on All Devices', '', 'publish', 'closed', 'closed', '', 'this-post-has-a-very-long-title-and-should-look-great-on-all-devices-3', '', '', '2017-12-01 20:27:27', '2017-12-02 01:27:27', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/this-post-has-a-very-long-title-and-should-look-great-on-all-devices-3/', 11, 'portfolio', '', 0),
(85, 1, '2017-12-11 20:27:32', '2017-12-12 01:27:32', '<h1>Lorem Ipsum</h1>\n\n<blockquote>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit..."\n"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain..."</blockquote>\n\n<h2>What is Lorem Ipsum?</h2>\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<h3>Why do we use it?</h3>\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>', 'This Post Has a Very Long Title and Should Look Great on All Devices', '', 'publish', 'closed', 'closed', '', 'this-post-has-a-very-long-title-and-should-look-great-on-all-devices-4', '', '', '2017-12-11 20:27:32', '2017-12-12 01:27:32', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/this-post-has-a-very-long-title-and-should-look-great-on-all-devices-4/', 1, 'portfolio', '', 0),
(86, 1, '2017-12-12 15:27:32', '2017-12-12 20:27:32', '', 'Sample Image #1', '', 'inherit', 'closed', 'closed', '', 'sample-image-1-3', '', '', '2017-12-12 18:43:07', '2017-12-12 23:43:07', '', 85, 'http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/unsplash-8.jpeg', 0, 'attachment', 'image/jpeg', 0),
(87, 1, '2017-12-10 20:27:33', '2017-12-11 01:27:33', 'Welcome to image alignment! The best way to demonstrate the ebb and flow of the various image positioning options is to nestle them snuggly among an ocean of words. Grab a paddle and let\'s get started.\n\nOn the topic of alignment, it should be noted that users can choose from the options of <em>None</em>, <em>Left</em>, <em>Right, </em>and <em>Center</em>. In addition, they also get the options of <em>Thumbnail</em>, <em>Medium</em>, <em>Large</em> &amp; <em>Fullsize</em>.\n<p style="text-align:center;"><img class="size-full wp-image-906 aligncenter" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /></p>\nThe image above happens to be <em><strong>centered</strong></em>.\n\n<strong><img class="size-full wp-image-904 alignleft" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n<img class="alignnone wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" />\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n<img class="size-full wp-image-905 alignright" title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" />\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd just when you thought we were done, we\'re going to do them all over again with captions!\n\n[caption id="attachment_906" align="aligncenter" width="580"]<img class="size-full wp-image-906" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /> Look at 580x300 getting some <a title="Image Settings" href="http://en.support.wordpress.com/images/image-settings/">caption</a> love.[/caption]\n\nThe image above happens to be <em><strong>centered</strong></em>. The caption also has a link in it, just to see if it does anything funky.\n\n[caption id="attachment_904" align="alignleft" width="150"]<img class="size-full wp-image-904" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /> Itty-bitty caption.[/caption]\n\n<strong></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n[caption id="attachment_907" align="alignnone" width="1200"]<img class=" wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" /> Massive image comment for your eyeballs.[/caption]\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n[caption id="attachment_905" align="alignright" width="300"]<img class="size-full wp-image-905 " title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" /> Feels good to be right all the time.[/caption]\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd that\'s a wrap, yo! You survived the tumultuous waters of alignment. Image alignment achievement unlocked!', 'Short Article Title', '', 'publish', 'closed', 'closed', '', 'short-article-title-3', '', '', '2017-12-10 20:27:33', '2017-12-11 01:27:33', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/short-article-title-3/', 2, 'portfolio', '', 0),
(88, 1, '2017-12-09 20:27:33', '2017-12-10 01:27:33', 'Welcome to image alignment! The best way to demonstrate the ebb and flow of the various image positioning options is to nestle them snuggly among an ocean of words. Grab a paddle and let\'s get started.\n\nOn the topic of alignment, it should be noted that users can choose from the options of <em>None</em>, <em>Left</em>, <em>Right, </em>and <em>Center</em>. In addition, they also get the options of <em>Thumbnail</em>, <em>Medium</em>, <em>Large</em> &amp; <em>Fullsize</em>.\n<p style="text-align:center;"><img class="size-full wp-image-906 aligncenter" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /></p>\nThe image above happens to be <em><strong>centered</strong></em>.\n\n<strong><img class="size-full wp-image-904 alignleft" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n<img class="alignnone wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" />\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n<img class="size-full wp-image-905 alignright" title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" />\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd just when you thought we were done, we\'re going to do them all over again with captions!\n\n[caption id="attachment_906" align="aligncenter" width="580"]<img class="size-full wp-image-906" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /> Look at 580x300 getting some <a title="Image Settings" href="http://en.support.wordpress.com/images/image-settings/">caption</a> love.[/caption]\n\nThe image above happens to be <em><strong>centered</strong></em>. The caption also has a link in it, just to see if it does anything funky.\n\n[caption id="attachment_904" align="alignleft" width="150"]<img class="size-full wp-image-904" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /> Itty-bitty caption.[/caption]\n\n<strong></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n[caption id="attachment_907" align="alignnone" width="1200"]<img class=" wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" /> Massive image comment for your eyeballs.[/caption]\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n[caption id="attachment_905" align="alignright" width="300"]<img class="size-full wp-image-905 " title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" /> Feels good to be right all the time.[/caption]\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd that\'s a wrap, yo! You survived the tumultuous waters of alignment. Image alignment achievement unlocked!', 'This Is a Fascinating Article About Us', '', 'publish', 'closed', 'closed', '', 'this-is-a-fascinating-article-about-us-3', '', '', '2017-12-09 20:27:33', '2017-12-10 01:27:33', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/this-is-a-fascinating-article-about-us-3/', 3, 'portfolio', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(89, 1, '2017-12-08 20:27:33', '2017-12-09 01:27:33', '<h2>Headings</h2>\n<h1>Header one</h1>\n<h2>Header two</h2>\n<h3>Header three</h3>\n<h4>Header four</h4>\n<h5>Header five</h5>\n<h6>Header six</h6>\n<h2>Blockquotes</h2>\nSingle line blockquote:\n<blockquote>Stay hungry. Stay foolish.</blockquote>\nMulti line blockquote with a cite reference:\n<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things.</blockquote>\n<cite>Steve Jobs</cite> - Apple Worldwide Developers\' Conference, 1997\n<h2>Tables</h2>\n<table>\n<thead>\n<tr>\n<th>Employee</th>\n<th>Salary</th>\n<th></th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<th><a href="http://example.org/">John Doe</a></th>\n<td>$1</td>\n<td>Because that\'s all Steve Jobs needed for a salary.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Doe</a></th>\n<td>$100K</td>\n<td>For all the blogging she does.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Fred Bloggs</a></th>\n<td>$100M</td>\n<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Bloggs</a></th>\n<td>$100B</td>\n<td>With hair like that?! Enough said...</td>\n</tr>\n</tbody>\n</table>\n<h2>Definition Lists</h2>\n<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>\n<h2>Unordered Lists (Nested)</h2>\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n<h2>Ordered List (Nested)</h2>\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n<h2>HTML Tags</h2>\nThese supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.\n\n<strong>Address Tag</strong>\n\n<address>1 Infinite Loop\nCupertino, CA 95014\nUnited States</address><strong>Anchor Tag (aka. Link)</strong>\n\nThis is an example of a <a title="Apple" href="http://apple.com">link</a>.\n\n<strong>Abbreviation Tag</strong>\n\nThe abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".\n\n<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>\n\nThe acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".\n\n<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThese tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.\n\n<strong>Cite Tag</strong>\n\n"Code is poetry." --<cite>Automattic</cite>\n\n<strong>Code Tag</strong>\n\nYou will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.\n\n<strong>Delete Tag</strong>\n\nThis tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).\n\n<strong>Emphasize Tag</strong>\n\nThe emphasize tag should <em>italicize</em> text.\n\n<strong>Insert Tag</strong>\n\nThis tag should denote <ins>inserted</ins> text.\n\n<strong>Keyboard Tag</strong>\n\nThis scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Preformatted Tag</strong>\n\nThis tag styles large blocks of code.\n<pre>.post-title {\n	margin: 0 0 5px;\n	font-weight: bold;\n	font-size: 38px;\n	line-height: 1.2;\n	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;\n}</pre>\n<strong>Quote Tag</strong>\n\n<q>Developers, developers, developers...</q> --Steve Ballmer\n\n<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis tag shows <span style="text-decoration: line-through;">strike-through text</span>\n\n<strong>Strong Tag</strong>\n\nThis tag shows <strong>bold<strong> text.</strong></strong>\n\n<strong>Subscript Tag</strong>\n\nGetting our science styling on with H<sub>2</sub>O, which should push the "2" down.\n\n<strong>Superscript Tag</strong>\n\nStill sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.\n\n<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Variable Tag</strong>\n\nThis allows you to denote <var>variables</var>.', 'Post About What Is Happening In Our Industry', '', 'publish', 'closed', 'closed', '', 'post-about-what-is-happening-in-our-industry-3', '', '', '2017-12-08 20:27:33', '2017-12-09 01:27:33', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/post-about-what-is-happening-in-our-industry-3/', 4, 'portfolio', '', 0),
(90, 1, '2017-12-12 15:27:33', '2017-12-12 20:27:33', '', 'Sample Image #4', '', 'inherit', 'closed', 'closed', '', 'sample-image-4-2', '', '', '2017-12-12 16:02:39', '2017-12-12 21:02:39', '', 89, 'http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/unsplash-9.jpeg', 0, 'attachment', 'image/jpeg', 0),
(91, 1, '2017-12-07 20:27:33', '2017-12-08 01:27:33', '<h1>Lorem Ipsum</h1>\n\n<blockquote>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit..."\n"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain..."</blockquote>\n\n<h2>What is Lorem Ipsum?</h2>\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<h3>Why do we use it?</h3>\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>', 'Ten Things We Say In Sample Blog Posts', '', 'publish', 'closed', 'closed', '', 'ten-things-we-say-in-sample-blog-posts-3', '', '', '2017-12-07 20:27:33', '2017-12-08 01:27:33', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/ten-things-we-say-in-sample-blog-posts-3/', 5, 'portfolio', '', 0),
(92, 1, '2017-12-06 20:27:33', '2017-12-07 01:27:33', 'Welcome to image alignment! The best way to demonstrate the ebb and flow of the various image positioning options is to nestle them snuggly among an ocean of words. Grab a paddle and let\'s get started.\n\nOn the topic of alignment, it should be noted that users can choose from the options of <em>None</em>, <em>Left</em>, <em>Right, </em>and <em>Center</em>. In addition, they also get the options of <em>Thumbnail</em>, <em>Medium</em>, <em>Large</em> &amp; <em>Fullsize</em>.\n<p style="text-align:center;"><img class="size-full wp-image-906 aligncenter" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /></p>\nThe image above happens to be <em><strong>centered</strong></em>.\n\n<strong><img class="size-full wp-image-904 alignleft" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n<img class="alignnone wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" />\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n<img class="size-full wp-image-905 alignright" title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" />\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd just when you thought we were done, we\'re going to do them all over again with captions!\n\n[caption id="attachment_906" align="aligncenter" width="580"]<img class="size-full wp-image-906" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /> Look at 580x300 getting some <a title="Image Settings" href="http://en.support.wordpress.com/images/image-settings/">caption</a> love.[/caption]\n\nThe image above happens to be <em><strong>centered</strong></em>. The caption also has a link in it, just to see if it does anything funky.\n\n[caption id="attachment_904" align="alignleft" width="150"]<img class="size-full wp-image-904" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /> Itty-bitty caption.[/caption]\n\n<strong></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n[caption id="attachment_907" align="alignnone" width="1200"]<img class=" wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" /> Massive image comment for your eyeballs.[/caption]\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n[caption id="attachment_905" align="alignright" width="300"]<img class="size-full wp-image-905 " title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" /> Feels good to be right all the time.[/caption]\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd that\'s a wrap, yo! You survived the tumultuous waters of alignment. Image alignment achievement unlocked!', 'This Post Has a Very Long Title and Should Look Great on All Devices', '', 'publish', 'closed', 'closed', '', 'this-post-has-a-very-long-title-and-should-look-great-on-all-devices-5', '', '', '2017-12-06 20:27:33', '2017-12-07 01:27:33', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/this-post-has-a-very-long-title-and-should-look-great-on-all-devices-5/', 6, 'portfolio', '', 0),
(93, 1, '2017-12-05 20:27:33', '2017-12-06 01:27:33', 'Welcome to image alignment! The best way to demonstrate the ebb and flow of the various image positioning options is to nestle them snuggly among an ocean of words. Grab a paddle and let\'s get started.\n\nOn the topic of alignment, it should be noted that users can choose from the options of <em>None</em>, <em>Left</em>, <em>Right, </em>and <em>Center</em>. In addition, they also get the options of <em>Thumbnail</em>, <em>Medium</em>, <em>Large</em> &amp; <em>Fullsize</em>.\n<p style="text-align:center;"><img class="size-full wp-image-906 aligncenter" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /></p>\nThe image above happens to be <em><strong>centered</strong></em>.\n\n<strong><img class="size-full wp-image-904 alignleft" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n<img class="alignnone wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" />\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n<img class="size-full wp-image-905 alignright" title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" />\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd just when you thought we were done, we\'re going to do them all over again with captions!\n\n[caption id="attachment_906" align="aligncenter" width="580"]<img class="size-full wp-image-906" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /> Look at 580x300 getting some <a title="Image Settings" href="http://en.support.wordpress.com/images/image-settings/">caption</a> love.[/caption]\n\nThe image above happens to be <em><strong>centered</strong></em>. The caption also has a link in it, just to see if it does anything funky.\n\n[caption id="attachment_904" align="alignleft" width="150"]<img class="size-full wp-image-904" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /> Itty-bitty caption.[/caption]\n\n<strong></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n[caption id="attachment_907" align="alignnone" width="1200"]<img class=" wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" /> Massive image comment for your eyeballs.[/caption]\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n[caption id="attachment_905" align="alignright" width="300"]<img class="size-full wp-image-905 " title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" /> Feels good to be right all the time.[/caption]\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd that\'s a wrap, yo! You survived the tumultuous waters of alignment. Image alignment achievement unlocked!', 'Short Article Title', '', 'publish', 'closed', 'closed', '', 'short-article-title-4', '', '', '2017-12-05 20:27:33', '2017-12-06 01:27:33', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/short-article-title-4/', 7, 'portfolio', '', 0),
(94, 1, '2017-12-04 20:27:33', '2017-12-05 01:27:33', 'Welcome to image alignment! The best way to demonstrate the ebb and flow of the various image positioning options is to nestle them snuggly among an ocean of words. Grab a paddle and let\'s get started.\n\nOn the topic of alignment, it should be noted that users can choose from the options of <em>None</em>, <em>Left</em>, <em>Right, </em>and <em>Center</em>. In addition, they also get the options of <em>Thumbnail</em>, <em>Medium</em>, <em>Large</em> &amp; <em>Fullsize</em>.\n<p style="text-align:center;"><img class="size-full wp-image-906 aligncenter" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /></p>\nThe image above happens to be <em><strong>centered</strong></em>.\n\n<strong><img class="size-full wp-image-904 alignleft" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n<img class="alignnone wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" />\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n<img class="size-full wp-image-905 alignright" title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" />\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd just when you thought we were done, we\'re going to do them all over again with captions!\n\n[caption id="attachment_906" align="aligncenter" width="580"]<img class="size-full wp-image-906" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /> Look at 580x300 getting some <a title="Image Settings" href="http://en.support.wordpress.com/images/image-settings/">caption</a> love.[/caption]\n\nThe image above happens to be <em><strong>centered</strong></em>. The caption also has a link in it, just to see if it does anything funky.\n\n[caption id="attachment_904" align="alignleft" width="150"]<img class="size-full wp-image-904" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /> Itty-bitty caption.[/caption]\n\n<strong></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n[caption id="attachment_907" align="alignnone" width="1200"]<img class=" wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" /> Massive image comment for your eyeballs.[/caption]\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n[caption id="attachment_905" align="alignright" width="300"]<img class="size-full wp-image-905 " title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" /> Feels good to be right all the time.[/caption]\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd that\'s a wrap, yo! You survived the tumultuous waters of alignment. Image alignment achievement unlocked!', 'This Is a Fascinating Article About Us', '', 'publish', 'closed', 'closed', '', 'this-is-a-fascinating-article-about-us-4', '', '', '2017-12-04 20:27:33', '2017-12-05 01:27:33', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/this-is-a-fascinating-article-about-us-4/', 8, 'portfolio', '', 0),
(95, 1, '2017-12-12 15:27:33', '2017-12-12 20:27:33', '', 'Sample Image #8', '', 'inherit', 'closed', 'closed', '', 'sample-image-8', '', '', '2017-12-12 19:39:32', '2017-12-13 00:39:32', '', 94, 'http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/unsplash-10.jpeg', 0, 'attachment', 'image/jpeg', 0),
(96, 1, '2017-12-03 20:27:33', '2017-12-04 01:27:33', 'Welcome to image alignment! The best way to demonstrate the ebb and flow of the various image positioning options is to nestle them snuggly among an ocean of words. Grab a paddle and let\'s get started.\n\nOn the topic of alignment, it should be noted that users can choose from the options of <em>None</em>, <em>Left</em>, <em>Right, </em>and <em>Center</em>. In addition, they also get the options of <em>Thumbnail</em>, <em>Medium</em>, <em>Large</em> &amp; <em>Fullsize</em>.\n<p style="text-align:center;"><img class="size-full wp-image-906 aligncenter" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /></p>\nThe image above happens to be <em><strong>centered</strong></em>.\n\n<strong><img class="size-full wp-image-904 alignleft" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n<img class="alignnone wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" />\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n<img class="size-full wp-image-905 alignright" title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" />\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd just when you thought we were done, we\'re going to do them all over again with captions!\n\n[caption id="attachment_906" align="aligncenter" width="580"]<img class="size-full wp-image-906" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /> Look at 580x300 getting some <a title="Image Settings" href="http://en.support.wordpress.com/images/image-settings/">caption</a> love.[/caption]\n\nThe image above happens to be <em><strong>centered</strong></em>. The caption also has a link in it, just to see if it does anything funky.\n\n[caption id="attachment_904" align="alignleft" width="150"]<img class="size-full wp-image-904" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /> Itty-bitty caption.[/caption]\n\n<strong></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n[caption id="attachment_907" align="alignnone" width="1200"]<img class=" wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" /> Massive image comment for your eyeballs.[/caption]\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n[caption id="attachment_905" align="alignright" width="300"]<img class="size-full wp-image-905 " title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" /> Feels good to be right all the time.[/caption]\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd that\'s a wrap, yo! You survived the tumultuous waters of alignment. Image alignment achievement unlocked!', 'Post About What Is Happening In Our Industry', '', 'publish', 'closed', 'closed', '', 'post-about-what-is-happening-in-our-industry-4', '', '', '2017-12-03 20:27:33', '2017-12-04 01:27:33', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/post-about-what-is-happening-in-our-industry-4/', 9, 'portfolio', '', 0),
(97, 1, '2017-12-02 20:27:33', '2017-12-03 01:27:33', '<h2>Headings</h2>\n<h1>Header one</h1>\n<h2>Header two</h2>\n<h3>Header three</h3>\n<h4>Header four</h4>\n<h5>Header five</h5>\n<h6>Header six</h6>\n<h2>Blockquotes</h2>\nSingle line blockquote:\n<blockquote>Stay hungry. Stay foolish.</blockquote>\nMulti line blockquote with a cite reference:\n<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things.</blockquote>\n<cite>Steve Jobs</cite> - Apple Worldwide Developers\' Conference, 1997\n<h2>Tables</h2>\n<table>\n<thead>\n<tr>\n<th>Employee</th>\n<th>Salary</th>\n<th></th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<th><a href="http://example.org/">John Doe</a></th>\n<td>$1</td>\n<td>Because that\'s all Steve Jobs needed for a salary.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Doe</a></th>\n<td>$100K</td>\n<td>For all the blogging she does.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Fred Bloggs</a></th>\n<td>$100M</td>\n<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Bloggs</a></th>\n<td>$100B</td>\n<td>With hair like that?! Enough said...</td>\n</tr>\n</tbody>\n</table>\n<h2>Definition Lists</h2>\n<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>\n<h2>Unordered Lists (Nested)</h2>\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n<h2>Ordered List (Nested)</h2>\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n<h2>HTML Tags</h2>\nThese supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.\n\n<strong>Address Tag</strong>\n\n<address>1 Infinite Loop\nCupertino, CA 95014\nUnited States</address><strong>Anchor Tag (aka. Link)</strong>\n\nThis is an example of a <a title="Apple" href="http://apple.com">link</a>.\n\n<strong>Abbreviation Tag</strong>\n\nThe abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".\n\n<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>\n\nThe acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".\n\n<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThese tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.\n\n<strong>Cite Tag</strong>\n\n"Code is poetry." --<cite>Automattic</cite>\n\n<strong>Code Tag</strong>\n\nYou will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.\n\n<strong>Delete Tag</strong>\n\nThis tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).\n\n<strong>Emphasize Tag</strong>\n\nThe emphasize tag should <em>italicize</em> text.\n\n<strong>Insert Tag</strong>\n\nThis tag should denote <ins>inserted</ins> text.\n\n<strong>Keyboard Tag</strong>\n\nThis scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Preformatted Tag</strong>\n\nThis tag styles large blocks of code.\n<pre>.post-title {\n	margin: 0 0 5px;\n	font-weight: bold;\n	font-size: 38px;\n	line-height: 1.2;\n	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;\n}</pre>\n<strong>Quote Tag</strong>\n\n<q>Developers, developers, developers...</q> --Steve Ballmer\n\n<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis tag shows <span style="text-decoration: line-through;">strike-through text</span>\n\n<strong>Strong Tag</strong>\n\nThis tag shows <strong>bold<strong> text.</strong></strong>\n\n<strong>Subscript Tag</strong>\n\nGetting our science styling on with H<sub>2</sub>O, which should push the "2" down.\n\n<strong>Superscript Tag</strong>\n\nStill sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.\n\n<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Variable Tag</strong>\n\nThis allows you to denote <var>variables</var>.', 'Ten Things We Say In Sample Blog Posts', '', 'publish', 'closed', 'closed', '', 'ten-things-we-say-in-sample-blog-posts-4', '', '', '2017-12-02 20:27:33', '2017-12-03 01:27:33', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/ten-things-we-say-in-sample-blog-posts-4/', 10, 'portfolio', '', 0),
(98, 1, '2017-12-01 20:27:33', '2017-12-02 01:27:33', '<h2>Headings</h2>\n<h1>Header one</h1>\n<h2>Header two</h2>\n<h3>Header three</h3>\n<h4>Header four</h4>\n<h5>Header five</h5>\n<h6>Header six</h6>\n<h2>Blockquotes</h2>\nSingle line blockquote:\n<blockquote>Stay hungry. Stay foolish.</blockquote>\nMulti line blockquote with a cite reference:\n<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things.</blockquote>\n<cite>Steve Jobs</cite> - Apple Worldwide Developers\' Conference, 1997\n<h2>Tables</h2>\n<table>\n<thead>\n<tr>\n<th>Employee</th>\n<th>Salary</th>\n<th></th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<th><a href="http://example.org/">John Doe</a></th>\n<td>$1</td>\n<td>Because that\'s all Steve Jobs needed for a salary.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Doe</a></th>\n<td>$100K</td>\n<td>For all the blogging she does.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Fred Bloggs</a></th>\n<td>$100M</td>\n<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Bloggs</a></th>\n<td>$100B</td>\n<td>With hair like that?! Enough said...</td>\n</tr>\n</tbody>\n</table>\n<h2>Definition Lists</h2>\n<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>\n<h2>Unordered Lists (Nested)</h2>\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n<h2>Ordered List (Nested)</h2>\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n<h2>HTML Tags</h2>\nThese supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.\n\n<strong>Address Tag</strong>\n\n<address>1 Infinite Loop\nCupertino, CA 95014\nUnited States</address><strong>Anchor Tag (aka. Link)</strong>\n\nThis is an example of a <a title="Apple" href="http://apple.com">link</a>.\n\n<strong>Abbreviation Tag</strong>\n\nThe abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".\n\n<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>\n\nThe acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".\n\n<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThese tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.\n\n<strong>Cite Tag</strong>\n\n"Code is poetry." --<cite>Automattic</cite>\n\n<strong>Code Tag</strong>\n\nYou will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.\n\n<strong>Delete Tag</strong>\n\nThis tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).\n\n<strong>Emphasize Tag</strong>\n\nThe emphasize tag should <em>italicize</em> text.\n\n<strong>Insert Tag</strong>\n\nThis tag should denote <ins>inserted</ins> text.\n\n<strong>Keyboard Tag</strong>\n\nThis scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Preformatted Tag</strong>\n\nThis tag styles large blocks of code.\n<pre>.post-title {\n	margin: 0 0 5px;\n	font-weight: bold;\n	font-size: 38px;\n	line-height: 1.2;\n	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;\n}</pre>\n<strong>Quote Tag</strong>\n\n<q>Developers, developers, developers...</q> --Steve Ballmer\n\n<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis tag shows <span style="text-decoration: line-through;">strike-through text</span>\n\n<strong>Strong Tag</strong>\n\nThis tag shows <strong>bold<strong> text.</strong></strong>\n\n<strong>Subscript Tag</strong>\n\nGetting our science styling on with H<sub>2</sub>O, which should push the "2" down.\n\n<strong>Superscript Tag</strong>\n\nStill sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.\n\n<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Variable Tag</strong>\n\nThis allows you to denote <var>variables</var>.', 'This Post Has a Very Long Title and Should Look Great on All Devices', '', 'publish', 'closed', 'closed', '', 'this-post-has-a-very-long-title-and-should-look-great-on-all-devices-6', '', '', '2017-12-01 20:27:33', '2017-12-02 01:27:33', '', 0, 'http://localhost/joekrollbuilder.com/portfolio/this-post-has-a-very-long-title-and-should-look-great-on-all-devices-6/', 11, 'portfolio', '', 0),
(99, 1, '2017-12-12 15:28:25', '2017-12-12 20:28:25', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"page_type";s:8:"operator";s:2:"==";s:5:"value";s:10:"front_page";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Home page fields', 'home-page-fields', 'publish', 'closed', 'closed', '', 'group_5a303bde1abde', '', '', '2017-12-12 15:51:41', '2017-12-12 20:51:41', '', 0, 'http://localhost/joekrollbuilder.com/?post_type=acf-field-group&#038;p=99', 0, 'acf-field-group', '', 0),
(100, 1, '2017-12-12 15:32:32', '2017-12-12 20:32:32', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"block";s:12:"button_label";s:9:"Add Slide";}', 'Hero slides', 'hero_slides', 'publish', 'closed', 'closed', '', 'field_5a303bf5e8f78', '', '', '2017-12-12 15:33:35', '2017-12-12 20:33:35', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=100', 1, 'acf-field', '', 0),
(101, 1, '2017-12-12 15:32:32', '2017-12-12 20:32:32', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:12:"medium_large";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Hero Slide Image', 'hero_slide_image', 'publish', 'closed', 'closed', '', 'field_5a303c34e8f79', '', '', '2017-12-12 15:32:32', '2017-12-12 20:32:32', '', 100, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=101', 0, 'acf-field', '', 0),
(102, 1, '2017-12-12 15:32:32', '2017-12-12 20:32:32', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Hero Slide Title', 'hero_slide_title', 'publish', 'closed', 'closed', '', 'field_5a303c7fe8f7a', '', '', '2017-12-12 15:32:32', '2017-12-12 20:32:32', '', 100, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=102', 1, 'acf-field', '', 0),
(103, 1, '2017-12-12 15:32:32', '2017-12-12 20:32:32', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Hero Slide Type', 'hero_slide_type', 'publish', 'closed', 'closed', '', 'field_5a303c91e8f7b', '', '', '2017-12-12 15:32:32', '2017-12-12 20:32:32', '', 100, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=103', 2, 'acf-field', '', 0),
(104, 1, '2017-12-12 15:32:32', '2017-12-12 20:32:32', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Hero Slide Location', 'hero_slide_location', 'publish', 'closed', 'closed', '', 'field_5a303ca2e8f7c', '', '', '2017-12-12 15:32:32', '2017-12-12 20:32:32', '', 100, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=104', 3, 'acf-field', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(105, 1, '2017-12-12 15:32:32', '2017-12-12 20:32:32', 'a:10:{s:4:"type";s:9:"page_link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:0:{}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:0;s:14:"allow_archives";i:1;s:8:"multiple";i:0;}', 'Hero Slide Link', 'hero_slide_link', 'publish', 'closed', 'closed', '', 'field_5a303cc3e8f7d', '', '', '2017-12-12 15:32:32', '2017-12-12 20:32:32', '', 100, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=105', 4, 'acf-field', '', 0),
(106, 1, '2017-12-12 15:32:48', '2017-12-12 20:32:48', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Hero slider', '', 'publish', 'closed', 'closed', '', 'field_5a303ce3d62c8', '', '', '2017-12-12 15:32:48', '2017-12-12 20:32:48', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=106', 0, 'acf-field', '', 0),
(107, 1, '2017-12-12 15:33:50', '2017-12-12 20:33:50', '', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2017-12-12 15:33:50', '2017-12-12 20:33:50', '', 4, 'http://localhost/joekrollbuilder.com/4-revision-v1/', 0, 'revision', '', 0),
(108, 1, '2017-12-12 15:37:39', '2017-12-12 20:37:39', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Intro section', 'intro_section', 'publish', 'closed', 'closed', '', 'field_5a303d6baa8fd', '', '', '2017-12-12 15:39:06', '2017-12-12 20:39:06', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=108', 2, 'acf-field', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(109, 1, '2017-12-12 15:37:39', '2017-12-12 20:37:39', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Intro section title', 'intro_section_title', 'publish', 'closed', 'closed', '', 'field_5a303dc5aa8fe', '', '', '2017-12-12 15:39:06', '2017-12-12 20:39:06', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=109', 3, 'acf-field', '', 0),
(110, 1, '2017-12-12 15:37:39', '2017-12-12 20:37:39', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Intro section text', 'intro_section_text', 'publish', 'closed', 'closed', '', 'field_5a303dd3aa8ff', '', '', '2017-12-12 15:39:06', '2017-12-12 20:39:06', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=110', 4, 'acf-field', '', 0),
(111, 1, '2017-12-12 15:37:39', '2017-12-12 20:37:39', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Intro section link text', 'intro_section_link_text', 'publish', 'closed', 'closed', '', 'field_5a303de8aa900', '', '', '2017-12-12 15:39:06', '2017-12-12 20:39:06', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=111', 5, 'acf-field', '', 0),
(112, 1, '2017-12-12 15:37:39', '2017-12-12 20:37:39', 'a:10:{s:4:"type";s:9:"page_link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:0:{}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:0;s:14:"allow_archives";i:1;s:8:"multiple";i:0;}', 'Intro section link', 'intro_section_link', 'publish', 'closed', 'closed', '', 'field_5a303e01aa901', '', '', '2017-12-12 15:39:06', '2017-12-12 20:39:06', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=112', 6, 'acf-field', '', 0),
(113, 1, '2017-12-12 15:42:41', '2017-12-12 20:42:41', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'About section', '', 'publish', 'closed', 'closed', '', 'field_5a303e71f153c', '', '', '2017-12-12 15:42:41', '2017-12-12 20:42:41', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=113', 7, 'acf-field', '', 0),
(114, 1, '2017-12-12 15:42:41', '2017-12-12 20:42:41', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'About section title', 'about_section_title', 'publish', 'closed', 'closed', '', 'field_5a303ea8f153d', '', '', '2017-12-12 15:42:41', '2017-12-12 20:42:41', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=114', 8, 'acf-field', '', 0),
(115, 1, '2017-12-12 15:42:41', '2017-12-12 20:42:41', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'About section text', 'about_section_text', 'publish', 'closed', 'closed', '', 'field_5a303eb1f153e', '', '', '2017-12-12 15:42:41', '2017-12-12 20:42:41', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=115', 9, 'acf-field', '', 0),
(116, 1, '2017-12-12 15:42:41', '2017-12-12 20:42:41', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'About section link text', 'about_section_link_text', 'publish', 'closed', 'closed', '', 'field_5a303ec0f153f', '', '', '2017-12-12 15:42:41', '2017-12-12 20:42:41', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=116', 10, 'acf-field', '', 0),
(117, 1, '2017-12-12 15:42:41', '2017-12-12 20:42:41', 'a:10:{s:4:"type";s:9:"page_link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:0:{}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:0;s:14:"allow_archives";i:1;s:8:"multiple";i:0;}', 'About section link', 'about_section_link', 'publish', 'closed', 'closed', '', 'field_5a303ecff1540', '', '', '2017-12-12 15:51:41', '2017-12-12 20:51:41', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=117', 11, 'acf-field', '', 0),
(118, 1, '2017-12-12 15:42:41', '2017-12-12 20:42:41', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:12:"medium_large";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'About section image', 'about_section_image', 'publish', 'closed', 'closed', '', 'field_5a303ee0f1541', '', '', '2017-12-12 15:42:41', '2017-12-12 20:42:41', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=118', 12, 'acf-field', '', 0),
(119, 1, '2017-12-12 15:42:41', '2017-12-12 20:42:41', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Joes partners', 'joes_partners', 'publish', 'closed', 'closed', '', 'field_5a303efaf1542', '', '', '2017-12-12 15:42:41', '2017-12-12 20:42:41', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=119', 13, 'acf-field', '', 0),
(120, 1, '2017-12-12 15:42:41', '2017-12-12 20:42:41', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Partner name', 'partner_name', 'publish', 'closed', 'closed', '', 'field_5a303f1df1543', '', '', '2017-12-12 15:42:41', '2017-12-12 20:42:41', '', 119, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=120', 0, 'acf-field', '', 0),
(121, 1, '2017-12-12 15:42:41', '2017-12-12 20:42:41', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Joes partners link text', 'joes_partners_link_text', 'publish', 'closed', 'closed', '', 'field_5a303f29f1544', '', '', '2017-12-12 15:42:41', '2017-12-12 20:42:41', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=121', 14, 'acf-field', '', 0),
(122, 1, '2017-12-12 15:42:41', '2017-12-12 20:42:41', 'a:10:{s:4:"type";s:9:"page_link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:0:{}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:0;s:14:"allow_archives";i:1;s:8:"multiple";i:0;}', 'Joes partners link', 'joes_partners_link', 'publish', 'closed', 'closed', '', 'field_5a303f32f1545', '', '', '2017-12-12 15:51:41', '2017-12-12 20:51:41', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=122', 15, 'acf-field', '', 0),
(123, 1, '2017-12-12 15:44:43', '2017-12-12 20:44:43', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'How it works section', '', 'publish', 'closed', 'closed', '', 'field_5a303f5b8330a', '', '', '2017-12-12 15:51:41', '2017-12-12 20:51:41', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=123', 16, 'acf-field', '', 0),
(124, 1, '2017-12-12 15:44:43', '2017-12-12 20:44:43', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'How it works title', 'how_it_works_title', 'publish', 'closed', 'closed', '', 'field_5a303f6a8330b', '', '', '2017-12-12 15:51:41', '2017-12-12 20:51:41', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=124', 17, 'acf-field', '', 0),
(125, 1, '2017-12-12 15:44:43', '2017-12-12 20:44:43', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'How it works text', 'how_it_works_text', 'publish', 'closed', 'closed', '', 'field_5a303f768330c', '', '', '2017-12-12 15:51:41', '2017-12-12 20:51:41', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=125', 18, 'acf-field', '', 0),
(126, 1, '2017-12-12 15:44:43', '2017-12-12 20:44:43', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'How it works steps', 'how_it_works_steps', 'publish', 'closed', 'closed', '', 'field_5a303f818330d', '', '', '2017-12-12 15:51:41', '2017-12-12 20:51:41', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=126', 19, 'acf-field', '', 0),
(127, 1, '2017-12-12 15:44:43', '2017-12-12 20:44:43', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Step icon', 'step_icon', 'publish', 'closed', 'closed', '', 'field_5a303fa08330e', '', '', '2017-12-12 15:44:43', '2017-12-12 20:44:43', '', 126, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=127', 0, 'acf-field', '', 0),
(128, 1, '2017-12-12 15:44:43', '2017-12-12 20:44:43', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Step text', 'step_text', 'publish', 'closed', 'closed', '', 'field_5a303faf8330f', '', '', '2017-12-12 15:44:43', '2017-12-12 20:44:43', '', 126, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=128', 1, 'acf-field', '', 0),
(129, 1, '2017-12-12 15:45:26', '2017-12-12 20:45:26', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'How it works link text', 'how_it_works_link_text', 'publish', 'closed', 'closed', '', 'field_5a303fce8e468', '', '', '2017-12-12 15:51:41', '2017-12-12 20:51:41', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=129', 20, 'acf-field', '', 0),
(130, 1, '2017-12-12 15:45:26', '2017-12-12 20:45:26', 'a:10:{s:4:"type";s:9:"page_link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:0:{}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:0;s:14:"allow_archives";i:1;s:8:"multiple";i:0;}', 'How it works link', 'how_it_works_link', 'publish', 'closed', 'closed', '', 'field_5a303fd78e469', '', '', '2017-12-12 15:51:41', '2017-12-12 20:51:41', '', 99, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=130', 21, 'acf-field', '', 0),
(131, 1, '2017-12-12 15:46:35', '2017-12-12 20:46:35', '', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2017-12-12 15:46:35', '2017-12-12 20:46:35', '', 4, 'http://localhost/joekrollbuilder.com/4-revision-v1/', 0, 'revision', '', 0),
(132, 1, '2017-12-12 15:48:32', '2017-12-12 20:48:32', '', 'joe', '', 'inherit', 'closed', 'closed', '', 'joe-2', '', '', '2017-12-12 15:48:32', '2017-12-12 20:48:32', '', 4, 'http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/joe-1.png', 0, 'attachment', 'image/png', 0),
(133, 1, '2017-12-12 15:51:05', '2017-12-12 20:51:05', '', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2017-12-12 15:51:05', '2017-12-12 20:51:05', '', 4, 'http://localhost/joekrollbuilder.com/4-revision-v1/', 0, 'revision', '', 0),
(134, 1, '2017-12-12 15:52:04', '2017-12-12 20:52:04', '', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2017-12-12 15:52:04', '2017-12-12 20:52:04', '', 4, 'http://localhost/joekrollbuilder.com/4-revision-v1/', 0, 'revision', '', 0),
(135, 1, '2017-12-12 15:53:37', '2017-12-12 20:53:37', '', 'step-1', '', 'inherit', 'closed', 'closed', '', 'step-1', '', '', '2017-12-12 15:53:37', '2017-12-12 20:53:37', '', 4, 'http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/step-1.svg', 0, 'attachment', 'image/svg+xml', 0),
(136, 1, '2017-12-12 15:53:59', '2017-12-12 20:53:59', '', 'step-5', '', 'inherit', 'closed', 'closed', '', 'step-5', '', '', '2017-12-12 15:53:59', '2017-12-12 20:53:59', '', 4, 'http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/step-5.svg', 0, 'attachment', 'image/svg+xml', 0),
(137, 1, '2017-12-12 15:53:59', '2017-12-12 20:53:59', '', 'step-4', '', 'inherit', 'closed', 'closed', '', 'step-4', '', '', '2017-12-12 15:53:59', '2017-12-12 20:53:59', '', 4, 'http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/step-4.svg', 0, 'attachment', 'image/svg+xml', 0),
(138, 1, '2017-12-12 15:54:00', '2017-12-12 20:54:00', '', 'step-3', '', 'inherit', 'closed', 'closed', '', 'step-3', '', '', '2017-12-12 15:54:00', '2017-12-12 20:54:00', '', 4, 'http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/step-3.svg', 0, 'attachment', 'image/svg+xml', 0),
(139, 1, '2017-12-12 15:54:00', '2017-12-12 20:54:00', '', 'step-2', '', 'inherit', 'closed', 'closed', '', 'step-2', '', '', '2017-12-12 15:54:00', '2017-12-12 20:54:00', '', 4, 'http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/step-2.svg', 0, 'attachment', 'image/svg+xml', 0),
(140, 1, '2017-12-12 15:55:07', '2017-12-12 20:55:07', '', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2017-12-12 15:55:07', '2017-12-12 20:55:07', '', 4, 'http://localhost/joekrollbuilder.com/4-revision-v1/', 0, 'revision', '', 0),
(141, 1, '2017-12-12 15:56:48', '2017-12-12 20:56:48', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:21:"msw-framework-options";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Theme Options', 'theme-options', 'publish', 'closed', 'closed', '', 'group_5a30427a98385', '', '', '2017-12-12 18:44:14', '2017-12-12 23:44:14', '', 0, 'http://localhost/joekrollbuilder.com/?post_type=acf-field-group&#038;p=141', 0, 'acf-field-group', '', 0),
(142, 1, '2017-12-12 15:56:49', '2017-12-12 20:56:49', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Footer CTA section', '', 'publish', 'closed', 'closed', '', 'field_5a304281e435e', '', '', '2017-12-12 15:56:49', '2017-12-12 20:56:49', '', 141, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=142', 0, 'acf-field', '', 0),
(143, 1, '2017-12-12 15:58:07', '2017-12-12 20:58:07', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:12:"medium_large";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Footer CTA image', 'footer_cta_image', 'publish', 'closed', 'closed', '', 'field_5a3042aa37de1', '', '', '2017-12-12 18:43:57', '2017-12-12 23:43:57', '', 141, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=143', 2, 'acf-field', '', 0),
(144, 1, '2017-12-12 15:58:07', '2017-12-12 20:58:07', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Footer CTA text', 'footer_cta_text', 'publish', 'closed', 'closed', '', 'field_5a3042bc37de2', '', '', '2017-12-12 18:44:14', '2017-12-12 23:44:14', '', 141, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=144', 4, 'acf-field', '', 0),
(145, 1, '2017-12-12 15:58:07', '2017-12-12 20:58:07', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Footer CTA link text', 'footer_cta_link_text', 'publish', 'closed', 'closed', '', 'field_5a3042c637de3', '', '', '2017-12-12 18:44:14', '2017-12-12 23:44:14', '', 141, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=145', 6, 'acf-field', '', 0),
(146, 1, '2017-12-12 15:58:07', '2017-12-12 20:58:07', 'a:10:{s:4:"type";s:9:"page_link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:0:{}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:0;s:14:"allow_archives";i:1;s:8:"multiple";i:0;}', 'Footer CTA link', 'footer_cta_link', 'publish', 'closed', 'closed', '', 'field_5a3042d437de4', '', '', '2017-12-12 18:44:14', '2017-12-12 23:44:14', '', 141, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=146', 8, 'acf-field', '', 0),
(147, 1, '2017-12-12 16:02:42', '2017-12-12 21:02:42', '', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2017-12-12 16:02:42', '2017-12-12 21:02:42', '', 4, 'http://localhost/joekrollbuilder.com/4-revision-v1/', 0, 'revision', '', 0),
(148, 1, '2017-12-12 18:13:31', '2017-12-12 23:13:31', '', 'keys', '', 'inherit', 'closed', 'closed', '', 'keys', '', '', '2017-12-12 18:13:34', '2017-12-12 23:13:34', '', 0, 'http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/keys.png', 0, 'attachment', 'image/png', 0),
(149, 1, '2017-12-12 18:21:04', '2017-12-12 23:21:04', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:25:"page_trusted-partners.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Trusted partners fields', 'trusted-partners-fields', 'publish', 'closed', 'closed', '', 'group_5a3063ab65d29', '', '', '2017-12-12 18:21:04', '2017-12-12 23:21:04', '', 0, 'http://localhost/joekrollbuilder.com/?post_type=acf-field-group&#038;p=149', 0, 'acf-field-group', '', 0),
(150, 1, '2017-12-12 18:21:04', '2017-12-12 23:21:04', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Trusted partners', 'trusted_partners', 'publish', 'closed', 'closed', '', 'field_5a3063c4afd2a', '', '', '2017-12-12 18:21:04', '2017-12-12 23:21:04', '', 149, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=150', 0, 'acf-field', '', 0),
(151, 1, '2017-12-12 18:21:04', '2017-12-12 23:21:04', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Partner image', 'partner_image', 'publish', 'closed', 'closed', '', 'field_5a3063e8afd2b', '', '', '2017-12-12 18:21:04', '2017-12-12 23:21:04', '', 150, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=151', 0, 'acf-field', '', 0),
(152, 1, '2017-12-12 18:21:04', '2017-12-12 23:21:04', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Partner name', 'partner_name', 'publish', 'closed', 'closed', '', 'field_5a306412afd2c', '', '', '2017-12-12 18:21:04', '2017-12-12 23:21:04', '', 150, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=152', 1, 'acf-field', '', 0),
(153, 1, '2017-12-12 18:21:04', '2017-12-12 23:21:04', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Partner text', 'partner_text', 'publish', 'closed', 'closed', '', 'field_5a30642dafd2d', '', '', '2017-12-12 18:21:04', '2017-12-12 23:21:04', '', 150, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=153', 2, 'acf-field', '', 0),
(154, 1, '2017-12-12 18:21:04', '2017-12-12 23:21:04', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Partner link', 'partner_link', 'publish', 'closed', 'closed', '', 'field_5a306444afd2e', '', '', '2017-12-12 18:21:04', '2017-12-12 23:21:04', '', 150, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=154', 3, 'acf-field', '', 0),
(155, 1, '2017-12-12 18:22:48', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2017-12-12 18:22:48', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?post_type=acf-field-group&p=155', 0, 'acf-field-group', '', 0),
(156, 1, '2017-12-12 18:24:41', '2017-12-12 23:24:41', 'We have picked Louisville’s top performers; however, if you have a vendor you would like to work with, bring to our attention.', 'Trusted Partners', '', 'inherit', 'closed', 'closed', '', '65-revision-v1', '', '', '2017-12-12 18:24:41', '2017-12-12 23:24:41', '', 65, 'http://localhost/joekrollbuilder.com/65-revision-v1/', 0, 'revision', '', 0),
(157, 1, '2017-12-12 18:25:04', '2017-12-12 23:25:04', 'We have picked Louisville’s top performers; however, if you have a vendor you would like to work with, bring to our attention.', 'Trusted Partners', '', 'inherit', 'closed', 'closed', '', '65-revision-v1', '', '', '2017-12-12 18:25:04', '2017-12-12 23:25:04', '', 65, 'http://localhost/joekrollbuilder.com/65-revision-v1/', 0, 'revision', '', 0),
(158, 1, '2017-12-12 18:26:13', '2017-12-12 23:26:13', 'We have picked Louisville’s top performers; however, if you have a vendor you would like to work with, bring to our attention.', 'Trusted Partners', '', 'inherit', 'closed', 'closed', '', '65-revision-v1', '', '', '2017-12-12 18:26:13', '2017-12-12 23:26:13', '', 65, 'http://localhost/joekrollbuilder.com/65-revision-v1/', 0, 'revision', '', 0),
(159, 1, '2017-12-12 18:35:22', '2017-12-12 23:35:22', 'a:7:{s:8:"location";a:1:{i:0;a:2:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"page";}i:1;a:3:{s:5:"param";s:9:"page_type";s:8:"operator";s:2:"!=";s:5:"value";s:10:"front_page";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Gencon fields', 'gencon-fields', 'publish', 'closed', 'closed', '', 'group_5a306798cb60e', '', '', '2017-12-12 19:04:14', '2017-12-13 00:04:14', '', 0, 'http://localhost/joekrollbuilder.com/?post_type=acf-field-group&#038;p=159', 0, 'acf-field-group', '', 0),
(160, 1, '2017-12-12 18:35:42', '2017-12-12 23:35:42', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:12:"medium_large";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Header image', 'header_image', 'publish', 'closed', 'closed', '', 'field_5a3067bc4990b', '', '', '2017-12-12 19:04:14', '2017-12-13 00:04:14', '', 159, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=160', 1, 'acf-field', '', 0),
(161, 1, '2017-12-12 18:41:27', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2017-12-12 18:41:27', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?post_type=acf-field-group&p=161', 0, 'acf-field-group', '', 0),
(162, 1, '2017-12-12 18:41:39', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2017-12-12 18:41:39', '0000-00-00 00:00:00', '', 0, 'http://localhost/joekrollbuilder.com/?post_type=acf-field-group&p=162', 0, 'acf-field-group', '', 0),
(163, 1, '2017-12-12 18:42:21', '2017-12-12 23:42:21', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Header image', '', 'publish', 'closed', 'closed', '', 'field_5a30693aefff9', '', '', '2017-12-12 18:44:14', '2017-12-12 23:44:14', '', 141, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=163', 10, 'acf-field', '', 0),
(164, 1, '2017-12-12 18:42:21', '2017-12-12 23:42:21', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:12:"medium_large";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Header image', 'header_image', 'publish', 'closed', 'closed', '', 'field_5a30694cefffa', '', '', '2017-12-12 18:44:14', '2017-12-12 23:44:14', '', 141, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=164', 11, 'acf-field', '', 0),
(165, 1, '2017-12-12 18:42:39', '2017-12-12 23:42:39', '', 'bitmap', '', 'inherit', 'closed', 'closed', '', 'bitmap', '', '', '2017-12-12 18:42:41', '2017-12-12 23:42:41', '', 0, 'http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/bitmap.jpg', 0, 'attachment', 'image/jpeg', 0),
(166, 1, '2017-12-12 18:43:09', '2017-12-12 23:43:09', 'We have picked Louisville’s top performers; however, if you have a vendor you would like to work with, bring to our attention.', 'Trusted Partners', '', 'inherit', 'closed', 'closed', '', '65-revision-v1', '', '', '2017-12-12 18:43:09', '2017-12-12 23:43:09', '', 65, 'http://localhost/joekrollbuilder.com/65-revision-v1/', 0, 'revision', '', 0),
(167, 1, '2017-12-12 18:43:57', '2017-12-12 23:43:57', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Footer CTA section', '', 'publish', 'closed', 'closed', '', 'field_5a3069b66d664', '', '', '2017-12-12 19:04:14', '2017-12-13 00:04:14', '', 159, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=167', 2, 'acf-field', '', 0),
(168, 1, '2017-12-12 18:44:14', '2017-12-12 23:44:14', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:12:"medium_large";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Footer CTA image', 'footer_cta_image', 'publish', 'closed', 'closed', '', 'field_5a3069c095b74', '', '', '2017-12-12 18:45:10', '2017-12-12 23:45:10', '', 159, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=168', 3, 'acf-field', '', 0),
(169, 1, '2017-12-12 18:44:14', '2017-12-12 23:44:14', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Footer CTA text', 'footer_cta_text', 'publish', 'closed', 'closed', '', 'field_5a3069c695b76', '', '', '2017-12-12 19:04:14', '2017-12-13 00:04:14', '', 159, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=169', 4, 'acf-field', '', 0),
(170, 1, '2017-12-12 18:44:14', '2017-12-12 23:44:14', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Footer CTA link text', 'footer_cta_link_text', 'publish', 'closed', 'closed', '', 'field_5a3069c395b75', '', '', '2017-12-12 19:04:14', '2017-12-13 00:04:14', '', 159, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=170', 5, 'acf-field', '', 0),
(171, 1, '2017-12-12 18:44:14', '2017-12-12 23:44:14', 'a:10:{s:4:"type";s:9:"page_link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:0:{}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:0;s:14:"allow_archives";i:1;s:8:"multiple";i:0;}', 'Footer CTA link', 'footer_cta_link', 'publish', 'closed', 'closed', '', 'field_5a3069c995b77', '', '', '2017-12-12 19:04:14', '2017-12-13 00:04:14', '', 159, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=171', 6, 'acf-field', '', 0),
(172, 1, '2017-12-12 18:57:06', '2017-12-12 23:57:06', 'Ipsum vitae sollicitudin interdum felis ipsum convallis lorem acscele risque leo dolor slim trebor lehcar mailliw. Condimentum tempus nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem. Nulla lacinia, ipsum vitae sollicitudin interdum, felis ipsum convallis lorem, ac scelerisque leo turpis in lorem. Cras et purus vel arcu ultricies eleifend. Etiam convallis massa sed dolor.\r\n\r\n<img class="alignleft wp-image-60 size-full" src="http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/joe-e1512935590373.png" alt="" width="300" height="470" />\r\n<h2>Who is Joe Kroll?</h2>\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit nulla facilisis dolor quis est suspen disse potenti phasellus et diam donec metus donec mi ante, vestibulum ut ornare non risque leo dolor slim trebor lehcar mailliw.\r\n\r\nFusce placerat dignissim lacus. Suspendisse cursus nunc ut ante. Phasellus pulvinar viverra nunc. Ut convallis dui et augue. Sed felis neque viverra in eleifend ac pharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.\r\n\r\nFusce placerat dignissim lacus. Suspendisse cursus nunc ut ante. Phasellus pulvinar viverra nunc. Ut convallis dui et augue. Sed felis neque viverra in eleifend ac pharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.\r\n\r\nFusce placerat dignissim lacus. Suspendisse cursus nunc ut ante. Phasellus pulvinar viverra nunc. Ut convallis dui et augue. Sed felis neque viverra in eleifend ac pharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.\r\n\r\nFusce placerat dignissim lacus. Suspendisse cursus nunc ut ante. Phasellus pulvinar viverra nunc. Ut convallis dui et augue. Sed felis neque viverra in eleifend ac pharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.\r\n\r\n\r\n\r\n				<div class="partners-list">\r\n					<h2>Joe’s Partners</h2>\r\n					<ul>\r\n						<li>New Century Plumbing</li>\r\n						<li>KME Electric</li>\r\n						<li>Chapman Heating & Cooling</li>\r\n						<li>Century Entertainment</li>\r\n						<li>Premiere Flooring</li>\r\n						<li>Willis-Klein</li>\r\n						<li>PC Lumber</li>\r\n						<li>Jennifer Bergin</li>\r\n						<li>Cindy Druin</li>\r\n					</ul>\r\n					<a href="/about-us/trusted-partners/" class="read-more">See our trusted partners <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>\r\n				</div><!-- /.partners-list -->', 'About Us', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2017-12-12 18:57:06', '2017-12-12 23:57:06', '', 25, 'http://localhost/joekrollbuilder.com/25-revision-v1/', 0, 'revision', '', 0),
(173, 1, '2017-12-12 18:57:43', '2017-12-12 23:57:43', 'Ipsum vitae sollicitudin interdum felis ipsum convallis lorem acscele risque leo dolor slim trebor lehcar mailliw. Condimentum tempus nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem. Nulla lacinia, ipsum vitae sollicitudin interdum, felis ipsum convallis lorem, ac scelerisque leo turpis in lorem. Cras et purus vel arcu ultricies eleifend. Etiam convallis massa sed dolor.\r\n\r\n<img class="alignleft wp-image-60 size-full" src="http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/joe-e1512935590373.png" alt="" width="300" height="470" />\r\n<h2>Who is Joe Kroll?</h2>\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit nulla facilisis dolor quis est suspen disse potenti phasellus et diam donec metus donec mi ante, vestibulum ut ornare non risque leo dolor slim trebor lehcar mailliw.\r\n\r\nFusce placerat dignissim lacus. Suspendisse cursus nunc ut ante. Phasellus pulvinar viverra nunc. Ut convallis dui et augue. Sed felis neque viverra in eleifend ac pharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.\r\n\r\nFusce placerat dignissim lacus. Suspendisse cursus nunc ut ante. Phasellus pulvinar viverra nunc. Ut convallis dui et augue. Sed felis neque viverra in eleifend ac pharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.\r\n\r\nFusce placerat dignissim lacus. Suspendisse cursus nunc ut ante. Phasellus pulvinar viverra nunc. Ut convallis dui et augue. Sed felis neque viverra in eleifend ac pharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.\r\n\r\nFusce placerat dignissim lacus. Suspendisse cursus nunc ut ante. Phasellus pulvinar viverra nunc. Ut convallis dui et augue. Sed felis neque viverra in eleifend ac pharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae.\r\n\r\n\r\n\r\n				<div class="partners-list">\r\n					<h2>Joe’s Partners</h2>\r\n					<ul>\r\n						<li>New Century Plumbing</li>\r\n						<li>KME Electric</li>\r\n						<li>Chapman Heating & Cooling</li>\r\n						<li>Century Entertainment</li>\r\n						<li>Premiere Flooring</li>\r\n						<li>Willis-Klein</li>\r\n						<li>PC Lumber</li>\r\n						<li>Jennifer Bergin</li>\r\n						<li>Cindy Druin</li>\r\n					</ul>\r\n					<a href="/about-us/trusted-partners/" class="read-more">See our trusted partners <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>\r\n				</div><!-- /.partners-list -->', 'About Us', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2017-12-12 18:57:43', '2017-12-12 23:57:43', '', 25, 'http://localhost/joekrollbuilder.com/25-revision-v1/', 0, 'revision', '', 0),
(174, 1, '2017-12-12 19:02:15', '2017-12-13 00:02:15', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:30:"page_home-building-process.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Home building process fields', 'home-building-process-fields', 'publish', 'closed', 'closed', '', 'group_5a306df7adeb0', '', '', '2017-12-12 19:06:44', '2017-12-13 00:06:44', '', 0, 'http://localhost/joekrollbuilder.com/?post_type=acf-field-group&#038;p=174', 0, 'acf-field-group', '', 0),
(175, 1, '2017-12-12 19:03:03', '2017-12-13 00:03:03', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:3:"row";s:12:"button_label";s:8:"Add step";}', 'Home building process steps', 'home_building_process_steps', 'publish', 'closed', 'closed', '', 'field_5a306e09a4345', '', '', '2017-12-12 19:06:44', '2017-12-13 00:06:44', '', 174, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=175', 0, 'acf-field', '', 0),
(176, 1, '2017-12-12 19:03:03', '2017-12-13 00:03:03', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Step icon', 'step_icon', 'publish', 'closed', 'closed', '', 'field_5a306e19a4346', '', '', '2017-12-12 19:05:07', '2017-12-13 00:05:07', '', 175, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=176', 0, 'acf-field', '', 0),
(177, 1, '2017-12-12 19:03:03', '2017-12-13 00:03:03', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Step title', 'step_title', 'publish', 'closed', 'closed', '', 'field_5a306e23a4347', '', '', '2017-12-12 19:03:03', '2017-12-13 00:03:03', '', 175, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=177', 1, 'acf-field', '', 0),
(178, 1, '2017-12-12 19:03:03', '2017-12-13 00:03:03', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Step text', 'step_text', 'publish', 'closed', 'closed', '', 'field_5a306e29a4348', '', '', '2017-12-12 19:03:03', '2017-12-13 00:03:03', '', 175, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=178', 2, 'acf-field', '', 0),
(179, 1, '2017-12-12 19:04:14', '2017-12-13 00:04:14', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Header', '', 'publish', 'closed', 'closed', '', 'field_5a306e6e03b48', '', '', '2017-12-12 19:04:14', '2017-12-13 00:04:14', '', 159, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=179', 0, 'acf-field', '', 0),
(180, 1, '2017-12-12 19:06:37', '2017-12-13 00:06:37', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.', 'Home Building Process', '', 'inherit', 'closed', 'closed', '', '27-revision-v1', '', '', '2017-12-12 19:06:37', '2017-12-13 00:06:37', '', 27, 'http://localhost/joekrollbuilder.com/27-revision-v1/', 0, 'revision', '', 0),
(181, 1, '2017-12-12 19:07:42', '2017-12-13 00:07:42', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.', 'Home Building Process', '', 'inherit', 'closed', 'closed', '', '27-revision-v1', '', '', '2017-12-12 19:07:42', '2017-12-13 00:07:42', '', 27, 'http://localhost/joekrollbuilder.com/27-revision-v1/', 0, 'revision', '', 0),
(182, 1, '2017-12-12 19:18:20', '2017-12-13 00:18:20', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:30:"msw-portfolio-archive-settings";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Portfolio archive fields', 'portfolio-archive-fields', 'publish', 'closed', 'closed', '', 'group_5a3071bfcb6cc', '', '', '2017-12-12 20:21:41', '2017-12-13 01:21:41', '', 0, 'http://localhost/joekrollbuilder.com/?post_type=acf-field-group&#038;p=182', 0, 'acf-field-group', '', 0),
(183, 1, '2017-12-12 19:18:41', '2017-12-13 00:18:41', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Portfolio archive intro text', 'portfolio_archive_intro_text', 'publish', 'closed', 'closed', '', 'field_5a3071d3b4cdb', '', '', '2017-12-12 20:21:20', '2017-12-13 01:21:20', '', 182, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=183', 1, 'acf-field', '', 0),
(184, 1, '2017-12-12 19:31:03', '2017-12-13 00:31:03', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:9:"portfolio";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Case Study Fields', 'case-study-fields', 'publish', 'closed', 'closed', '', 'group_5a3074bcbe31d', '', '', '2017-12-14 03:25:33', '2017-12-14 08:25:33', '', 0, 'http://localhost/joekrollbuilder.com/?post_type=acf-field-group&#038;p=184', 0, 'acf-field-group', '', 0),
(185, 1, '2017-12-12 19:33:13', '2017-12-13 00:33:13', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Image text block', 'image_text_block', 'publish', 'closed', 'closed', '', 'field_5a3074c91f7ed', '', '', '2017-12-12 19:33:13', '2017-12-13 00:33:13', '', 184, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=185', 0, 'acf-field', '', 0),
(186, 1, '2017-12-12 19:33:13', '2017-12-13 00:33:13', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Block content', 'block_content', 'publish', 'closed', 'closed', '', 'field_5a3075171f7ee', '', '', '2017-12-12 19:35:22', '2017-12-13 00:35:22', '', 184, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=186', 1, 'acf-field', '', 0),
(187, 1, '2017-12-12 19:33:13', '2017-12-13 00:33:13', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Block image', 'block_image', 'publish', 'closed', 'closed', '', 'field_5a3075291f7ef', '', '', '2017-12-12 19:33:13', '2017-12-13 00:33:13', '', 186, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=187', 0, 'acf-field', '', 0),
(188, 1, '2017-12-12 19:33:13', '2017-12-13 00:33:13', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Block text', 'block_text', 'publish', 'closed', 'closed', '', 'field_5a30753b1f7f0', '', '', '2017-12-12 19:33:13', '2017-12-13 00:33:13', '', 186, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=188', 1, 'acf-field', '', 0),
(189, 1, '2017-12-12 19:35:22', '2017-12-13 00:35:22', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Testimonial', '', 'publish', 'closed', 'closed', '', 'field_5a30754da2523', '', '', '2017-12-12 19:35:22', '2017-12-13 00:35:22', '', 184, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=189', 2, 'acf-field', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(190, 1, '2017-12-12 19:35:22', '2017-12-13 00:35:22', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Testimonial text', 'testimonial_text', 'publish', 'closed', 'closed', '', 'field_5a30756ba2524', '', '', '2017-12-12 19:35:22', '2017-12-13 00:35:22', '', 184, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=190', 3, 'acf-field', '', 0),
(191, 1, '2017-12-12 19:35:22', '2017-12-13 00:35:22', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Testimonial author', 'testimonial_author', 'publish', 'closed', 'closed', '', 'field_5a307576a2525', '', '', '2017-12-12 19:35:22', '2017-12-13 00:35:22', '', 184, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=191', 4, 'acf-field', '', 0),
(192, 1, '2017-12-12 19:35:22', '2017-12-13 00:35:22', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Testimonial author location', 'testimonial_author_location', 'publish', 'closed', 'closed', '', 'field_5a307585a2526', '', '', '2017-12-12 19:35:22', '2017-12-13 00:35:22', '', 184, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=192', 5, 'acf-field', '', 0),
(193, 1, '2017-12-12 19:35:22', '2017-12-13 00:35:22', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Image text block', 'image_text_block', 'publish', 'closed', 'closed', '', 'field_5a307593a2527', '', '', '2017-12-12 19:35:22', '2017-12-13 00:35:22', '', 184, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=193', 6, 'acf-field', '', 0),
(194, 1, '2017-12-12 19:35:22', '2017-12-13 00:35:22', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Second Block content', 'second_block_content', 'publish', 'closed', 'closed', '', 'field_5a30759ba2528', '', '', '2017-12-12 19:35:22', '2017-12-13 00:35:22', '', 184, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=194', 7, 'acf-field', '', 0),
(195, 1, '2017-12-12 19:35:22', '2017-12-13 00:35:22', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Block image', 'block_image', 'publish', 'closed', 'closed', '', 'field_5a30759ba2529', '', '', '2017-12-12 19:35:22', '2017-12-13 00:35:22', '', 194, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=195', 0, 'acf-field', '', 0),
(196, 1, '2017-12-12 19:35:22', '2017-12-13 00:35:22', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";}', 'Block text', 'block_text', 'publish', 'closed', 'closed', '', 'field_5a30759ba252a', '', '', '2017-12-12 19:35:22', '2017-12-13 00:35:22', '', 194, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=196', 1, 'acf-field', '', 0),
(197, 1, '2017-12-12 19:37:16', '2017-12-13 00:37:16', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Project specs', '', 'publish', 'closed', 'closed', '', 'field_5a3075d8216f5', '', '', '2017-12-12 19:37:16', '2017-12-13 00:37:16', '', 184, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=197', 8, 'acf-field', '', 0),
(198, 1, '2017-12-12 19:37:16', '2017-12-13 00:37:16', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Specs', 'specs', 'publish', 'closed', 'closed', '', 'field_5a30760f216f7', '', '', '2017-12-14 03:25:33', '2017-12-14 08:25:33', '', 184, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=198', 10, 'acf-field', '', 0),
(199, 1, '2017-12-12 19:37:16', '2017-12-13 00:37:16', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Spec name', 'spec_name', 'publish', 'closed', 'closed', '', 'field_5a307622216f8', '', '', '2017-12-12 19:37:16', '2017-12-13 00:37:16', '', 198, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=199', 0, 'acf-field', '', 0),
(200, 1, '2017-12-12 19:37:16', '2017-12-13 00:37:16', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Additional details', 'additional_details', 'publish', 'closed', 'closed', '', 'field_5a3075e4216f6', '', '', '2017-12-14 03:25:33', '2017-12-14 08:25:33', '', 184, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=200', 12, 'acf-field', '', 0),
(201, 1, '2017-12-12 19:38:26', '2017-12-13 00:38:26', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Additional', '', 'publish', 'closed', 'closed', '', 'field_5a307675de91d', '', '', '2017-12-14 03:25:33', '2017-12-14 08:25:33', '', 184, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=201', 11, 'acf-field', '', 0),
(202, 1, '2017-12-12 20:21:20', '2017-12-13 01:21:20', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:12:"medium_large";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Header image', 'portfolio_header_image', 'publish', 'closed', 'closed', '', 'field_5a30807f213c8', '', '', '2017-12-12 20:21:41', '2017-12-13 01:21:41', '', 182, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&#038;p=202', 0, 'acf-field', '', 0),
(203, 1, '2017-12-14 03:18:51', '2017-12-14 08:18:51', '', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2017-12-14 03:18:51', '2017-12-14 08:18:51', '', 4, 'http://localhost/joekrollbuilder.com/4-revision-v1/', 0, 'revision', '', 0),
(204, 1, '2017-12-14 03:25:33', '2017-12-14 08:25:33', 'a:12:{s:4:"type";s:8:"checkbox";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:2:{i:0;s:86:"<img src="http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/step-1.svg">";i:1;s:86:"<img src="http://localhost/joekrollbuilder.com/wp-content/uploads/2017/12/step-2.svg">";}s:12:"allow_custom";i:0;s:11:"save_custom";i:0;s:13:"default_value";a:0:{}s:6:"layout";s:8:"vertical";s:6:"toggle";i:0;s:13:"return_format";s:5:"value";}', '', '', 'publish', 'closed', 'closed', '', 'field_5a32348b3c531', '', '', '2017-12-14 03:25:33', '2017-12-14 08:25:33', '', 184, 'http://localhost/joekrollbuilder.com/?post_type=acf-field&p=204', 9, 'acf-field', '', 0),
(205, 1, '2017-12-14 03:55:49', '2017-12-14 08:55:49', 'Aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Praesent ornare, lectus at mattis condimentum, quam enim auctor nunc, sit amet molestie velit erat nec ligula. Fusce ultrices consequat risus proin porttitor donec a nibh accumsan mi tempor aliquet. Phasellus laoreet orci ac lorem.', 'Home Building Process', '', 'inherit', 'closed', 'closed', '', '27-revision-v1', '', '', '2017-12-14 03:55:49', '2017-12-14 08:55:49', '', 27, 'http://localhost/joekrollbuilder.com/27-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form`
#

DROP TABLE IF EXISTS `wp_rg_form`;


#
# Table structure of table `wp_rg_form`
#

CREATE TABLE `wp_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_form`
#
INSERT INTO `wp_rg_form` ( `id`, `title`, `date_created`, `is_active`, `is_trash`) VALUES
(2, 'Contact Form', '2017-12-13 01:17:03', 1, 0) ;

#
# End of data contents of table `wp_rg_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_meta`
#

DROP TABLE IF EXISTS `wp_rg_form_meta`;


#
# Table structure of table `wp_rg_form_meta`
#

CREATE TABLE `wp_rg_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `entries_grid_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `confirmations` longtext COLLATE utf8mb4_unicode_520_ci,
  `notifications` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_form_meta`
#
INSERT INTO `wp_rg_form_meta` ( `form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(2, '{"title":"Contact Form","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Send Your Message","imageUrl":""},"fields":[{"type":"text","id":1,"label":"First Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"gf_left_half","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":""},{"type":"text","id":2,"label":"Last Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"gf_right_half","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":""},{"type":"email","id":3,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"gf_left_half","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","emailConfirmEnabled":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":""},{"type":"phone","id":4,"label":"Phone","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"phoneFormat":"standard","formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"gf_right_half","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","form_id":"","productField":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":""},{"type":"textarea","id":5,"label":"Message","adminLabel":"","isRequired":false,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","form_id":"","useRichTextEditor":false,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"displayOnly":""}],"version":"2.2.5","id":2,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"subLabelPlacement":"below","cssClass":"","enableHoneypot":true,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":""}', NULL, '{"5864c20d1ea26":{"id":"5864c20d1ea26","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}}', '{"5864c20d1dba5":{"isActive":true,"id":"5864c20d1dba5","name":"Admin Notification","service":"wordpress","event":"form_submission","to":"{admin_email}","toType":"email","bcc":"","subject":"Website Inquiry","message":"{all_fields}","from":"wp@makespaceweb.com","fromName":"WordPress","replyTo":"{Email:3}","routing":null,"conditionalLogic":null,"disableAutoformat":false}}') ;

#
# End of data contents of table `wp_rg_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_view`
#

DROP TABLE IF EXISTS `wp_rg_form_view`;


#
# Table structure of table `wp_rg_form_view`
#

CREATE TABLE `wp_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `date_created` (`date_created`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_form_view`
#

#
# End of data contents of table `wp_rg_form_view`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_incomplete_submissions`
#

DROP TABLE IF EXISTS `wp_rg_incomplete_submissions`;


#
# Table structure of table `wp_rg_incomplete_submissions`
#

CREATE TABLE `wp_rg_incomplete_submissions` (
  `uuid` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `submission` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_incomplete_submissions`
#

#
# End of data contents of table `wp_rg_incomplete_submissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead`
#

DROP TABLE IF EXISTS `wp_rg_lead`;


#
# Table structure of table `wp_rg_lead`
#

CREATE TABLE `wp_rg_lead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `payment_method` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead`
#

#
# End of data contents of table `wp_rg_lead`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail`;


#
# Table structure of table `wp_rg_lead_detail`
#

CREATE TABLE `wp_rg_lead_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `field_number` float NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_field_number` (`lead_id`,`field_number`),
  KEY `lead_field_value` (`value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_detail`
#

#
# End of data contents of table `wp_rg_lead_detail`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail_long`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail_long`;


#
# Table structure of table `wp_rg_lead_detail_long`
#

CREATE TABLE `wp_rg_lead_detail_long` (
  `lead_detail_id` bigint(20) unsigned NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`lead_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_detail_long`
#

#
# End of data contents of table `wp_rg_lead_detail_long`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_meta`
#

DROP TABLE IF EXISTS `wp_rg_lead_meta`;


#
# Table structure of table `wp_rg_lead_meta`
#

CREATE TABLE `wp_rg_lead_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lead_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `lead_id` (`lead_id`),
  KEY `form_id_meta_key` (`form_id`,`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_meta`
#

#
# End of data contents of table `wp_rg_lead_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_notes`
#

DROP TABLE IF EXISTS `wp_rg_lead_notes`;


#
# Table structure of table `wp_rg_lead_notes`
#

CREATE TABLE `wp_rg_lead_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  `note_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_user_key` (`lead_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_notes`
#

#
# End of data contents of table `wp_rg_lead_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(10, 1, 0),
(12, 1, 0),
(14, 1, 0),
(15, 1, 0),
(16, 1, 0),
(18, 1, 0),
(19, 1, 0),
(20, 1, 0),
(21, 1, 0),
(22, 1, 0),
(23, 1, 0),
(51, 2, 0),
(52, 2, 0),
(53, 2, 0),
(55, 2, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 11),
(2, 2, 'nav_menu', '', 0, 4) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Main Menu', 'main-menu', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'makespace'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'addtoany_settings_pointer'),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:2:{s:64:"aed734a9a2c455405f58083cedc3bab8159b589d7073bd6307c2890396fb0ffc";a:4:{s:10:"expiration";i:1513412248;s:2:"ip";s:3:"::1";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36";s:5:"login";i:1513239448;}s:64:"ca4942e66329537a611f8d0fcb774f90faf99a674c5eddf0e566dc3cd746f3b7";a:4:{s:10:"expiration";i:1513412248;s:2:"ip";s:3:"::1";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36";s:5:"login";i:1513239448;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '3'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:2:"::";}'),
(19, 1, 'wp_yoast_notifications', 'a:10:{i:0;a:2:{s:7:"message";s:235:"You just changed the URL of this Field Group. To ensure your visitors do not see a 404 on the old URL, you should create a redirect. <a href="https://yoa.st/1d0?utm_content=5.9.3" target="_blank">Learn how to create redirects here.</a>";s:7:"options";a:8:{s:4:"type";s:11:"notice-info";s:2:"id";s:0:"";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";a:1:{i:0;s:20:"wpseo_manage_options";}s:16:"capability_check";s:3:"all";}}i:1;a:2:{s:7:"message";s:235:"You just changed the URL of this Field Group. To ensure your visitors do not see a 404 on the old URL, you should create a redirect. <a href="https://yoa.st/1d0?utm_content=5.9.3" target="_blank">Learn how to create redirects here.</a>";s:7:"options";a:8:{s:4:"type";s:11:"notice-info";s:2:"id";s:0:"";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";a:1:{i:0;s:20:"wpseo_manage_options";}s:16:"capability_check";s:3:"all";}}i:2;a:2:{s:7:"message";s:235:"You just changed the URL of this Field Group. To ensure your visitors do not see a 404 on the old URL, you should create a redirect. <a href="https://yoa.st/1d0?utm_content=5.9.3" target="_blank">Learn how to create redirects here.</a>";s:7:"options";a:8:{s:4:"type";s:11:"notice-info";s:2:"id";s:0:"";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";a:1:{i:0;s:20:"wpseo_manage_options";}s:16:"capability_check";s:3:"all";}}i:3;a:2:{s:7:"message";s:235:"You just changed the URL of this Field Group. To ensure your visitors do not see a 404 on the old URL, you should create a redirect. <a href="https://yoa.st/1d0?utm_content=5.9.3" target="_blank">Learn how to create redirects here.</a>";s:7:"options";a:8:{s:4:"type";s:11:"notice-info";s:2:"id";s:0:"";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";a:1:{i:0;s:20:"wpseo_manage_options";}s:16:"capability_check";s:3:"all";}}i:4;a:2:{s:7:"message";s:235:"You just changed the URL of this Field Group. To ensure your visitors do not see a 404 on the old URL, you should create a redirect. <a href="https://yoa.st/1d0?utm_content=5.9.3" target="_blank">Learn how to create redirects here.</a>";s:7:"options";a:8:{s:4:"type";s:11:"notice-info";s:2:"id";s:0:"";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";a:1:{i:0;s:20:"wpseo_manage_options";}s:16:"capability_check";s:3:"all";}}i:5;a:2:{s:7:"message";s:235:"You just changed the URL of this Field Group. To ensure your visitors do not see a 404 on the old URL, you should create a redirect. <a href="https://yoa.st/1d0?utm_content=5.9.3" target="_blank">Learn how to create redirects here.</a>";s:7:"options";a:8:{s:4:"type";s:11:"notice-info";s:2:"id";s:0:"";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";a:1:{i:0;s:20:"wpseo_manage_options";}s:16:"capability_check";s:3:"all";}}i:6;a:2:{s:7:"message";s:235:"You just changed the URL of this Field Group. To ensure your visitors do not see a 404 on the old URL, you should create a redirect. <a href="https://yoa.st/1d0?utm_content=5.9.3" target="_blank">Learn how to create redirects here.</a>";s:7:"options";a:8:{s:4:"type";s:11:"notice-info";s:2:"id";s:0:"";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";a:1:{i:0;s:20:"wpseo_manage_options";}s:16:"capability_check";s:3:"all";}}i:7;a:2:{s:7:"message";s:791:"We\'ve noticed you\'ve been using Yoast SEO for some time now; we hope you love it! We\'d be thrilled if you could <a href="https://yoa.st/rate-yoast-seo?utm_content=5.9.3">give us a 5 stars rating on WordPress.org</a>!\n\nIf you are experiencing issues, <a href="https://yoa.st/bugreport?utm_content=5.9.3">please file a bug report</a> and we\'ll do our best to help you out.\n\nBy the way, did you know we also have a <a href=\'https://yoa.st/premium-notification?utm_content=5.9.3\'>Premium plugin</a>? It offers advanced features, like a redirect manager and support for multiple keywords. It also comes with 24/7 personal support.\n\n<a class="button" href="http://localhost/joekrollbuilder.com/wp-admin/?page=wpseo_dashboard&yoast_dismiss=upsell">Please don\'t show me this notification anymore</a>";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:19:"wpseo-upsell-notice";s:5:"nonce";N;s:8:"priority";d:0.8000000000000000444089209850062616169452667236328125;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:20:"wpseo_manage_options";s:16:"capability_check";s:3:"all";}}i:8;a:2:{s:7:"message";s:179:"Don\'t miss your crawl errors: <a href="http://localhost/joekrollbuilder.com/wp-admin/admin.php?page=wpseo_search_console&tab=settings">connect with Google Search Console here</a>.";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:17:"wpseo-dismiss-gsc";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:20:"wpseo_manage_options";s:16:"capability_check";s:3:"all";}}i:9;a:2:{s:7:"message";s:288:"You still have the default WordPress tagline, even an empty one is probably better. <a href="http://localhost/joekrollbuilder.com/wp-admin/customize.php?url=http%3A%2F%2Flocalhost%2Fjoekrollbuilder.com%2Fwp-admin%2Ftools.php%3Fpage%3Dwp-migrate-db">You can fix this in the customizer</a>.";s:7:"options";a:8:{s:4:"type";s:5:"error";s:2:"id";s:28:"wpseo-dismiss-tagline-notice";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:20:"wpseo_manage_options";s:16:"capability_check";s:3:"all";}}}'),
(20, 1, '_yoast_wpseo_profile_updated', '1512685426'),
(21, 1, 'wp_user-settings', 'libraryContent=browse&editor=html'),
(22, 1, 'wp_user-settings-time', '1513122949'),
(23, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(24, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(25, 1, 'nav_menu_recently_edited', '2'),
(26, 1, 'acf_user_settings', 'a:0:{}'),
(27, 1, 'gform_recent_forms', 'a:1:{i:0;s:1:"2";}'),
(28, 1, 'closedpostboxes_page', 'a:1:{i:0;s:10:"wpseo_meta";}'),
(29, 1, 'metaboxhidden_page', 'a:9:{i:0;s:23:"acf-group_56cbac453acf3";i:1;s:23:"acf-group_57baf550b8fda";i:2;s:23:"acf-group_56c5356f1e6e2";i:3;s:23:"acf-group_56c54930c0959";i:4;s:12:"revisionsdiv";i:5;s:16:"commentstatusdiv";i:6;s:11:"commentsdiv";i:7;s:7:"slugdiv";i:8;s:9:"authordiv";}'),
(30, 1, 'meta-box-order_page', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:84:"submitdiv,pageparentdiv,acf-group_56cbac453acf3,acf-group_57baf550b8fda,postimagediv";s:6:"normal";s:238:"acf-group_5a306df7adeb0,acf-group_5a306798cb60e,acf-group_5a303bde1abde,acf-group_5a30427a98385,acf-group_5a3063ab65d29,acf-group_56c5356f1e6e2,acf-group_56c54930c0959,revisionsdiv,commentstatusdiv,commentsdiv,slugdiv,authordiv,wpseo_meta";s:8:"advanced";s:0:"";}'),
(31, 1, 'screen_layout_page', '2'),
(32, 1, 'meta-box-order_portfolio', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:106:"submitdiv,portfolio-categorydiv,pageparentdiv,acf-group_56cbac453acf3,acf-group_57baf550b8fda,postimagediv";s:6:"normal";s:246:"postexcerpt,acf-group_5a3074bcbe31d,acf-group_5a306798cb60e,acf-group_5a306df7adeb0,acf-group_5a303bde1abde,acf-group_5a3071bfcb6cc,acf-group_5a30427a98385,acf-group_5a3063ab65d29,acf-group_56c5356f1e6e2,acf-group_56c54930c0959,slugdiv,wpseo_meta";s:8:"advanced";s:0:"";}'),
(33, 1, 'screen_layout_portfolio', '2') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'makespace', '$P$Brclca0H7MjlWnTYE0UDQIUc5K1Nx70', 'makespace', 'wp@makespaceweb.com', '', '2017-12-05 20:35:18', '', 0, 'makespace') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_seo_links`
#

DROP TABLE IF EXISTS `wp_yoast_seo_links`;


#
# Table structure of table `wp_yoast_seo_links`
#

CREATE TABLE `wp_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `target_post_id` bigint(20) unsigned NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_seo_links`
#
INSERT INTO `wp_yoast_seo_links` ( `id`, `url`, `post_id`, `target_post_id`, `type`) VALUES
(1, 'https://www.makespaceweb.com/services/louisville-website-design/', 8, 0, 'external'),
(2, 'https://www.makespaceweb.com/', 8, 0, 'external'),
(3, 'https://www.makespaceweb.com/services/louisville-website-design', 8, 0, 'external'),
(4, 'https://www.makespaceweb.com/services/louisville-website-design/index.html#anchor-dev', 8, 0, 'external'),
(5, 'https://www.makespaceweb.com/services/', 8, 0, 'external'),
(6, '&#109;&#97;&#105;&#108;&#116;&#111;&#58;&#105;&#110;&#102;&#111;&#64;&#109;&#97;&#107;&#101;&#115;&#112;&#97;&#99;&#101;&#119;&#101;&#98;&#46;&#99;&#111;&#109;', 8, 0, 'internal'),
(7, 'https://www.makespaceweb.com/Orlando_Web_Design', 8, 0, 'external'),
(8, 'https://www.makespaceweb.com/', 8, 0, 'external'),
(9, 'https://www.makespaceweb.com/web-design-portfolio/', 8, 0, 'external'),
(10, 'https://www.oohology.com/Services/Branding', 8, 0, 'external'),
(11, 'https://www.oohology.com', 8, 0, 'external'),
(12, 'https://www.oohology.com/', 8, 0, 'external'),
(13, 'http://localhost/joekrollbuilder.com/?page_id=2', 9, 2, 'internal'),
(14, 'http://localhost/joekrollbuilder.com/', 9, 4, 'internal'),
(15, 'http://localhost/joekrollbuilder.com/?page_id=6', 9, 6, 'internal'),
(16, 'http://localhost/joekrollbuilder.com/?page_id=7', 9, 7, 'internal'),
(17, 'http://localhost/joekrollbuilder.com/?page_id=8', 9, 8, 'internal'),
(18, 'http://localhost/joekrollbuilder.com/?page_id=9', 9, 9, 'internal'),
(19, 'http://example.org/', 14, 0, 'external'),
(20, 'http://example.org/', 14, 0, 'external'),
(21, 'http://example.org/', 14, 0, 'external'),
(22, 'http://example.org/', 14, 0, 'external'),
(23, 'https://www.youtube.com/watch?v=O_HyZ5aW76c', 14, 0, 'external'),
(24, 'http://en.support.wordpress.com/code/', 14, 0, 'external'),
(25, 'http://apple.com', 14, 0, 'external'),
(26, 'http://example.org/', 16, 0, 'external'),
(27, 'http://example.org/', 16, 0, 'external'),
(28, 'http://example.org/', 16, 0, 'external'),
(29, 'http://example.org/', 16, 0, 'external'),
(30, 'https://www.youtube.com/watch?v=O_HyZ5aW76c', 16, 0, 'external'),
(31, 'http://en.support.wordpress.com/code/', 16, 0, 'external'),
(32, 'http://apple.com', 16, 0, 'external'),
(33, 'http://example.org/', 19, 0, 'external'),
(34, 'http://example.org/', 19, 0, 'external'),
(35, 'http://example.org/', 19, 0, 'external'),
(36, 'http://example.org/', 19, 0, 'external'),
(37, 'https://www.youtube.com/watch?v=O_HyZ5aW76c', 19, 0, 'external'),
(38, 'http://en.support.wordpress.com/code/', 19, 0, 'external'),
(39, 'http://apple.com', 19, 0, 'external'),
(40, 'http://example.org/', 20, 0, 'external'),
(41, 'http://example.org/', 20, 0, 'external'),
(42, 'http://example.org/', 20, 0, 'external'),
(43, 'http://example.org/', 20, 0, 'external'),
(44, 'https://www.youtube.com/watch?v=O_HyZ5aW76c', 20, 0, 'external'),
(45, 'http://en.support.wordpress.com/code/', 20, 0, 'external'),
(46, 'http://apple.com', 20, 0, 'external'),
(47, 'http://en.support.wordpress.com/images/image-settings/', 21, 0, 'external'),
(48, 'http://example.org/', 75, 0, 'external'),
(49, 'http://example.org/', 75, 0, 'external'),
(50, 'http://example.org/', 75, 0, 'external'),
(51, 'http://example.org/', 75, 0, 'external'),
(52, 'https://www.youtube.com/watch?v=O_HyZ5aW76c', 75, 0, 'external'),
(53, 'http://en.support.wordpress.com/code/', 75, 0, 'external'),
(54, 'http://apple.com', 75, 0, 'external'),
(55, 'http://en.support.wordpress.com/images/image-settings/', 78, 0, 'external'),
(56, 'http://example.org/', 79, 0, 'external'),
(57, 'http://example.org/', 79, 0, 'external'),
(58, 'http://example.org/', 79, 0, 'external'),
(59, 'http://example.org/', 79, 0, 'external'),
(60, 'https://www.youtube.com/watch?v=O_HyZ5aW76c', 79, 0, 'external'),
(61, 'http://en.support.wordpress.com/code/', 79, 0, 'external'),
(62, 'http://apple.com', 79, 0, 'external'),
(63, 'http://example.org/', 80, 0, 'external'),
(64, 'http://example.org/', 80, 0, 'external'),
(65, 'http://example.org/', 80, 0, 'external'),
(66, 'http://example.org/', 80, 0, 'external'),
(67, 'https://www.youtube.com/watch?v=O_HyZ5aW76c', 80, 0, 'external'),
(68, 'http://en.support.wordpress.com/code/', 80, 0, 'external'),
(69, 'http://apple.com', 80, 0, 'external'),
(70, 'http://en.support.wordpress.com/images/image-settings/', 81, 0, 'external'),
(71, 'http://example.org/', 82, 0, 'external'),
(72, 'http://example.org/', 82, 0, 'external'),
(73, 'http://example.org/', 82, 0, 'external'),
(74, 'http://example.org/', 82, 0, 'external'),
(75, 'https://www.youtube.com/watch?v=O_HyZ5aW76c', 82, 0, 'external'),
(76, 'http://en.support.wordpress.com/code/', 82, 0, 'external'),
(77, 'http://apple.com', 82, 0, 'external'),
(78, 'http://en.support.wordpress.com/images/image-settings/', 83, 0, 'external'),
(79, 'http://en.support.wordpress.com/images/image-settings/', 87, 0, 'external'),
(80, 'http://en.support.wordpress.com/images/image-settings/', 88, 0, 'external'),
(81, 'http://example.org/', 89, 0, 'external'),
(82, 'http://example.org/', 89, 0, 'external'),
(83, 'http://example.org/', 89, 0, 'external'),
(84, 'http://example.org/', 89, 0, 'external'),
(85, 'https://www.youtube.com/watch?v=O_HyZ5aW76c', 89, 0, 'external'),
(86, 'http://en.support.wordpress.com/code/', 89, 0, 'external'),
(87, 'http://apple.com', 89, 0, 'external'),
(88, 'http://en.support.wordpress.com/images/image-settings/', 92, 0, 'external'),
(89, 'http://en.support.wordpress.com/images/image-settings/', 93, 0, 'external'),
(90, 'http://en.support.wordpress.com/images/image-settings/', 94, 0, 'external'),
(91, 'http://en.support.wordpress.com/images/image-settings/', 96, 0, 'external'),
(92, 'http://example.org/', 97, 0, 'external'),
(93, 'http://example.org/', 97, 0, 'external'),
(94, 'http://example.org/', 97, 0, 'external'),
(95, 'http://example.org/', 97, 0, 'external'),
(96, 'https://www.youtube.com/watch?v=O_HyZ5aW76c', 97, 0, 'external'),
(97, 'http://en.support.wordpress.com/code/', 97, 0, 'external'),
(98, 'http://apple.com', 97, 0, 'external'),
(99, 'http://example.org/', 98, 0, 'external'),
(100, 'http://example.org/', 98, 0, 'external') ;
INSERT INTO `wp_yoast_seo_links` ( `id`, `url`, `post_id`, `target_post_id`, `type`) VALUES
(101, 'http://example.org/', 98, 0, 'external'),
(102, 'http://example.org/', 98, 0, 'external'),
(103, 'https://www.youtube.com/watch?v=O_HyZ5aW76c', 98, 0, 'external'),
(104, 'http://en.support.wordpress.com/code/', 98, 0, 'external'),
(105, 'http://apple.com', 98, 0, 'external'),
(107, '/about-us/trusted-partners/', 25, 65, 'internal') ;

#
# End of data contents of table `wp_yoast_seo_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_seo_meta`
#

DROP TABLE IF EXISTS `wp_yoast_seo_meta`;


#
# Table structure of table `wp_yoast_seo_meta`
#

CREATE TABLE `wp_yoast_seo_meta` (
  `object_id` bigint(20) unsigned NOT NULL,
  `internal_link_count` int(10) unsigned DEFAULT NULL,
  `incoming_link_count` int(10) unsigned DEFAULT NULL,
  UNIQUE KEY `object_id` (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_seo_meta`
#
INSERT INTO `wp_yoast_seo_meta` ( `object_id`, `internal_link_count`, `incoming_link_count`) VALUES
(1, 0, 0),
(2, 0, 1),
(3, 0, 0),
(4, 0, 1),
(5, 0, 0),
(6, 0, 1),
(7, 0, 1),
(8, 1, 1),
(9, 6, 1),
(10, 0, 0),
(12, 0, 0),
(14, 0, 0),
(15, 0, 0),
(16, 0, 0),
(18, 0, 0),
(19, 0, 0),
(20, 0, 0),
(21, 0, 0),
(22, 0, 0),
(23, 0, 0),
(25, 1, 0),
(27, 0, 0),
(29, 0, 0),
(30, 0, 0),
(35, 0, 0),
(45, 0, 0),
(54, 0, 0),
(65, 0, 1),
(71, 0, 0),
(73, 0, 0),
(75, 0, 0),
(76, 0, 0),
(78, 0, 0),
(79, 0, 0),
(80, 0, 0),
(81, 0, 0),
(82, 0, 0),
(83, 0, 0),
(84, 0, 0),
(85, 0, 0),
(87, 0, 0),
(88, 0, 0),
(89, 0, 0),
(91, 0, 0),
(92, 0, 0),
(93, 0, 0),
(94, 0, 0),
(96, 0, 0),
(97, 0, 0),
(98, 0, 0) ;

#
# End of data contents of table `wp_yoast_seo_meta`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

