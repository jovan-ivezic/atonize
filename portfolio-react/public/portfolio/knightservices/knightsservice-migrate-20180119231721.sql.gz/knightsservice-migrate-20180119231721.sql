# WordPress MySQL database migration
#
# Generated: Friday 19. January 2018 23:17 UTC
# Hostname: localhost
# Database: `knightsservice`
# URL: //localhost/knightsservice.com
# Path: /Applications/MAMP/htdocs/knightsservice.com
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_rg_form, wp_rg_form_meta, wp_rg_form_view, wp_rg_incomplete_submissions, wp_rg_lead, wp_rg_lead_detail, wp_rg_lead_detail_long, wp_rg_lead_meta, wp_rg_lead_notes, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users, wp_yoast_seo_links, wp_yoast_seo_meta
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, nav_menu_item, page, post, service
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=677 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/knightsservice.com', 'yes'),
(2, 'home', 'http://localhost/knightsservice.com', 'yes'),
(3, 'blogname', 'Knight Services', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'wp@makespaceweb.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '0', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'closed', 'yes'),
(20, 'default_ping_status', 'closed', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '1', 'yes'),
(27, 'moderation_notify', '0', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:107:{s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:25:"index.php?xsl=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:10:"service/?$";s:27:"index.php?post_type=service";s:40:"service/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=service&feed=$matches[1]";s:35:"service/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=service&feed=$matches[1]";s:27:"service/page/([0-9]{1,})/?$";s:45:"index.php?post_type=service&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:33:"service/.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"service/.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"service/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"service/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"service/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"service/.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:22:"service/(.+?)/embed/?$";s:40:"index.php?service=$matches[1]&embed=true";s:26:"service/(.+?)/trackback/?$";s:34:"index.php?service=$matches[1]&tb=1";s:46:"service/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?service=$matches[1]&feed=$matches[2]";s:41:"service/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?service=$matches[1]&feed=$matches[2]";s:34:"service/(.+?)/page/?([0-9]{1,})/?$";s:47:"index.php?service=$matches[1]&paged=$matches[2]";s:41:"service/(.+?)/comment-page-([0-9]{1,})/?$";s:47:"index.php?service=$matches[1]&cpage=$matches[2]";s:30:"service/(.+?)(?:/([0-9]+))?/?$";s:46:"index.php?service=$matches[1]&page=$matches[2]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=4&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:5:{i:0;s:29:"gravityforms/gravityforms.php";i:1;s:25:"add-to-any/add-to-any.php";i:2;s:34:"advanced-custom-fields-pro/acf.php";i:3;s:24:"wordpress-seo/wp-seo.php";i:4;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'makespace-framework', 'yes'),
(41, 'stylesheet', 'makespace-child', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '1', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '0', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '300', 'yes'),
(59, 'thumbnail_size_h', '300', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '900', 'yes'),
(62, 'medium_size_h', '900', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '2048', 'yes'),
(65, 'large_size_h', '2048', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '1', 'yes'),
(70, 'close_comments_days_old', '1', 'yes'),
(71, 'thread_comments', '0', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', 'America/Kentucky/Louisville', 'yes'),
(83, 'page_for_posts', '5', 'yes'),
(84, 'page_on_front', '4', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:20:"wpseo_manage_options";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:13:"wpseo_manager";a:2:{s:4:"name";s:11:"SEO Manager";s:12:"capabilities";a:37:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;s:20:"wpseo_manage_options";b:1;}}s:12:"wpseo_editor";a:2:{s:4:"name";s:10:"SEO Editor";s:12:"capabilities";a:36:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'nonce_key', 'R)sif=M1Up5$8C$zX^QrWHe2^lq7=*^u$w4sW:fJz|0%lnn%T#l#jJBSRMU8*6-D', 'no'),
(107, 'nonce_salt', '8#}`5}=G7![v=uVH5 ZC]>P{3Br4s%?_#wk,!oDTFL &`3rS`mdMssls5)eu3u||', 'no'),
(108, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'cron', 'a:6:{i:1516419920;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1516463127;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1516463171;a:1:{s:17:"gravityforms_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1516463179;a:1:{s:19:"wpseo-reindex-links";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1516490033;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(112, 'theme_mods_twentyseventeen', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1515599145;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(122, 'auth_key', 'OQ5npnsDS++t!y7|iz[}yLVa-#G|`0.5z6A1D@K&-,!)A/Uym#hs;HtSq]:.AE1:', 'no'),
(123, 'auth_salt', '[jmEm!Jj5(Ve:?_bShdr/@^+j)Bo8r2%Bs|7E&yY]e5{>{|z3n=.+Xn[c]:9Ml;A', 'no'),
(124, 'logged_in_key', '$RYL]oOz[)UfExf$%pZ=7(9qrG=3W%o29,w_>oBKC380Cwm-Q/>S|ODcF,HWn`I#', 'no'),
(125, 'logged_in_salt', 'vq-ZNYEJ|j}cV$Pz$]sq8!4z~1:j},=ECSq(0SF6$oi/t`J1|4CDhUH)Qwvfk?x7', 'no'),
(131, 'can_compress_scripts', '1', 'no'),
(142, 'current_theme', 'Makespace Theme', 'yes'),
(143, 'theme_mods_makespace-child', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:2:{s:7:"primary";i:2;s:9:"secondary";i:3;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(144, 'theme_switched', '', 'yes'),
(145, 'makespace_theme_config', 'a:2:{s:20:"populated_post_types";a:2:{i:0;s:4:"post";i:1;s:7:"service";}s:21:"did_install_framework";i:1;}', 'yes'),
(146, 'rg_gforms_disable_css', '1', 'yes'),
(147, 'rg_gforms_enable_html5', '1', 'yes'),
(148, 'rg_gforms_key', '2962b64bb06ef76f4f98adf34ffb3f64', 'yes'),
(149, 'options_n9m_option_google_map_key', 'AIzaSyAVpUpbK44OAm5lLrf6Q9b5lbI-bZhwYDo', 'no'),
(150, '_options_n9m_option_google_map_key', '', 'no'),
(151, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3MjoiYjNKa1pYSmZhV1E5TlRJeE9EbDhkSGx3WlQxa1pYWmxiRzl3WlhKOFpHRjBaVDB5TURFMUxUQXpMVEUzSURFMU9qRTJPakl5IjtzOjM6InVybCI7czozNToiaHR0cDovL2xvY2FsaG9zdC9rbmlnaHRzc2VydmljZS5jb20iO30=', 'yes'),
(152, 'acf_version', '5.5.10', 'yes'),
(158, 'recently_activated', 'a:0:{}', 'yes'),
(164, 'widget_gform_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(165, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes'),
(166, 'gform_enable_background_updates', '1', 'yes'),
(167, 'rg_gforms_message', '<!--GFM-->', 'yes'),
(170, 'rg_form_version', '2.2.5', 'yes'),
(173, 'gf_imported_theme_file', 'a:1:{s:19:"makespace-framework";b:1;}', 'yes'),
(177, 'wpseo', 'a:25:{s:14:"blocking_files";a:0:{}s:15:"ms_defaults_set";b:0;s:7:"version";s:5:"6.1.1";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:17:"company_or_person";s:0:"";s:20:"disableadvanced_meta";b:1;s:19:"onpage_indexability";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:11:"person_name";s:0:"";s:12:"website_name";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"yandexverify";s:0:"";s:9:"site_type";s:0:"";s:20:"has_multiple_authors";s:0:"";s:16:"environment_type";s:0:"";s:23:"content_analysis_active";b:1;s:23:"keyword_analysis_active";b:1;s:20:"enable_setting_pages";b:1;s:21:"enable_admin_bar_menu";b:1;s:26:"enable_cornerstone_content";b:1;s:24:"enable_text_link_counter";b:1;s:22:"show_onboarding_notice";b:1;s:18:"first_activated_on";b:0;}', 'yes'),
(178, 'wpseo_permalinks', 'a:9:{s:15:"cleanpermalinks";b:0;s:24:"cleanpermalink-extravars";s:0:"";s:29:"cleanpermalink-googlecampaign";b:0;s:31:"cleanpermalink-googlesitesearch";b:0;s:15:"cleanreplytocom";b:0;s:10:"cleanslugs";b:1;s:18:"redirectattachment";b:0;s:17:"stripcategorybase";b:0;s:13:"trailingslash";b:0;}', 'yes'),
(179, 'wpseo_titles', 'a:53:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-dash";s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page not found %%sep%% %%sitename%%";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:13:"showdate-post";b:0;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:1;}', 'yes'),
(180, 'wpseo_social', 'a:20:{s:9:"fb_admins";a:0:{}s:12:"fbconnectkey";s:32:"48053caefc4011e0d2f4062ea462a66d";s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:14:"plus-publisher";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:19:"summary_large_image";s:11:"youtube_url";s:0:"";s:15:"google_plus_url";s:0:"";s:10:"fbadminapp";s:0:"";}', 'yes'),
(181, 'wpseo_rss', 'a:2:{s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";}', 'yes'),
(182, 'wpseo_internallinks', 'a:10:{s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:23:"breadcrumbs-blog-remove";b:0;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:1;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:2:"»";s:23:"post_types-post-maintax";i:0;}', 'yes'),
(183, 'wpseo_xml', 'a:16:{s:22:"disable_author_sitemap";b:1;s:22:"disable_author_noposts";b:1;s:16:"enablexmlsitemap";b:1;s:16:"entries-per-page";i:1000;s:14:"excluded-posts";s:0:"";s:38:"user_role-administrator-not_in_sitemap";b:0;s:31:"user_role-editor-not_in_sitemap";b:0;s:31:"user_role-author-not_in_sitemap";b:0;s:36:"user_role-contributor-not_in_sitemap";b:0;s:35:"user_role-subscriber-not_in_sitemap";b:0;s:30:"post_types-post-not_in_sitemap";b:0;s:30:"post_types-page-not_in_sitemap";b:0;s:36:"post_types-attachment-not_in_sitemap";b:1;s:34:"taxonomies-category-not_in_sitemap";b:0;s:34:"taxonomies-post_tag-not_in_sitemap";b:0;s:37:"taxonomies-post_format-not_in_sitemap";b:0;}', 'yes'),
(184, 'wpseo_flush_rewrite', '1', 'yes'),
(191, 'gf_is_upgrading', '0', 'yes'),
(192, 'gf_previous_db_version', '0', 'yes'),
(193, 'gf_db_version', '2.2.5', 'yes'),
(197, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1516403841;}', 'no'),
(220, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(221, 'wpseo_sitemap_1_cache_validator', '72MRj', 'no'),
(222, 'wpseo_sitemap_26_cache_validator', 'BQkk', 'no'),
(223, 'wpseo_sitemap_27_cache_validator', '73q3n', 'no'),
(224, 'wpseo_sitemap_28_cache_validator', '73q5c', 'no'),
(225, 'wpseo_sitemap_29_cache_validator', '73q72', 'no'),
(226, 'wpseo_sitemap_30_cache_validator', '73q8Q', 'no'),
(227, 'wpseo_sitemap_25_cache_validator', '73s6Q', 'no'),
(234, 'wpseo_sitemap_page_cache_validator', '55Vxx', 'no'),
(236, 'options_msw_ses_send_via_amazon', '1', 'yes'),
(237, '_options_msw_ses_send_via_amazon', 'field_56cbac4a15c80', 'yes'),
(238, 'options_msw_ses_sender_name', 'WordPress', 'yes'),
(239, '_options_msw_ses_sender_name', 'field_56e221da427ab', 'yes'),
(240, 'options_msw_ses_sender_email', 'wp@makespaceweb.com', 'yes'),
(241, '_options_msw_ses_sender_email', 'field_56cbadc4102fe', 'yes'),
(242, 'options_msw_google_map_api_key', 'AIzaSyAVpUpbK44OAm5lLrf6Q9b5lbI-bZhwYDo', 'yes'),
(243, '_options_msw_google_map_api_key', 'field_57baf557b0230', 'yes'),
(244, 'options_site_logo', '47', 'yes'),
(245, '_options_site_logo', 'field_56c53575b5a60', 'yes'),
(246, 'options_favicon', '', 'yes'),
(247, '_options_favicon', 'field_56c53593b5a61', 'yes'),
(248, 'options_menu_type', 'ocn', 'yes'),
(249, '_options_menu_type', 'field_56c7ebe15394e', 'yes'),
(250, 'options_contact_information', '1', 'yes'),
(251, '_options_contact_information', 'field_56c53a165ed97', 'yes'),
(252, 'options_header_javascript', '', 'yes'),
(253, '_options_header_javascript', 'field_56c535d1f0ce4', 'yes'),
(254, 'options_footer_javascript', '', 'yes'),
(255, '_options_footer_javascript', 'field_56c53b93f1877', 'yes'),
(341, 'wpseo_sitemap_cache_validator_global', '6to4C', 'no'),
(385, 'options_contact_information_0_map', 'a:3:{s:7:"address";s:23:"429 Bardstown, KY 40024";s:3:"lat";s:9:"38.041291";s:3:"lng";s:18:"-85.53597830000001";}', 'yes'),
(386, '_options_contact_information_0_map', 'field_56c53a895ed99', 'yes'),
(387, 'options_contact_information_0_address', 'Knight Services\r\nPO Box 429\r\nBardstown, KY 40024\r\n\r\n\r\n', 'yes'),
(388, '_options_contact_information_0_address', 'field_56c7e13924c55', 'yes'),
(389, 'options_contact_information_0_map_marker', '', 'yes'),
(390, '_options_contact_information_0_map_marker', 'field_56c8795c3d137', 'yes'),
(391, 'options_contact_information_0_location_name', 'Knight Services PO Box 429 Bardstown, KY 40024', 'yes'),
(392, '_options_contact_information_0_location_name', 'field_56c7e20b24c5a', 'yes'),
(393, 'options_contact_information_0_phone_number', '(502) 264-2527', 'yes'),
(394, '_options_contact_information_0_phone_number', 'field_56c7e1b924c57', 'yes'),
(395, 'options_contact_information_0_email_address', 'ryan.knight@knightsclaims.com', 'yes'),
(396, '_options_contact_information_0_email_address', 'field_56c7e1dd24c59', 'yes'),
(397, 'options_contact_information_0_fax_number', '', 'yes'),
(398, '_options_contact_information_0_fax_number', 'field_56c7e1cd24c58', 'yes'),
(399, 'options_contact_information_0_social_media_links', '3', 'yes'),
(400, '_options_contact_information_0_social_media_links', 'field_56c87a7c702e0', 'yes'),
(406, 'options_msw_post_type_0_plural_name', 'Services', 'yes'),
(407, '_options_msw_post_type_0_plural_name', 'field_56c5498aae42c', 'yes'),
(408, 'options_msw_post_type_0_singular_name', 'Service', 'yes'),
(409, '_options_msw_post_type_0_singular_name', 'field_56c5497aae42b', 'yes'),
(410, 'options_msw_post_type_0_slug', 'service', 'yes'),
(411, '_options_msw_post_type_0_slug', 'field_56c54a1467543', 'yes'),
(412, 'options_msw_post_type_0_dashicon', 'dashicons-admin-generic', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(413, '_options_msw_post_type_0_dashicon', 'field_56c54a9667544', 'yes'),
(414, 'options_msw_post_type_0_menu_position', '5', 'yes'),
(415, '_options_msw_post_type_0_menu_position', 'field_56c54cf3c6d10', 'yes'),
(416, 'options_msw_post_type_0_menu_name', 'Services', 'yes'),
(417, '_options_msw_post_type_0_menu_name', 'field_56e2260b0fc86', 'yes'),
(418, 'options_msw_post_type_0_options_supports', 'a:5:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:9:"thumbnail";i:3;s:7:"excerpt";i:4;s:15:"page-attributes";}', 'yes'),
(419, '_options_msw_post_type_0_options_supports', 'field_56c54ac44d70c', 'yes'),
(420, 'options_msw_post_type_0_public_information', 'a:1:{i:0;s:11:"has_archive";}', 'yes'),
(421, '_options_msw_post_type_0_public_information', 'field_56c54bd4c6d0f', 'yes'),
(422, 'options_msw_post_type_0_taxonomies', '', 'yes'),
(423, '_options_msw_post_type_0_taxonomies', 'field_56c54d8780da9', 'yes'),
(424, 'options_msw_post_type', '1', 'yes'),
(425, '_options_msw_post_type', 'field_56c54957ae42a', 'yes'),
(426, 'wpseo_sitemap_service_cache_validator', '72MRm', 'no'),
(463, 'category_children', 'a:0:{}', 'yes'),
(543, 'options_footer_cta_bg_image', '113', 'yes'),
(544, '_options_footer_cta_bg_image', 'field_5a5fb9752fd67', 'yes'),
(545, 'options_footer_cta_logo', '114', 'yes'),
(546, '_options_footer_cta_logo', 'field_5a5fb9c42fd6b', 'yes'),
(547, 'options_footer_cta_text', '<h2>Contact <strong>Knight Services</strong> for your\r\nnext residential roof inspection.</h2>', 'yes'),
(548, '_options_footer_cta_text', 'field_5a5fb9812fd68', 'yes'),
(549, 'options_footer_cta_button_text', 'Let us help', 'yes'),
(550, '_options_footer_cta_button_text', 'field_5a5fb9ab2fd69', 'yes'),
(551, 'options_footer_cta_button_link', '', 'yes'),
(552, '_options_footer_cta_button_link', 'field_5a5fb9b32fd6a', 'yes'),
(589, 'options_services_intro', 'Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Nulla porttitor accumsan tincidunt. Donec rutrum congue leo eget malesuada.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quis lorem ut libero malesuada feugiat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula.', 'no'),
(590, '_options_services_intro', 'field_5a61050482b74', 'no'),
(602, 'wpseo_sitemap_41_cache_validator', '4pw5O', 'no'),
(607, 'options_header_image', '125', 'yes'),
(608, '_options_header_image', 'field_5a61eef83a66c', 'yes'),
(635, 'options_contact_information_0_social_media_links_0_site', 'Facebook', 'yes'),
(636, '_options_contact_information_0_social_media_links_0_site', 'field_56c87a89702e1', 'yes'),
(637, 'options_contact_information_0_social_media_links_0_url', '#', 'yes'),
(638, '_options_contact_information_0_social_media_links_0_url', 'field_56c87a97702e2', 'yes'),
(639, 'options_contact_information_0_social_media_links_0_class', 'facebook-official', 'yes'),
(640, '_options_contact_information_0_social_media_links_0_class', 'field_57bb0a976cbb8', 'yes'),
(641, 'options_contact_information_0_social_media_links_1_site', 'Youtube', 'yes'),
(642, '_options_contact_information_0_social_media_links_1_site', 'field_56c87a89702e1', 'yes'),
(643, 'options_contact_information_0_social_media_links_1_url', '#', 'yes'),
(644, '_options_contact_information_0_social_media_links_1_url', 'field_56c87a97702e2', 'yes'),
(645, 'options_contact_information_0_social_media_links_1_class', 'youtube-square', 'yes'),
(646, '_options_contact_information_0_social_media_links_1_class', 'field_57bb0a976cbb8', 'yes'),
(647, 'options_contact_information_0_social_media_links_2_site', 'Instagram', 'yes'),
(648, '_options_contact_information_0_social_media_links_2_site', 'field_56c87a89702e1', 'yes'),
(649, 'options_contact_information_0_social_media_links_2_url', '#', 'yes'),
(650, '_options_contact_information_0_social_media_links_2_url', 'field_56c87a97702e2', 'yes'),
(651, 'options_contact_information_0_social_media_links_2_class', 'instagram', 'yes'),
(652, '_options_contact_information_0_social_media_links_2_class', 'field_57bb0a976cbb8', 'yes'),
(668, 'widget_a2a_share_save_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(669, 'widget_a2a_follow_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(670, 'addtoany_options', 'a:35:{s:8:"position";s:6:"bottom";s:30:"display_in_posts_on_front_page";s:2:"-1";s:33:"display_in_posts_on_archive_pages";s:2:"-1";s:19:"display_in_excerpts";s:2:"-1";s:16:"display_in_posts";s:2:"-1";s:16:"display_in_pages";s:2:"-1";s:22:"display_in_attachments";s:2:"-1";s:15:"display_in_feed";s:2:"-1";s:7:"onclick";s:2:"-1";s:9:"icon_size";s:2:"32";s:7:"icon_bg";s:8:"original";s:13:"icon_bg_color";s:7:"#2a2a2a";s:7:"icon_fg";s:8:"original";s:13:"icon_fg_color";s:7:"#ffffff";s:6:"button";s:4:"NONE";s:13:"button_custom";s:0:"";s:17:"button_show_count";s:2:"-1";s:6:"header";s:0:"";s:23:"additional_js_variables";s:0:"";s:14:"additional_css";s:0:"";s:12:"custom_icons";s:2:"-1";s:16:"custom_icons_url";s:1:"/";s:17:"custom_icons_type";s:3:"png";s:18:"custom_icons_width";s:0:"";s:19:"custom_icons_height";s:0:"";s:5:"cache";s:2:"-1";s:22:"display_in_cpt_service";s:2:"-1";s:11:"button_text";s:5:"Share";s:24:"special_facebook_options";a:1:{s:10:"show_count";s:2:"-1";}s:15:"active_services";a:3:{i:0;s:8:"facebook";i:1;s:7:"twitter";i:2;s:11:"google_plus";}s:29:"special_facebook_like_options";a:1:{s:4:"verb";s:4:"like";}s:29:"special_twitter_tweet_options";a:1:{s:10:"show_count";s:2:"-1";}s:30:"special_google_plusone_options";a:1:{s:10:"show_count";s:2:"-1";}s:33:"special_google_plus_share_options";a:1:{s:10:"show_count";s:2:"-1";}s:29:"special_pinterest_pin_options";a:1:{s:10:"show_count";s:2:"-1";}}', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=574 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 6, '_wp_page_template', 'page_contact.php'),
(4, 11, '_wp_attached_file', '2018/01/unsplash.jpeg'),
(5, 11, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:800;s:4:"file";s:21:"2018/01/unsplash.jpeg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"unsplash-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"unsplash-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"unsplash-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"unsplash-1024x683.jpeg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(6, 10, '_thumbnail_id', '11'),
(10, 15, '_wp_attached_file', '2018/01/unsplash-1.jpeg'),
(11, 15, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:800;s:4:"file";s:23:"2018/01/unsplash-1.jpeg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"unsplash-1-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"unsplash-1-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"unsplash-1-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"unsplash-1-1024x683.jpeg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(12, 14, '_thumbnail_id', '15'),
(16, 19, '_wp_attached_file', '2018/01/unsplash-2.jpeg'),
(17, 19, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:800;s:4:"file";s:23:"2018/01/unsplash-2.jpeg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"unsplash-2-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"unsplash-2-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"unsplash-2-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"unsplash-2-1024x683.jpeg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(18, 18, '_thumbnail_id', '19'),
(23, 24, '_menu_item_type', 'post_type'),
(24, 24, '_menu_item_menu_item_parent', '0'),
(25, 24, '_menu_item_object_id', '4'),
(26, 24, '_menu_item_object', 'page'),
(27, 24, '_menu_item_target', ''),
(28, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(29, 24, '_menu_item_xfn', ''),
(30, 24, '_menu_item_url', ''),
(31, 24, '_menu_item_orphaned', '1515797663'),
(86, 31, '_edit_last', '1'),
(87, 31, '_wp_page_template', 'default'),
(88, 31, '_yoast_wpseo_content_score', '30'),
(89, 31, '_edit_lock', '1516307547:1'),
(90, 33, '_edit_last', '1'),
(91, 33, '_wp_page_template', 'default'),
(92, 33, '_yoast_wpseo_content_score', '30'),
(93, 33, '_edit_lock', '1515798740:1'),
(94, 35, '_edit_last', '1'),
(95, 35, '_wp_page_template', 'default'),
(96, 35, '_yoast_wpseo_content_score', '30'),
(97, 35, '_edit_lock', '1515798755:1'),
(98, 37, '_edit_last', '1'),
(99, 37, '_wp_page_template', 'default'),
(100, 37, '_yoast_wpseo_content_score', '30'),
(101, 37, '_edit_lock', '1515798815:1'),
(102, 39, '_menu_item_type', 'post_type'),
(103, 39, '_menu_item_menu_item_parent', '0'),
(104, 39, '_menu_item_object_id', '35'),
(105, 39, '_menu_item_object', 'page'),
(106, 39, '_menu_item_target', ''),
(107, 39, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(108, 39, '_menu_item_xfn', ''),
(109, 39, '_menu_item_url', ''),
(111, 40, '_menu_item_type', 'post_type'),
(112, 40, '_menu_item_menu_item_parent', '0'),
(113, 40, '_menu_item_object_id', '33'),
(114, 40, '_menu_item_object', 'page'),
(115, 40, '_menu_item_target', ''),
(116, 40, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(117, 40, '_menu_item_xfn', ''),
(118, 40, '_menu_item_url', ''),
(129, 42, '_menu_item_type', 'post_type'),
(130, 42, '_menu_item_menu_item_parent', '0'),
(131, 42, '_menu_item_object_id', '37'),
(132, 42, '_menu_item_object', 'page'),
(133, 42, '_menu_item_target', ''),
(134, 42, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(135, 42, '_menu_item_xfn', ''),
(136, 42, '_menu_item_url', ''),
(138, 43, '_menu_item_type', 'post_type'),
(139, 43, '_menu_item_menu_item_parent', '0'),
(140, 43, '_menu_item_object_id', '6'),
(141, 43, '_menu_item_object', 'page'),
(142, 43, '_menu_item_target', ''),
(143, 43, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(144, 43, '_menu_item_xfn', ''),
(145, 43, '_menu_item_url', ''),
(147, 44, '_menu_item_type', 'post_type'),
(148, 44, '_menu_item_menu_item_parent', '0'),
(149, 44, '_menu_item_object_id', '5'),
(150, 44, '_menu_item_object', 'page'),
(151, 44, '_menu_item_target', ''),
(152, 44, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(153, 44, '_menu_item_xfn', ''),
(154, 44, '_menu_item_url', ''),
(156, 45, '_menu_item_type', 'custom'),
(157, 45, '_menu_item_menu_item_parent', '0'),
(158, 45, '_menu_item_object_id', '45'),
(159, 45, '_menu_item_object', 'custom'),
(160, 45, '_menu_item_target', ''),
(161, 45, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(162, 45, '_menu_item_xfn', ''),
(163, 45, '_menu_item_url', 'tel:5022642527'),
(165, 46, '_wp_attached_file', '2018/01/logo.svg'),
(166, 47, '_wp_attached_file', '2018/01/logo-small-1.svg'),
(167, 50, '_edit_last', '1'),
(168, 50, '_wp_page_template', 'default'),
(169, 50, '_yoast_wpseo_content_score', '30'),
(170, 50, '_edit_lock', '1516142881:1'),
(171, 54, '_wp_attached_file', '2018/01/unsplash-3.jpeg'),
(172, 54, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:800;s:4:"file";s:23:"2018/01/unsplash-3.jpeg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"unsplash-3-300x300.jpeg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"unsplash-3-900x600.jpeg";s:5:"width";i:900;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"unsplash-3-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(173, 53, '_thumbnail_id', '54'),
(174, 59, '_wp_attached_file', '2018/01/unsplash-4.jpeg'),
(175, 59, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:800;s:4:"file";s:23:"2018/01/unsplash-4.jpeg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"unsplash-4-300x300.jpeg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"unsplash-4-900x600.jpeg";s:5:"width";i:900;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"unsplash-4-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(176, 58, '_thumbnail_id', '59'),
(177, 62, '_wp_attached_file', '2018/01/unsplash-5.jpeg'),
(178, 62, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:800;s:4:"file";s:23:"2018/01/unsplash-5.jpeg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"unsplash-5-300x300.jpeg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"unsplash-5-900x600.jpeg";s:5:"width";i:900;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:23:"unsplash-5-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(179, 61, '_thumbnail_id', '62'),
(180, 53, '_wp_trash_meta_status', 'publish'),
(181, 53, '_wp_trash_meta_time', '1516221234') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(182, 53, '_wp_desired_post_slug', 'this-post-has-a-very-long-title-and-should-look-great-on-all-devices'),
(183, 55, '_wp_trash_meta_status', 'publish'),
(184, 55, '_wp_trash_meta_time', '1516221234'),
(185, 55, '_wp_desired_post_slug', 'short-article-title'),
(186, 56, '_wp_trash_meta_status', 'publish'),
(187, 56, '_wp_trash_meta_time', '1516221234'),
(188, 56, '_wp_desired_post_slug', 'this-is-a-fascinating-article-about-us'),
(189, 57, '_wp_trash_meta_status', 'publish'),
(190, 57, '_wp_trash_meta_time', '1516221234'),
(191, 57, '_wp_desired_post_slug', 'post-about-what-is-happening-in-our-industry'),
(192, 58, '_wp_trash_meta_status', 'publish'),
(193, 58, '_wp_trash_meta_time', '1516221234'),
(194, 58, '_wp_desired_post_slug', 'ten-things-we-say-in-sample-blog-posts'),
(195, 60, '_wp_trash_meta_status', 'publish'),
(196, 60, '_wp_trash_meta_time', '1516221234'),
(197, 60, '_wp_desired_post_slug', 'this-post-has-a-very-long-title-and-should-look-great-on-all-devices-2'),
(198, 61, '_wp_trash_meta_status', 'publish'),
(199, 61, '_wp_trash_meta_time', '1516221234'),
(200, 61, '_wp_desired_post_slug', 'short-article-title-2'),
(201, 63, '_wp_trash_meta_status', 'publish'),
(202, 63, '_wp_trash_meta_time', '1516221234'),
(203, 63, '_wp_desired_post_slug', 'this-is-a-fascinating-article-about-us-2'),
(204, 64, '_wp_trash_meta_status', 'publish'),
(205, 64, '_wp_trash_meta_time', '1516221234'),
(206, 64, '_wp_desired_post_slug', 'post-about-what-is-happening-in-our-industry-2'),
(207, 65, '_wp_trash_meta_status', 'publish'),
(208, 65, '_wp_trash_meta_time', '1516221234'),
(209, 65, '_wp_desired_post_slug', 'ten-things-we-say-in-sample-blog-posts-2'),
(210, 66, '_wp_trash_meta_status', 'publish'),
(211, 66, '_wp_trash_meta_time', '1516221234'),
(212, 66, '_wp_desired_post_slug', 'this-post-has-a-very-long-title-and-should-look-great-on-all-devices-3'),
(213, 67, '_edit_last', '1'),
(214, 67, '_edit_lock', '1516403362:1'),
(215, 67, '_yoast_wpseo_content_score', '30'),
(216, 68, '_wp_attached_file', '2018/01/icon.svg'),
(217, 67, '_thumbnail_id', '68'),
(218, 69, '_edit_last', '1'),
(219, 69, '_edit_lock', '1516223725:1'),
(220, 67, 'service_overview', '<h2>OVERVIEW</h2>\r\nSed felis neque viverra in eleifend acpharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae. Fusce varius risus dapibus dolor. Donec tristique faucibus velit aliquam erat volutpat integer sed felis. Quisque odio lacus tincidunt fringilla iaculis vitae dictum a quam cras consectetuer interdum odio pellentesque ideros nulla atenim.'),
(221, 67, '_service_overview', 'field_5a5fb657f502a'),
(222, 72, '_wp_attached_file', '2018/01/group-2.svg'),
(223, 67, 'service_menu_icon', '72'),
(224, 67, '_service_menu_icon', 'field_5a5fb6a321652'),
(225, 73, '_edit_last', '1'),
(226, 73, '_edit_lock', '1516403314:1'),
(227, 74, '_wp_attached_file', '2018/01/group-10.svg'),
(228, 73, 'service_overview', 'Sed felis neque viverra in eleifend acpharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae. Fusce varius risus dapibus dolor. Donec tristique faucibus velit aliquam erat volutpat integer sed felis. Quisque odio lacus tincidunt fringilla iaculis vitae dictum a quam cras consectetuer interdum odio pellentesque ideros nulla atenim.'),
(229, 73, '_service_overview', 'field_5a5fb657f502a'),
(230, 73, 'service_menu_icon', '74'),
(231, 73, '_service_menu_icon', 'field_5a5fb6a321652'),
(232, 73, '_yoast_wpseo_content_score', '30'),
(233, 75, '_edit_last', '1'),
(234, 75, '_edit_lock', '1516403443:1'),
(235, 76, '_wp_attached_file', '2018/01/group-14.svg'),
(236, 75, 'service_overview', 'Sed felis neque viverra in eleifend acpharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae. Fusce varius risus dapibus dolor. Donec tristique faucibus velit aliquam erat volutpat integer sed felis. Quisque odio lacus tincidunt fringilla iaculis vitae dictum a quam cras consectetuer interdum odio pellentesque ideros nulla atenim.'),
(237, 75, '_service_overview', 'field_5a5fb657f502a'),
(238, 75, 'service_menu_icon', '76'),
(239, 75, '_service_menu_icon', 'field_5a5fb6a321652'),
(240, 75, '_yoast_wpseo_content_score', '30'),
(241, 77, '_edit_last', '1'),
(242, 77, '_edit_lock', '1516403480:1'),
(243, 78, '_wp_attached_file', '2018/01/group-15.svg'),
(244, 77, 'service_overview', 'Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui.'),
(245, 77, '_service_overview', 'field_5a5fb657f502a'),
(246, 77, 'service_menu_icon', '78'),
(247, 77, '_service_menu_icon', 'field_5a5fb6a321652'),
(248, 77, '_yoast_wpseo_content_score', '30'),
(249, 79, '_edit_last', '1'),
(250, 79, '_edit_lock', '1516225571:1'),
(251, 4, '_edit_lock', '1516225892:1'),
(252, 94, '_edit_last', '1'),
(253, 94, '_edit_lock', '1516367484:1'),
(254, 4, '_edit_last', '1'),
(255, 4, '_wp_page_template', 'default'),
(256, 4, '_yoast_wpseo_content_score', '30'),
(257, 4, 'home_services_0_home_service', '67'),
(258, 4, '_home_services_0_home_service', 'field_5a5fb7cdf30a6'),
(259, 4, 'home_services_1_home_service', '73'),
(260, 4, '_home_services_1_home_service', 'field_5a5fb7cdf30a6'),
(261, 4, 'home_services_2_home_service', '75'),
(262, 4, '_home_services_2_home_service', 'field_5a5fb7cdf30a6'),
(263, 4, 'home_services_3_home_service', '77'),
(264, 4, '_home_services_3_home_service', 'field_5a5fb7cdf30a6'),
(265, 4, 'home_services', '4'),
(266, 4, '_home_services', 'field_5a5fb7c0f30a5'),
(267, 4, 'about_background_image', '62'),
(268, 4, '_about_background_image', 'field_5a5fb831b62bb'),
(269, 4, 'about_title', 'About us'),
(270, 4, '_about_title', 'field_5a5fb879b62bd'),
(271, 4, 'about_text', 'Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur aliquet quam id dui posuere blandit. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a.'),
(272, 4, '_about_text', 'field_5a5fb868b62bc'),
(273, 4, 'about_button_text', 'Learn More'),
(274, 4, '_about_button_text', 'field_5a5fb887b62be'),
(275, 4, 'about_button_link', '37'),
(276, 4, '_about_button_link', 'field_5a5fb890b62bf'),
(277, 4, 'help_background_image', '107'),
(278, 4, '_help_background_image', 'field_5a5fb8d76d45f'),
(279, 4, 'help_text', '<h2>Find out how our\r\n<strong>drone technology</strong>\r\ncan help you</h2>'),
(280, 4, '_help_text', 'field_5a5fb8ef6d462'),
(281, 4, 'help_button_text', 'Drone technology') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(282, 4, '_help_button_text', 'field_5a5fb8e06d460'),
(283, 4, 'help_button_link', ''),
(284, 4, '_help_button_link', 'field_5a5fb8e46d461'),
(285, 101, 'home_services_0_home_service', '67'),
(286, 101, '_home_services_0_home_service', 'field_5a5fb7cdf30a6'),
(287, 101, 'home_services_1_home_service', '73'),
(288, 101, '_home_services_1_home_service', 'field_5a5fb7cdf30a6'),
(289, 101, 'home_services_2_home_service', '75'),
(290, 101, '_home_services_2_home_service', 'field_5a5fb7cdf30a6'),
(291, 101, 'home_services_3_home_service', '77'),
(292, 101, '_home_services_3_home_service', 'field_5a5fb7cdf30a6'),
(293, 101, 'home_services', '4'),
(294, 101, '_home_services', 'field_5a5fb7c0f30a5'),
(295, 101, 'about_background_image', ''),
(296, 101, '_about_background_image', 'field_5a5fb831b62bb'),
(297, 101, 'about_title', ''),
(298, 101, '_about_title', 'field_5a5fb879b62bd'),
(299, 101, 'about_text', ''),
(300, 101, '_about_text', 'field_5a5fb868b62bc'),
(301, 101, 'about_button_text', ''),
(302, 101, '_about_button_text', 'field_5a5fb887b62be'),
(303, 101, 'about_button_link', ''),
(304, 101, '_about_button_link', 'field_5a5fb890b62bf'),
(305, 101, 'help_background_image', ''),
(306, 101, '_help_background_image', 'field_5a5fb8d76d45f'),
(307, 101, 'help_text', ''),
(308, 101, '_help_text', 'field_5a5fb8ef6d462'),
(309, 101, 'help_button_text', ''),
(310, 101, '_help_button_text', 'field_5a5fb8e06d460'),
(311, 101, 'help_button_link', ''),
(312, 101, '_help_button_link', 'field_5a5fb8e46d461'),
(313, 102, 'home_services_0_home_service', '67'),
(314, 102, '_home_services_0_home_service', 'field_5a5fb7cdf30a6'),
(315, 102, 'home_services_1_home_service', '73'),
(316, 102, '_home_services_1_home_service', 'field_5a5fb7cdf30a6'),
(317, 102, 'home_services_2_home_service', '75'),
(318, 102, '_home_services_2_home_service', 'field_5a5fb7cdf30a6'),
(319, 102, 'home_services_3_home_service', '77'),
(320, 102, '_home_services_3_home_service', 'field_5a5fb7cdf30a6'),
(321, 102, 'home_services', '4'),
(322, 102, '_home_services', 'field_5a5fb7c0f30a5'),
(323, 102, 'about_background_image', '62'),
(324, 102, '_about_background_image', 'field_5a5fb831b62bb'),
(325, 102, 'about_title', ''),
(326, 102, '_about_title', 'field_5a5fb879b62bd'),
(327, 102, 'about_text', ''),
(328, 102, '_about_text', 'field_5a5fb868b62bc'),
(329, 102, 'about_button_text', ''),
(330, 102, '_about_button_text', 'field_5a5fb887b62be'),
(331, 102, 'about_button_link', ''),
(332, 102, '_about_button_link', 'field_5a5fb890b62bf'),
(333, 102, 'help_background_image', ''),
(334, 102, '_help_background_image', 'field_5a5fb8d76d45f'),
(335, 102, 'help_text', ''),
(336, 102, '_help_text', 'field_5a5fb8ef6d462'),
(337, 102, 'help_button_text', ''),
(338, 102, '_help_button_text', 'field_5a5fb8e06d460'),
(339, 102, 'help_button_link', ''),
(340, 102, '_help_button_link', 'field_5a5fb8e46d461'),
(341, 103, 'home_services_0_home_service', '67'),
(342, 103, '_home_services_0_home_service', 'field_5a5fb7cdf30a6'),
(343, 103, 'home_services_1_home_service', '73'),
(344, 103, '_home_services_1_home_service', 'field_5a5fb7cdf30a6'),
(345, 103, 'home_services_2_home_service', '75'),
(346, 103, '_home_services_2_home_service', 'field_5a5fb7cdf30a6'),
(347, 103, 'home_services_3_home_service', '77'),
(348, 103, '_home_services_3_home_service', 'field_5a5fb7cdf30a6'),
(349, 103, 'home_services', '4'),
(350, 103, '_home_services', 'field_5a5fb7c0f30a5'),
(351, 103, 'about_background_image', '62'),
(352, 103, '_about_background_image', 'field_5a5fb831b62bb'),
(353, 103, 'about_title', 'About us'),
(354, 103, '_about_title', 'field_5a5fb879b62bd'),
(355, 103, 'about_text', 'Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur aliquet quam id dui posuere blandit. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a.'),
(356, 103, '_about_text', 'field_5a5fb868b62bc'),
(357, 103, 'about_button_text', 'Learn More'),
(358, 103, '_about_button_text', 'field_5a5fb887b62be'),
(359, 103, 'about_button_link', '37'),
(360, 103, '_about_button_link', 'field_5a5fb890b62bf'),
(361, 103, 'help_background_image', ''),
(362, 103, '_help_background_image', 'field_5a5fb8d76d45f'),
(363, 103, 'help_text', ''),
(364, 103, '_help_text', 'field_5a5fb8ef6d462'),
(365, 103, 'help_button_text', ''),
(366, 103, '_help_button_text', 'field_5a5fb8e06d460'),
(367, 103, 'help_button_link', ''),
(368, 103, '_help_button_link', 'field_5a5fb8e46d461'),
(369, 5, '_edit_lock', '1516225894:1'),
(370, 5, '_edit_last', '1'),
(371, 5, '_yoast_wpseo_content_score', '30'),
(372, 107, '_wp_attached_file', '2018/01/sky.jpg'),
(373, 107, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1920;s:6:"height";i:726;s:4:"file";s:15:"2018/01/sky.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"sky-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:15:"sky-900x340.jpg";s:5:"width";i:900;s:6:"height";i:340;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:15:"sky-768x290.jpg";s:5:"width";i:768;s:6:"height";i:290;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(374, 108, 'home_services_0_home_service', '67'),
(375, 108, '_home_services_0_home_service', 'field_5a5fb7cdf30a6'),
(376, 108, 'home_services_1_home_service', '73'),
(377, 108, '_home_services_1_home_service', 'field_5a5fb7cdf30a6'),
(378, 108, 'home_services_2_home_service', '75'),
(379, 108, '_home_services_2_home_service', 'field_5a5fb7cdf30a6'),
(380, 108, 'home_services_3_home_service', '77'),
(381, 108, '_home_services_3_home_service', 'field_5a5fb7cdf30a6') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(382, 108, 'home_services', '4'),
(383, 108, '_home_services', 'field_5a5fb7c0f30a5'),
(384, 108, 'about_background_image', '62'),
(385, 108, '_about_background_image', 'field_5a5fb831b62bb'),
(386, 108, 'about_title', 'About us'),
(387, 108, '_about_title', 'field_5a5fb879b62bd'),
(388, 108, 'about_text', 'Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur aliquet quam id dui posuere blandit. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a.'),
(389, 108, '_about_text', 'field_5a5fb868b62bc'),
(390, 108, 'about_button_text', 'Learn More'),
(391, 108, '_about_button_text', 'field_5a5fb887b62be'),
(392, 108, 'about_button_link', '37'),
(393, 108, '_about_button_link', 'field_5a5fb890b62bf'),
(394, 108, 'help_background_image', '107'),
(395, 108, '_help_background_image', 'field_5a5fb8d76d45f'),
(396, 108, 'help_text', '<h2>Find out how our</h2>\r\n<h2><strong>drone technology</strong></h2>\r\n<h2>can help you</h2>'),
(397, 108, '_help_text', 'field_5a5fb8ef6d462'),
(398, 108, 'help_button_text', ''),
(399, 108, '_help_button_text', 'field_5a5fb8e06d460'),
(400, 108, 'help_button_link', ''),
(401, 108, '_help_button_link', 'field_5a5fb8e46d461'),
(402, 4, 'help_detail_image', '110'),
(403, 4, '_help_detail_image', 'field_5a5fc05279a3c'),
(404, 109, 'home_services_0_home_service', '67'),
(405, 109, '_home_services_0_home_service', 'field_5a5fb7cdf30a6'),
(406, 109, 'home_services_1_home_service', '73'),
(407, 109, '_home_services_1_home_service', 'field_5a5fb7cdf30a6'),
(408, 109, 'home_services_2_home_service', '75'),
(409, 109, '_home_services_2_home_service', 'field_5a5fb7cdf30a6'),
(410, 109, 'home_services_3_home_service', '77'),
(411, 109, '_home_services_3_home_service', 'field_5a5fb7cdf30a6'),
(412, 109, 'home_services', '4'),
(413, 109, '_home_services', 'field_5a5fb7c0f30a5'),
(414, 109, 'about_background_image', '62'),
(415, 109, '_about_background_image', 'field_5a5fb831b62bb'),
(416, 109, 'about_title', 'About us'),
(417, 109, '_about_title', 'field_5a5fb879b62bd'),
(418, 109, 'about_text', 'Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur aliquet quam id dui posuere blandit. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a.'),
(419, 109, '_about_text', 'field_5a5fb868b62bc'),
(420, 109, 'about_button_text', 'Learn More'),
(421, 109, '_about_button_text', 'field_5a5fb887b62be'),
(422, 109, 'about_button_link', '37'),
(423, 109, '_about_button_link', 'field_5a5fb890b62bf'),
(424, 109, 'help_background_image', '107'),
(425, 109, '_help_background_image', 'field_5a5fb8d76d45f'),
(426, 109, 'help_text', '<h2>Find out how our2>\r\n<strong>drone technology</strong>\r\ncan help you</h2>'),
(427, 109, '_help_text', 'field_5a5fb8ef6d462'),
(428, 109, 'help_button_text', ''),
(429, 109, '_help_button_text', 'field_5a5fb8e06d460'),
(430, 109, 'help_button_link', ''),
(431, 109, '_help_button_link', 'field_5a5fb8e46d461'),
(432, 109, 'help_detail_image', ''),
(433, 109, '_help_detail_image', 'field_5a5fc05279a3c'),
(434, 110, '_wp_attached_file', '2018/01/drone.png'),
(435, 110, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:607;s:6:"height";i:372;s:4:"file";s:17:"2018/01/drone.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"drone-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(436, 111, 'home_services_0_home_service', '67'),
(437, 111, '_home_services_0_home_service', 'field_5a5fb7cdf30a6'),
(438, 111, 'home_services_1_home_service', '73'),
(439, 111, '_home_services_1_home_service', 'field_5a5fb7cdf30a6'),
(440, 111, 'home_services_2_home_service', '75'),
(441, 111, '_home_services_2_home_service', 'field_5a5fb7cdf30a6'),
(442, 111, 'home_services_3_home_service', '77'),
(443, 111, '_home_services_3_home_service', 'field_5a5fb7cdf30a6'),
(444, 111, 'home_services', '4'),
(445, 111, '_home_services', 'field_5a5fb7c0f30a5'),
(446, 111, 'about_background_image', '62'),
(447, 111, '_about_background_image', 'field_5a5fb831b62bb'),
(448, 111, 'about_title', 'About us'),
(449, 111, '_about_title', 'field_5a5fb879b62bd'),
(450, 111, 'about_text', 'Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur aliquet quam id dui posuere blandit. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a.'),
(451, 111, '_about_text', 'field_5a5fb868b62bc'),
(452, 111, 'about_button_text', 'Learn More'),
(453, 111, '_about_button_text', 'field_5a5fb887b62be'),
(454, 111, 'about_button_link', '37'),
(455, 111, '_about_button_link', 'field_5a5fb890b62bf'),
(456, 111, 'help_background_image', '107'),
(457, 111, '_help_background_image', 'field_5a5fb8d76d45f'),
(458, 111, 'help_text', '<h2>Find out how our\r\n<strong>drone technology</strong>\r\ncan help you</h2>'),
(459, 111, '_help_text', 'field_5a5fb8ef6d462'),
(460, 111, 'help_button_text', ''),
(461, 111, '_help_button_text', 'field_5a5fb8e06d460'),
(462, 111, 'help_button_link', ''),
(463, 111, '_help_button_link', 'field_5a5fb8e46d461'),
(464, 111, 'help_detail_image', '110'),
(465, 111, '_help_detail_image', 'field_5a5fc05279a3c'),
(466, 112, 'home_services_0_home_service', '67'),
(467, 112, '_home_services_0_home_service', 'field_5a5fb7cdf30a6'),
(468, 112, 'home_services_1_home_service', '73'),
(469, 112, '_home_services_1_home_service', 'field_5a5fb7cdf30a6'),
(470, 112, 'home_services_2_home_service', '75'),
(471, 112, '_home_services_2_home_service', 'field_5a5fb7cdf30a6'),
(472, 112, 'home_services_3_home_service', '77'),
(473, 112, '_home_services_3_home_service', 'field_5a5fb7cdf30a6'),
(474, 112, 'home_services', '4'),
(475, 112, '_home_services', 'field_5a5fb7c0f30a5'),
(476, 112, 'about_background_image', '62'),
(477, 112, '_about_background_image', 'field_5a5fb831b62bb'),
(478, 112, 'about_title', 'About us'),
(479, 112, '_about_title', 'field_5a5fb879b62bd'),
(480, 112, 'about_text', 'Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Curabitur aliquet quam id dui posuere blandit. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a.'),
(481, 112, '_about_text', 'field_5a5fb868b62bc') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(482, 112, 'about_button_text', 'Learn More'),
(483, 112, '_about_button_text', 'field_5a5fb887b62be'),
(484, 112, 'about_button_link', '37'),
(485, 112, '_about_button_link', 'field_5a5fb890b62bf'),
(486, 112, 'help_background_image', '107'),
(487, 112, '_help_background_image', 'field_5a5fb8d76d45f'),
(488, 112, 'help_text', '<h2>Find out how our\r\n<strong>drone technology</strong>\r\ncan help you</h2>'),
(489, 112, '_help_text', 'field_5a5fb8ef6d462'),
(490, 112, 'help_button_text', 'Drone technology'),
(491, 112, '_help_button_text', 'field_5a5fb8e06d460'),
(492, 112, 'help_button_link', ''),
(493, 112, '_help_button_link', 'field_5a5fb8e46d461'),
(494, 112, 'help_detail_image', '110'),
(495, 112, '_help_detail_image', 'field_5a5fc05279a3c'),
(496, 113, '_wp_attached_file', '2018/01/roofs.jpg'),
(497, 113, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1920;s:6:"height";i:739;s:4:"file";s:17:"2018/01/roofs.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"roofs-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"roofs-900x346.jpg";s:5:"width";i:900;s:6:"height";i:346;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:17:"roofs-768x296.jpg";s:5:"width";i:768;s:6:"height";i:296;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(498, 114, '_wp_attached_file', '2018/01/logo-2.svg'),
(499, 116, '_edit_last', '1'),
(500, 116, '_edit_lock', '1516307609:1'),
(501, 118, '_menu_item_type', 'post_type_archive'),
(502, 118, '_menu_item_menu_item_parent', '0'),
(503, 118, '_menu_item_object_id', '-50'),
(504, 118, '_menu_item_object', 'service'),
(505, 118, '_menu_item_target', ''),
(506, 118, '_menu_item_classes', 'a:1:{i:0;s:19:"pt-special-dropdown";}'),
(507, 118, '_menu_item_xfn', ''),
(508, 118, '_menu_item_url', ''),
(510, 119, '_menu_item_type', 'post_type'),
(511, 119, '_menu_item_menu_item_parent', '118'),
(512, 119, '_menu_item_object_id', '77'),
(513, 119, '_menu_item_object', 'service'),
(514, 119, '_menu_item_target', ''),
(515, 119, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(516, 119, '_menu_item_xfn', ''),
(517, 119, '_menu_item_url', ''),
(519, 120, '_menu_item_type', 'post_type'),
(520, 120, '_menu_item_menu_item_parent', '118'),
(521, 120, '_menu_item_object_id', '75'),
(522, 120, '_menu_item_object', 'service'),
(523, 120, '_menu_item_target', ''),
(524, 120, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(525, 120, '_menu_item_xfn', ''),
(526, 120, '_menu_item_url', ''),
(528, 121, '_menu_item_type', 'post_type'),
(529, 121, '_menu_item_menu_item_parent', '118'),
(530, 121, '_menu_item_object_id', '73'),
(531, 121, '_menu_item_object', 'service'),
(532, 121, '_menu_item_target', ''),
(533, 121, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(534, 121, '_menu_item_xfn', ''),
(535, 121, '_menu_item_url', ''),
(537, 122, '_menu_item_type', 'post_type'),
(538, 122, '_menu_item_menu_item_parent', '118'),
(539, 122, '_menu_item_object_id', '67'),
(540, 122, '_menu_item_object', 'service'),
(541, 122, '_menu_item_target', ''),
(542, 122, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(543, 122, '_menu_item_xfn', ''),
(544, 122, '_menu_item_url', ''),
(546, 31, '_wp_trash_meta_status', 'publish'),
(547, 31, '_wp_trash_meta_time', '1516367171'),
(548, 31, '_wp_desired_post_slug', 'ladder-services'),
(549, 50, '_wp_trash_meta_status', 'publish'),
(550, 50, '_wp_trash_meta_time', '1516367171'),
(551, 50, '_wp_desired_post_slug', 'ladder-assist'),
(552, 125, '_wp_attached_file', '2018/01/shutterstock-384604915-shingle-roof.jpg'),
(553, 125, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2760;s:6:"height";i:800;s:4:"file";s:47:"2018/01/shutterstock-384604915-shingle-roof.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:47:"shutterstock-384604915-shingle-roof-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:47:"shutterstock-384604915-shingle-roof-900x261.jpg";s:5:"width";i:900;s:6:"height";i:261;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:47:"shutterstock-384604915-shingle-roof-768x223.jpg";s:5:"width";i:768;s:6:"height";i:223;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:48:"shutterstock-384604915-shingle-roof-2048x594.jpg";s:5:"width";i:2048;s:6:"height";i:594;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:48:"shutterstock-384604915-shingle-roof-2048x594.jpg";s:5:"width";i:2048;s:6:"height";i:594;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(554, 126, '_edit_last', '1'),
(555, 126, '_edit_lock', '1516376401:1'),
(556, 6, '_edit_lock', '1516376360:1'),
(557, 128, '_wp_attached_file', '2018/01/coverage-map.svg'),
(558, 6, '_edit_last', '1'),
(559, 6, '_yoast_wpseo_content_score', '30'),
(560, 6, 'coverage_map_image', '128'),
(561, 6, '_coverage_map_image', 'field_5a621062aac29'),
(562, 129, 'coverage_map_image', '128'),
(563, 129, '_coverage_map_image', 'field_5a621062aac29'),
(564, 6, 'coverage_title', 'Our coverage'),
(565, 6, '_coverage_title', 'field_5a621186babc5'),
(566, 6, 'coverage_text', 'Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Sed porttitor lectus nibh. Curabitur aliquet quam id dui posuere blandit.\r\n\r\nDonec rutrum congue leo eget malesuada. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Nulla quis lorem ut libero malesuada feugiat.'),
(567, 6, '_coverage_text', 'field_5a62118dbabc6'),
(568, 132, 'coverage_map_image', '128'),
(569, 132, '_coverage_map_image', 'field_5a621062aac29'),
(570, 132, 'coverage_title', 'Our coverage'),
(571, 132, '_coverage_title', 'field_5a621186babc5'),
(572, 132, 'coverage_text', 'Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Sed porttitor lectus nibh. Curabitur aliquet quam id dui posuere blandit.\r\n\r\nDonec rutrum congue leo eget malesuada. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Nulla quis lorem ut libero malesuada feugiat.'),
(573, 132, '_coverage_text', 'field_5a62118dbabc6') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(4, 1, '2018-01-10 15:45:45', '2018-01-10 15:45:45', '', 'Home Page', '', 'publish', 'closed', 'closed', '', 'home-page', '', '', '2018-01-17 16:47:09', '2018-01-17 21:47:09', '', 0, 'http://knightsservice/home-page/', 0, 'page', '', 0),
(5, 1, '2018-01-10 15:45:45', '2018-01-10 15:45:45', '', 'The Knight Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2018-01-17 16:44:08', '2018-01-17 21:44:08', '', 0, 'http://knightsservice/blog/', 10, 'page', '', 0),
(6, 1, '2018-01-10 15:45:45', '2018-01-10 15:45:45', '', 'Contact Us', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2018-01-19 10:41:41', '2018-01-19 15:41:41', '', 0, 'http://knightsservice/contact/', 20, 'page', '', 0),
(7, 1, '2018-01-10 15:45:45', '2018-01-10 15:45:45', 'Throughout this Online Privacy Policy, &quot;we&quot;, &quot;us&quot;, or &quot;our&quot; refers to Knight Services, and Site refers to this website.\n\nWe are dedicated to protecting your privacy while you are using or accessing this Site. This Online Privacy Policy applies solely to the Site. Once you enter another web site, via a link provided on the Site or by other methods, we are no longer responsible for the privacy practices of the linked site. You should review the privacy statements of those web sites as posted on the individual web sites. We reserve the right to collect use and user statistics from the Site. Use and user statistics will be used to track information such as visitor interests, which may be used to enhance and improve the Site in the future; however, such use and user statistics do not include personally identifiable information. Generally, no personally identifiable information is tracked or collected on the generally accessible portions of the Site, unless you voluntarily provide such information to us via web forms or surveys on the Site. However, if you access certain portions of the Site by using a particular account authorized by us and/or a user name and password, certain information including your user name and password will be collected and identified with the information we have on file for that user name, and the information and materials you access and actions you take while logged on with that user name, will be tracked by us.\n\nWe do not sell or otherwise distribute names or other personally identifiable information to third parties for direct marketing, sales or any other purposes. Except as noted herein, any personally identifiable information received by us is used solely for internal purposes and is not shared with any nonaffiliated organizations unless required to do so by law, upon governmental request or in response to a court order.\n\nThe Site is not designed or intended to attract children under the age of 13. We do not collect any personally identifiable information, whether or not such information is voluntarily provided, from any person we actually know is under the age of 13. If a parent or guardian accesses the Site on behalf of a person under the age of 13, that parent or guardian is responsible for protecting that child’s personally identifiable information.\n\nFor questions, comments or assistance, please contact us.', 'Online Privacy Policy', '', 'publish', 'closed', 'closed', '', 'privacy-policy', '', '', '2018-01-10 15:45:45', '2018-01-10 15:45:45', '', 0, 'http://knightsservice/privacy-policy/', 97, 'page', '', 0),
(8, 1, '2018-01-10 15:45:45', '2018-01-10 15:45:45', 'All information on this website is property of <strong>Knight Services</strong> &copy;2018.\n\nAll material at this website, such as text, images, markup, CSS, programming, TITLE tag content, META element tag content, and design, is &copy;2018 to <strong>Knight Services</strong> and may not be reproduced elsewhere in any way without our express written permission.\n<h2>Responsive Design, Images, and Artwork Cannot Be Reproduced</h2>\nThis <a title="responsive web design" href="https://www.makespaceweb.com/services/louisville-website-design/" target="_blank">responsive web design</a> and unique combination of images, colors, sizes, typography, positioning, CSS, HTML and other markup and programming is &copy;2018 to <strong>Knight Services</strong> and cannot be reproduced or used anywhere else, whether in part or in whole. No exceptions.\n<h2>Website Design and Development</h2>\nThis website was created, designed and developed by the <a title="Louisville web design company Makespace" href="https://www.makespaceweb.com/" target="_blank">Louisville web design company Makespace</a>. Any inquiries about this <a title="web design" href="https://www.makespaceweb.com/services/louisville-website-design" target="_blank">website design</a>, <a title="WordPress development" href="https://www.makespaceweb.com/services/louisville-website-design/index.html#anchor-dev" target="_blank">WordPress development</a>, and other <a title="digital marketing services" href="https://www.makespaceweb.com/services/" target="_blank">digital marketing services</a> of this website should be directed to <a href="&#109;&#97;&#105;&#108;&#116;&#111;&#58;&#105;&#110;&#102;&#111;&#64;&#109;&#97;&#107;&#101;&#115;&#112;&#97;&#99;&#101;&#119;&#101;&#98;&#46;&#99;&#111;&#109;" target="_blank">&#105;&#110;&#102;&#111;&#64;&#109;&#97;&#107;&#101;&#115;&#112;&#97;&#99;&#101;&#119;&#101;&#98;&#46;&#99;&#111;&#109;</a>, or you may stop by our Louisville office or our <a href="https://www.makespaceweb.com/Orlando_Web_Design" target="_blank">Orlando web design</a> location.\n\nYou can visit the Louisville web design company online at <a title="www.makespaceweb.com" href="https://www.makespaceweb.com/" target="_blank">www.makespaceweb.com</a>. Makespace reserves the right to use this website in its <a title="web design portfolio" href="https://www.makespaceweb.com/web-design-portfolio/" target="_blank">web design portfolio</a>.\n<h2>Logo and Branding</h2>\nThis website&#8217;s <a href="https://www.oohology.com/Services/Branding" target="_blank">logo and branding</a> may have been created by Oohology - <a href="https://www.oohology.com" target="_blank">Louisville&#8217;s #1 branding, advertising, and digital ad agency</a>. If so, all rights and ownership of the brand assets belong to <strong>Knight Services</strong> and you should contact <strong>Knight Services</strong> for usage rights. If unsure, you may call <a href="https://www.oohology.com/" target="_blank">Oohology</a> to learn more.', 'Site Info', '', 'publish', 'closed', 'closed', '', 'site-info', '', '', '2018-01-10 15:45:45', '2018-01-10 15:45:45', '', 0, 'http://knightsservice/site-info/', 98, 'page', '', 0),
(9, 1, '2018-01-10 15:45:45', '2018-01-10 15:45:45', '[makespace_sitemap]', 'Site Map', '', 'publish', 'closed', 'closed', '', 'site-map', '', '', '2018-01-10 15:45:45', '2018-01-10 15:45:45', '', 0, 'http://knightsservice/site-map/', 99, 'page', '', 0),
(10, 1, '2018-01-09 15:45:50', '2018-01-09 20:45:50', '<h2>Headings</h2>\n<h1>Header one</h1>\n<h2>Header two</h2>\n<h3>Header three</h3>\n<h4>Header four</h4>\n<h5>Header five</h5>\n<h6>Header six</h6>\n<h2>Blockquotes</h2>\nSingle line blockquote:\n<blockquote>Stay hungry. Stay foolish.</blockquote>\nMulti line blockquote with a cite reference:\n<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things.</blockquote>\n<cite>Steve Jobs</cite> - Apple Worldwide Developers\' Conference, 1997\n<h2>Tables</h2>\n<table>\n<thead>\n<tr>\n<th>Employee</th>\n<th>Salary</th>\n<th></th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<th><a href="http://example.org/">John Doe</a></th>\n<td>$1</td>\n<td>Because that\'s all Steve Jobs needed for a salary.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Doe</a></th>\n<td>$100K</td>\n<td>For all the blogging she does.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Fred Bloggs</a></th>\n<td>$100M</td>\n<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Bloggs</a></th>\n<td>$100B</td>\n<td>With hair like that?! Enough said...</td>\n</tr>\n</tbody>\n</table>\n<h2>Definition Lists</h2>\n<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>\n<h2>Unordered Lists (Nested)</h2>\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n<h2>Ordered List (Nested)</h2>\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n<h2>HTML Tags</h2>\nThese supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.\n\n<strong>Address Tag</strong>\n\n<address>1 Infinite Loop\nCupertino, CA 95014\nUnited States</address><strong>Anchor Tag (aka. Link)</strong>\n\nThis is an example of a <a title="Apple" href="http://apple.com">link</a>.\n\n<strong>Abbreviation Tag</strong>\n\nThe abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".\n\n<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>\n\nThe acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".\n\n<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThese tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.\n\n<strong>Cite Tag</strong>\n\n"Code is poetry." --<cite>Automattic</cite>\n\n<strong>Code Tag</strong>\n\nYou will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.\n\n<strong>Delete Tag</strong>\n\nThis tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).\n\n<strong>Emphasize Tag</strong>\n\nThe emphasize tag should <em>italicize</em> text.\n\n<strong>Insert Tag</strong>\n\nThis tag should denote <ins>inserted</ins> text.\n\n<strong>Keyboard Tag</strong>\n\nThis scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Preformatted Tag</strong>\n\nThis tag styles large blocks of code.\n<pre>.post-title {\n	margin: 0 0 5px;\n	font-weight: bold;\n	font-size: 38px;\n	line-height: 1.2;\n	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;\n}</pre>\n<strong>Quote Tag</strong>\n\n<q>Developers, developers, developers...</q> --Steve Ballmer\n\n<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis tag shows <span style="text-decoration: line-through;">strike-through text</span>\n\n<strong>Strong Tag</strong>\n\nThis tag shows <strong>bold<strong> text.</strong></strong>\n\n<strong>Subscript Tag</strong>\n\nGetting our science styling on with H<sub>2</sub>O, which should push the "2" down.\n\n<strong>Superscript Tag</strong>\n\nStill sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.\n\n<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Variable Tag</strong>\n\nThis allows you to denote <var>variables</var>.', 'This Post Has a Very Long Title and Should Look Great on All Devices', '', 'publish', 'closed', 'closed', '', 'this-post-has-a-very-long-title-and-should-look-great-on-all-devices', '', '', '2018-01-09 15:45:50', '2018-01-09 20:45:50', '', 0, 'http://knightsservice/2018/01/09/this-post-has-a-very-long-title-and-should-look-great-on-all-devices/', 0, 'post', '', 0),
(11, 1, '2018-01-10 10:45:50', '2018-01-10 15:45:50', '', 'Sample Image #1', '', 'inherit', 'closed', 'closed', '', 'sample-image-1', '', '', '2018-01-10 10:45:50', '2018-01-10 15:45:50', '', 10, 'http://knightsservice/wp-content/uploads/2018/01/unsplash.jpeg', 0, 'attachment', 'image/jpeg', 0),
(12, 1, '2018-01-08 15:45:50', '2018-01-08 20:45:50', '<h1>Lorem Ipsum</h1>\n\n<blockquote>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit..."\n"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain..."</blockquote>\n\n<h2>What is Lorem Ipsum?</h2>\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<h3>Why do we use it?</h3>\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>', 'Short Article Title', '', 'publish', 'closed', 'closed', '', 'short-article-title', '', '', '2018-01-08 15:45:50', '2018-01-08 20:45:50', '', 0, 'http://knightsservice/2018/01/08/short-article-title/', 0, 'post', '', 0),
(13, 1, '2018-01-07 15:45:50', '2018-01-07 20:45:50', '<h1>Lorem Ipsum</h1>\n\n<blockquote>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit..."\n"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain..."</blockquote>\n\n<h2>What is Lorem Ipsum?</h2>\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<h3>Why do we use it?</h3>\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>', 'This Is a Fascinating Article About Us', '', 'publish', 'closed', 'closed', '', 'this-is-a-fascinating-article-about-us', '', '', '2018-01-07 15:45:50', '2018-01-07 20:45:50', '', 0, 'http://knightsservice/2018/01/07/this-is-a-fascinating-article-about-us/', 0, 'post', '', 0),
(14, 1, '2018-01-06 15:45:50', '2018-01-06 20:45:50', '<h1>Lorem Ipsum</h1>\n\n<blockquote>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit..."\n"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain..."</blockquote>\n\n<h2>What is Lorem Ipsum?</h2>\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<h3>Why do we use it?</h3>\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>', 'Post About What Is Happening In Our Industry', '', 'publish', 'closed', 'closed', '', 'post-about-what-is-happening-in-our-industry', '', '', '2018-01-06 15:45:50', '2018-01-06 20:45:50', '', 0, 'http://knightsservice/2018/01/06/post-about-what-is-happening-in-our-industry/', 0, 'post', '', 0),
(15, 1, '2018-01-10 10:45:50', '2018-01-10 15:45:50', '', 'Sample Image #4', '', 'inherit', 'closed', 'closed', '', 'sample-image-4', '', '', '2018-01-10 10:45:50', '2018-01-10 15:45:50', '', 14, 'http://knightsservice/wp-content/uploads/2018/01/unsplash-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(16, 1, '2018-01-05 15:45:50', '2018-01-05 20:45:50', 'Welcome to image alignment! The best way to demonstrate the ebb and flow of the various image positioning options is to nestle them snuggly among an ocean of words. Grab a paddle and let\'s get started.\n\nOn the topic of alignment, it should be noted that users can choose from the options of <em>None</em>, <em>Left</em>, <em>Right, </em>and <em>Center</em>. In addition, they also get the options of <em>Thumbnail</em>, <em>Medium</em>, <em>Large</em> &amp; <em>Fullsize</em>.\n<p style="text-align:center;"><img class="size-full wp-image-906 aligncenter" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /></p>\nThe image above happens to be <em><strong>centered</strong></em>.\n\n<strong><img class="size-full wp-image-904 alignleft" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n<img class="alignnone wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" />\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n<img class="size-full wp-image-905 alignright" title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" />\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd just when you thought we were done, we\'re going to do them all over again with captions!\n\n[caption id="attachment_906" align="aligncenter" width="580"]<img class="size-full wp-image-906" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /> Look at 580x300 getting some <a title="Image Settings" href="http://en.support.wordpress.com/images/image-settings/">caption</a> love.[/caption]\n\nThe image above happens to be <em><strong>centered</strong></em>. The caption also has a link in it, just to see if it does anything funky.\n\n[caption id="attachment_904" align="alignleft" width="150"]<img class="size-full wp-image-904" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /> Itty-bitty caption.[/caption]\n\n<strong></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n[caption id="attachment_907" align="alignnone" width="1200"]<img class=" wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" /> Massive image comment for your eyeballs.[/caption]\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n[caption id="attachment_905" align="alignright" width="300"]<img class="size-full wp-image-905 " title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" /> Feels good to be right all the time.[/caption]\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd that\'s a wrap, yo! You survived the tumultuous waters of alignment. Image alignment achievement unlocked!', 'Ten Things We Say In Sample Blog Posts', '', 'publish', 'closed', 'closed', '', 'ten-things-we-say-in-sample-blog-posts', '', '', '2018-01-05 15:45:50', '2018-01-05 20:45:50', '', 0, 'http://knightsservice/2018/01/05/ten-things-we-say-in-sample-blog-posts/', 0, 'post', '', 0),
(17, 1, '2018-01-04 15:45:50', '2018-01-04 20:45:50', '<h2>Headings</h2>\n<h1>Header one</h1>\n<h2>Header two</h2>\n<h3>Header three</h3>\n<h4>Header four</h4>\n<h5>Header five</h5>\n<h6>Header six</h6>\n<h2>Blockquotes</h2>\nSingle line blockquote:\n<blockquote>Stay hungry. Stay foolish.</blockquote>\nMulti line blockquote with a cite reference:\n<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things.</blockquote>\n<cite>Steve Jobs</cite> - Apple Worldwide Developers\' Conference, 1997\n<h2>Tables</h2>\n<table>\n<thead>\n<tr>\n<th>Employee</th>\n<th>Salary</th>\n<th></th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<th><a href="http://example.org/">John Doe</a></th>\n<td>$1</td>\n<td>Because that\'s all Steve Jobs needed for a salary.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Doe</a></th>\n<td>$100K</td>\n<td>For all the blogging she does.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Fred Bloggs</a></th>\n<td>$100M</td>\n<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Bloggs</a></th>\n<td>$100B</td>\n<td>With hair like that?! Enough said...</td>\n</tr>\n</tbody>\n</table>\n<h2>Definition Lists</h2>\n<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>\n<h2>Unordered Lists (Nested)</h2>\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n<h2>Ordered List (Nested)</h2>\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n<h2>HTML Tags</h2>\nThese supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.\n\n<strong>Address Tag</strong>\n\n<address>1 Infinite Loop\nCupertino, CA 95014\nUnited States</address><strong>Anchor Tag (aka. Link)</strong>\n\nThis is an example of a <a title="Apple" href="http://apple.com">link</a>.\n\n<strong>Abbreviation Tag</strong>\n\nThe abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".\n\n<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>\n\nThe acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".\n\n<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThese tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.\n\n<strong>Cite Tag</strong>\n\n"Code is poetry." --<cite>Automattic</cite>\n\n<strong>Code Tag</strong>\n\nYou will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.\n\n<strong>Delete Tag</strong>\n\nThis tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).\n\n<strong>Emphasize Tag</strong>\n\nThe emphasize tag should <em>italicize</em> text.\n\n<strong>Insert Tag</strong>\n\nThis tag should denote <ins>inserted</ins> text.\n\n<strong>Keyboard Tag</strong>\n\nThis scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Preformatted Tag</strong>\n\nThis tag styles large blocks of code.\n<pre>.post-title {\n	margin: 0 0 5px;\n	font-weight: bold;\n	font-size: 38px;\n	line-height: 1.2;\n	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;\n}</pre>\n<strong>Quote Tag</strong>\n\n<q>Developers, developers, developers...</q> --Steve Ballmer\n\n<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis tag shows <span style="text-decoration: line-through;">strike-through text</span>\n\n<strong>Strong Tag</strong>\n\nThis tag shows <strong>bold<strong> text.</strong></strong>\n\n<strong>Subscript Tag</strong>\n\nGetting our science styling on with H<sub>2</sub>O, which should push the "2" down.\n\n<strong>Superscript Tag</strong>\n\nStill sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.\n\n<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Variable Tag</strong>\n\nThis allows you to denote <var>variables</var>.', 'This Post Has a Very Long Title and Should Look Great on All Devices', '', 'publish', 'closed', 'closed', '', 'this-post-has-a-very-long-title-and-should-look-great-on-all-devices-2', '', '', '2018-01-04 15:45:50', '2018-01-04 20:45:50', '', 0, 'http://knightsservice/2018/01/04/this-post-has-a-very-long-title-and-should-look-great-on-all-devices-2/', 0, 'post', '', 0),
(18, 1, '2018-01-03 15:45:50', '2018-01-03 20:45:50', '<h2>Headings</h2>\n<h1>Header one</h1>\n<h2>Header two</h2>\n<h3>Header three</h3>\n<h4>Header four</h4>\n<h5>Header five</h5>\n<h6>Header six</h6>\n<h2>Blockquotes</h2>\nSingle line blockquote:\n<blockquote>Stay hungry. Stay foolish.</blockquote>\nMulti line blockquote with a cite reference:\n<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things.</blockquote>\n<cite>Steve Jobs</cite> - Apple Worldwide Developers\' Conference, 1997\n<h2>Tables</h2>\n<table>\n<thead>\n<tr>\n<th>Employee</th>\n<th>Salary</th>\n<th></th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<th><a href="http://example.org/">John Doe</a></th>\n<td>$1</td>\n<td>Because that\'s all Steve Jobs needed for a salary.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Doe</a></th>\n<td>$100K</td>\n<td>For all the blogging she does.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Fred Bloggs</a></th>\n<td>$100M</td>\n<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Bloggs</a></th>\n<td>$100B</td>\n<td>With hair like that?! Enough said...</td>\n</tr>\n</tbody>\n</table>\n<h2>Definition Lists</h2>\n<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>\n<h2>Unordered Lists (Nested)</h2>\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n<h2>Ordered List (Nested)</h2>\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n<h2>HTML Tags</h2>\nThese supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.\n\n<strong>Address Tag</strong>\n\n<address>1 Infinite Loop\nCupertino, CA 95014\nUnited States</address><strong>Anchor Tag (aka. Link)</strong>\n\nThis is an example of a <a title="Apple" href="http://apple.com">link</a>.\n\n<strong>Abbreviation Tag</strong>\n\nThe abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".\n\n<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>\n\nThe acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".\n\n<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThese tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.\n\n<strong>Cite Tag</strong>\n\n"Code is poetry." --<cite>Automattic</cite>\n\n<strong>Code Tag</strong>\n\nYou will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.\n\n<strong>Delete Tag</strong>\n\nThis tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).\n\n<strong>Emphasize Tag</strong>\n\nThe emphasize tag should <em>italicize</em> text.\n\n<strong>Insert Tag</strong>\n\nThis tag should denote <ins>inserted</ins> text.\n\n<strong>Keyboard Tag</strong>\n\nThis scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Preformatted Tag</strong>\n\nThis tag styles large blocks of code.\n<pre>.post-title {\n	margin: 0 0 5px;\n	font-weight: bold;\n	font-size: 38px;\n	line-height: 1.2;\n	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;\n}</pre>\n<strong>Quote Tag</strong>\n\n<q>Developers, developers, developers...</q> --Steve Ballmer\n\n<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis tag shows <span style="text-decoration: line-through;">strike-through text</span>\n\n<strong>Strong Tag</strong>\n\nThis tag shows <strong>bold<strong> text.</strong></strong>\n\n<strong>Subscript Tag</strong>\n\nGetting our science styling on with H<sub>2</sub>O, which should push the "2" down.\n\n<strong>Superscript Tag</strong>\n\nStill sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.\n\n<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Variable Tag</strong>\n\nThis allows you to denote <var>variables</var>.', 'Short Article Title', '', 'publish', 'closed', 'closed', '', 'short-article-title-2', '', '', '2018-01-03 15:45:50', '2018-01-03 20:45:50', '', 0, 'http://knightsservice/2018/01/03/short-article-title-2/', 0, 'post', '', 0),
(19, 1, '2018-01-10 10:45:50', '2018-01-10 15:45:50', '', 'Sample Image #7', '', 'inherit', 'closed', 'closed', '', 'sample-image-7', '', '', '2018-01-10 10:45:50', '2018-01-10 15:45:50', '', 18, 'http://knightsservice/wp-content/uploads/2018/01/unsplash-2.jpeg', 0, 'attachment', 'image/jpeg', 0),
(20, 1, '2018-01-02 15:45:50', '2018-01-02 20:45:50', 'Welcome to image alignment! The best way to demonstrate the ebb and flow of the various image positioning options is to nestle them snuggly among an ocean of words. Grab a paddle and let\'s get started.\n\nOn the topic of alignment, it should be noted that users can choose from the options of <em>None</em>, <em>Left</em>, <em>Right, </em>and <em>Center</em>. In addition, they also get the options of <em>Thumbnail</em>, <em>Medium</em>, <em>Large</em> &amp; <em>Fullsize</em>.\n<p style="text-align:center;"><img class="size-full wp-image-906 aligncenter" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /></p>\nThe image above happens to be <em><strong>centered</strong></em>.\n\n<strong><img class="size-full wp-image-904 alignleft" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n<img class="alignnone wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" />\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n<img class="size-full wp-image-905 alignright" title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" />\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd just when you thought we were done, we\'re going to do them all over again with captions!\n\n[caption id="attachment_906" align="aligncenter" width="580"]<img class="size-full wp-image-906" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /> Look at 580x300 getting some <a title="Image Settings" href="http://en.support.wordpress.com/images/image-settings/">caption</a> love.[/caption]\n\nThe image above happens to be <em><strong>centered</strong></em>. The caption also has a link in it, just to see if it does anything funky.\n\n[caption id="attachment_904" align="alignleft" width="150"]<img class="size-full wp-image-904" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /> Itty-bitty caption.[/caption]\n\n<strong></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n[caption id="attachment_907" align="alignnone" width="1200"]<img class=" wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" /> Massive image comment for your eyeballs.[/caption]\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n[caption id="attachment_905" align="alignright" width="300"]<img class="size-full wp-image-905 " title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" /> Feels good to be right all the time.[/caption]\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd that\'s a wrap, yo! You survived the tumultuous waters of alignment. Image alignment achievement unlocked!', 'This Is a Fascinating Article About Us', '', 'publish', 'closed', 'closed', '', 'this-is-a-fascinating-article-about-us-2', '', '', '2018-01-02 15:45:50', '2018-01-02 20:45:50', '', 0, 'http://knightsservice/2018/01/02/this-is-a-fascinating-article-about-us-2/', 0, 'post', '', 0),
(21, 1, '2018-01-01 15:45:50', '2018-01-01 20:45:50', '<h1>Lorem Ipsum</h1>\n\n<blockquote>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit..."\n"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain..."</blockquote>\n\n<h2>What is Lorem Ipsum?</h2>\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<h3>Why do we use it?</h3>\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>', 'Post About What Is Happening In Our Industry', '', 'publish', 'closed', 'closed', '', 'post-about-what-is-happening-in-our-industry-2', '', '', '2018-01-01 15:45:50', '2018-01-01 20:45:50', '', 0, 'http://knightsservice/2018/01/01/post-about-what-is-happening-in-our-industry-2/', 0, 'post', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(22, 1, '2017-12-31 15:45:50', '2017-12-31 20:45:50', '<h2>Headings</h2>\n<h1>Header one</h1>\n<h2>Header two</h2>\n<h3>Header three</h3>\n<h4>Header four</h4>\n<h5>Header five</h5>\n<h6>Header six</h6>\n<h2>Blockquotes</h2>\nSingle line blockquote:\n<blockquote>Stay hungry. Stay foolish.</blockquote>\nMulti line blockquote with a cite reference:\n<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things.</blockquote>\n<cite>Steve Jobs</cite> - Apple Worldwide Developers\' Conference, 1997\n<h2>Tables</h2>\n<table>\n<thead>\n<tr>\n<th>Employee</th>\n<th>Salary</th>\n<th></th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<th><a href="http://example.org/">John Doe</a></th>\n<td>$1</td>\n<td>Because that\'s all Steve Jobs needed for a salary.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Doe</a></th>\n<td>$100K</td>\n<td>For all the blogging she does.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Fred Bloggs</a></th>\n<td>$100M</td>\n<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Bloggs</a></th>\n<td>$100B</td>\n<td>With hair like that?! Enough said...</td>\n</tr>\n</tbody>\n</table>\n<h2>Definition Lists</h2>\n<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>\n<h2>Unordered Lists (Nested)</h2>\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n<h2>Ordered List (Nested)</h2>\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n<h2>HTML Tags</h2>\nThese supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.\n\n<strong>Address Tag</strong>\n\n<address>1 Infinite Loop\nCupertino, CA 95014\nUnited States</address><strong>Anchor Tag (aka. Link)</strong>\n\nThis is an example of a <a title="Apple" href="http://apple.com">link</a>.\n\n<strong>Abbreviation Tag</strong>\n\nThe abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".\n\n<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>\n\nThe acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".\n\n<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThese tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.\n\n<strong>Cite Tag</strong>\n\n"Code is poetry." --<cite>Automattic</cite>\n\n<strong>Code Tag</strong>\n\nYou will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.\n\n<strong>Delete Tag</strong>\n\nThis tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).\n\n<strong>Emphasize Tag</strong>\n\nThe emphasize tag should <em>italicize</em> text.\n\n<strong>Insert Tag</strong>\n\nThis tag should denote <ins>inserted</ins> text.\n\n<strong>Keyboard Tag</strong>\n\nThis scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Preformatted Tag</strong>\n\nThis tag styles large blocks of code.\n<pre>.post-title {\n	margin: 0 0 5px;\n	font-weight: bold;\n	font-size: 38px;\n	line-height: 1.2;\n	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;\n}</pre>\n<strong>Quote Tag</strong>\n\n<q>Developers, developers, developers...</q> --Steve Ballmer\n\n<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis tag shows <span style="text-decoration: line-through;">strike-through text</span>\n\n<strong>Strong Tag</strong>\n\nThis tag shows <strong>bold<strong> text.</strong></strong>\n\n<strong>Subscript Tag</strong>\n\nGetting our science styling on with H<sub>2</sub>O, which should push the "2" down.\n\n<strong>Superscript Tag</strong>\n\nStill sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.\n\n<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Variable Tag</strong>\n\nThis allows you to denote <var>variables</var>.', 'Ten Things We Say In Sample Blog Posts', '', 'publish', 'closed', 'closed', '', 'ten-things-we-say-in-sample-blog-posts-2', '', '', '2017-12-31 15:45:50', '2017-12-31 20:45:50', '', 0, 'http://knightsservice/2017/12/31/ten-things-we-say-in-sample-blog-posts-2/', 0, 'post', '', 0),
(23, 1, '2017-12-30 15:45:50', '2017-12-30 20:45:50', '<h1>Lorem Ipsum</h1>\n\n<blockquote>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit..."\n"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain..."</blockquote>\n\n<h2>What is Lorem Ipsum?</h2>\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<h3>Why do we use it?</h3>\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>', 'This Post Has a Very Long Title and Should Look Great on All Devices', '', 'publish', 'closed', 'closed', '', 'this-post-has-a-very-long-title-and-should-look-great-on-all-devices-3', '', '', '2017-12-30 15:45:50', '2017-12-30 20:45:50', '', 0, 'http://knightsservice/2017/12/30/this-post-has-a-very-long-title-and-should-look-great-on-all-devices-3/', 0, 'post', '', 0),
(24, 1, '2018-01-12 17:54:22', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-01-12 17:54:22', '0000-00-00 00:00:00', '', 0, 'http://knightsservice/?p=24', 1, 'nav_menu_item', '', 0),
(31, 1, '2018-01-12 18:14:05', '2018-01-12 23:14:05', 'Vivamus suscipit tortor eget felis porttitor volutpat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur aliquet quam id dui posuere blandit.\r\n\r\nDonec sollicitudin molestie malesuada. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui.', 'Ladder services', '', 'trash', 'closed', 'closed', '', 'ladder-services__trashed', '', '', '2018-01-19 08:06:11', '2018-01-19 13:06:11', '', 0, 'http://knightsservice/?page_id=31', 0, 'page', '', 0),
(32, 1, '2018-01-12 18:14:05', '2018-01-12 23:14:05', '', 'Ladder services', '', 'inherit', 'closed', 'closed', '', '31-revision-v1', '', '', '2018-01-12 18:14:05', '2018-01-12 23:14:05', '', 31, 'http://knightsservice/2018/01/12/31-revision-v1/', 0, 'revision', '', 0),
(33, 1, '2018-01-12 18:14:31', '2018-01-12 23:14:31', '', 'Drone Technology', '', 'publish', 'closed', 'closed', '', 'drone-technology', '', '', '2018-01-12 18:14:31', '2018-01-12 23:14:31', '', 0, 'http://knightsservice/?page_id=33', 0, 'page', '', 0),
(34, 1, '2018-01-12 18:14:31', '2018-01-12 23:14:31', '', 'Drone Technology', '', 'inherit', 'closed', 'closed', '', '33-revision-v1', '', '', '2018-01-12 18:14:31', '2018-01-12 23:14:31', '', 33, 'http://knightsservice/2018/01/12/33-revision-v1/', 0, 'revision', '', 0),
(35, 1, '2018-01-12 18:14:48', '2018-01-12 23:14:48', '', 'Reporting', '', 'publish', 'closed', 'closed', '', 'reporting', '', '', '2018-01-12 18:14:48', '2018-01-12 23:14:48', '', 0, 'http://knightsservice/?page_id=35', 0, 'page', '', 0),
(36, 1, '2018-01-12 18:14:48', '2018-01-12 23:14:48', '', 'Reporting', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2018-01-12 18:14:48', '2018-01-12 23:14:48', '', 35, 'http://knightsservice/2018/01/12/35-revision-v1/', 0, 'revision', '', 0),
(37, 1, '2018-01-12 18:15:25', '2018-01-12 23:15:25', '', 'About us', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2018-01-12 18:15:25', '2018-01-12 23:15:25', '', 0, 'http://knightsservice/?page_id=37', 0, 'page', '', 0),
(38, 1, '2018-01-12 18:15:25', '2018-01-12 23:15:25', '', 'About us', '', 'inherit', 'closed', 'closed', '', '37-revision-v1', '', '', '2018-01-12 18:15:25', '2018-01-12 23:15:25', '', 37, 'http://knightsservice/2018/01/12/37-revision-v1/', 0, 'revision', '', 0),
(39, 1, '2018-01-12 18:16:22', '2018-01-12 23:16:22', ' ', '', '', 'publish', 'closed', 'closed', '', '39', '', '', '2018-01-19 10:22:17', '2018-01-19 15:22:17', '', 0, 'http://knightsservice/?p=39', 7, 'nav_menu_item', '', 0),
(40, 1, '2018-01-12 18:16:22', '2018-01-12 23:16:22', ' ', '', '', 'publish', 'closed', 'closed', '', '40', '', '', '2018-01-19 10:22:17', '2018-01-19 15:22:17', '', 0, 'http://knightsservice/?p=40', 6, 'nav_menu_item', '', 0),
(42, 1, '2018-01-12 18:17:26', '2018-01-12 23:17:26', ' ', '', '', 'publish', 'closed', 'closed', '', '42', '', '', '2018-01-19 08:06:36', '2018-01-19 13:06:36', '', 0, 'http://knightsservice/?p=42', 1, 'nav_menu_item', '', 0),
(43, 1, '2018-01-12 18:17:27', '2018-01-12 23:17:27', ' ', '', '', 'publish', 'closed', 'closed', '', '43', '', '', '2018-01-19 08:06:36', '2018-01-19 13:06:36', '', 0, 'http://knightsservice/?p=43', 2, 'nav_menu_item', '', 0),
(44, 1, '2018-01-12 18:17:27', '2018-01-12 23:17:27', '', 'Blog', '', 'publish', 'closed', 'closed', '', '44', '', '', '2018-01-19 08:06:36', '2018-01-19 13:06:36', '', 0, 'http://knightsservice/?p=44', 3, 'nav_menu_item', '', 0),
(45, 1, '2018-01-12 18:17:27', '2018-01-12 23:17:27', '', '(502) 264-2527', '', 'publish', 'closed', 'closed', '', '502-264-2527', '', '', '2018-01-19 08:06:36', '2018-01-19 13:06:36', '', 0, 'http://knightsservice/?p=45', 4, 'nav_menu_item', '', 0),
(46, 1, '2018-01-12 18:18:56', '2018-01-12 23:18:56', '', 'logo', '', 'inherit', 'closed', 'closed', '', 'logo', '', '', '2018-01-12 18:18:56', '2018-01-12 23:18:56', '', 0, 'http://knightsservice/wp-content/uploads/2018/01/logo.svg', 0, 'attachment', 'image/svg+xml', 0),
(47, 1, '2018-01-15 12:15:58', '2018-01-15 17:15:58', '', 'logo-small', '', 'inherit', 'closed', 'closed', '', 'logo-small', '', '', '2018-01-15 12:15:58', '2018-01-15 17:15:58', '', 0, 'http://knightsservice/wp-content/uploads/2018/01/logo-small-1.svg', 0, 'attachment', 'image/svg+xml', 0),
(48, 1, '2018-01-16 12:45:18', '2018-01-16 17:45:18', 'Sed felis neque viverra in eleifend acpharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae. Fusce varius risus dapibus dolor. Donec tristique faucibus velit aliquam erat volutpat integer sed felis. Quisque odio lacus tincidunt fringilla iaculis vitae dictum a quam cras consectetuer interdum odio pellentesque ideros nulla atenim.', 'Ladder services', '', 'inherit', 'closed', 'closed', '', '31-revision-v1', '', '', '2018-01-16 12:45:18', '2018-01-16 17:45:18', '', 31, 'http://knightsservice/31-revision-v1/', 0, 'revision', '', 0),
(50, 1, '2018-01-16 17:45:27', '2018-01-16 22:45:27', 'Sed felis neque viverra in eleifend acpharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae. Fusce varius risus dapibus dolor. Donec tristique faucibus velit aliquam erat volutpat integer sed felis. Quisque odio lacus tincidunt fringilla iaculis vitae dictum a quam cras consectetuer interdum odio pellentesque ideros nulla atenim.', 'Ladder assist', '', 'trash', 'closed', 'closed', '', 'ladder-assist__trashed', '', '', '2018-01-19 08:06:11', '2018-01-19 13:06:11', '', 31, 'http://knightsservice/?page_id=50', 0, 'page', '', 0),
(51, 1, '2018-01-16 17:45:27', '2018-01-16 22:45:27', '', 'Ladder assist', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2018-01-16 17:45:27', '2018-01-16 22:45:27', '', 50, 'http://knightsservice/50-revision-v1/', 0, 'revision', '', 0),
(52, 1, '2018-01-16 17:48:00', '2018-01-16 22:48:00', 'Sed felis neque viverra in eleifend acpharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae. Fusce varius risus dapibus dolor. Donec tristique faucibus velit aliquam erat volutpat integer sed felis. Quisque odio lacus tincidunt fringilla iaculis vitae dictum a quam cras consectetuer interdum odio pellentesque ideros nulla atenim.', 'Ladder assist', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2018-01-16 17:48:00', '2018-01-16 22:48:00', '', 50, 'http://knightsservice/50-revision-v1/', 0, 'revision', '', 0),
(53, 1, '2018-01-16 20:33:02', '2018-01-17 01:33:02', '<h2>Headings</h2>\n<h1>Header one</h1>\n<h2>Header two</h2>\n<h3>Header three</h3>\n<h4>Header four</h4>\n<h5>Header five</h5>\n<h6>Header six</h6>\n<h2>Blockquotes</h2>\nSingle line blockquote:\n<blockquote>Stay hungry. Stay foolish.</blockquote>\nMulti line blockquote with a cite reference:\n<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things.</blockquote>\n<cite>Steve Jobs</cite> - Apple Worldwide Developers\' Conference, 1997\n<h2>Tables</h2>\n<table>\n<thead>\n<tr>\n<th>Employee</th>\n<th>Salary</th>\n<th></th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<th><a href="http://example.org/">John Doe</a></th>\n<td>$1</td>\n<td>Because that\'s all Steve Jobs needed for a salary.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Doe</a></th>\n<td>$100K</td>\n<td>For all the blogging she does.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Fred Bloggs</a></th>\n<td>$100M</td>\n<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Bloggs</a></th>\n<td>$100B</td>\n<td>With hair like that?! Enough said...</td>\n</tr>\n</tbody>\n</table>\n<h2>Definition Lists</h2>\n<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>\n<h2>Unordered Lists (Nested)</h2>\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n<h2>Ordered List (Nested)</h2>\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n<h2>HTML Tags</h2>\nThese supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.\n\n<strong>Address Tag</strong>\n\n<address>1 Infinite Loop\nCupertino, CA 95014\nUnited States</address><strong>Anchor Tag (aka. Link)</strong>\n\nThis is an example of a <a title="Apple" href="http://apple.com">link</a>.\n\n<strong>Abbreviation Tag</strong>\n\nThe abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".\n\n<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>\n\nThe acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".\n\n<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThese tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.\n\n<strong>Cite Tag</strong>\n\n"Code is poetry." --<cite>Automattic</cite>\n\n<strong>Code Tag</strong>\n\nYou will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.\n\n<strong>Delete Tag</strong>\n\nThis tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).\n\n<strong>Emphasize Tag</strong>\n\nThe emphasize tag should <em>italicize</em> text.\n\n<strong>Insert Tag</strong>\n\nThis tag should denote <ins>inserted</ins> text.\n\n<strong>Keyboard Tag</strong>\n\nThis scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Preformatted Tag</strong>\n\nThis tag styles large blocks of code.\n<pre>.post-title {\n	margin: 0 0 5px;\n	font-weight: bold;\n	font-size: 38px;\n	line-height: 1.2;\n	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;\n}</pre>\n<strong>Quote Tag</strong>\n\n<q>Developers, developers, developers...</q> --Steve Ballmer\n\n<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis tag shows <span style="text-decoration: line-through;">strike-through text</span>\n\n<strong>Strong Tag</strong>\n\nThis tag shows <strong>bold<strong> text.</strong></strong>\n\n<strong>Subscript Tag</strong>\n\nGetting our science styling on with H<sub>2</sub>O, which should push the "2" down.\n\n<strong>Superscript Tag</strong>\n\nStill sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.\n\n<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Variable Tag</strong>\n\nThis allows you to denote <var>variables</var>.', 'This Post Has a Very Long Title and Should Look Great on All Devices', '', 'trash', 'closed', 'closed', '', 'this-post-has-a-very-long-title-and-should-look-great-on-all-devices__trashed', '', '', '2018-01-17 15:33:54', '2018-01-17 20:33:54', '', 0, 'http://localhost/knightsservice.com/service/this-post-has-a-very-long-title-and-should-look-great-on-all-devices/', 1, 'service', '', 0),
(54, 1, '2018-01-17 15:33:02', '2018-01-17 20:33:02', '', 'Sample Image #1', '', 'inherit', 'closed', 'closed', '', 'sample-image-1-2', '', '', '2018-01-17 15:33:02', '2018-01-17 20:33:02', '', 53, 'http://localhost/knightsservice.com/wp-content/uploads/2018/01/unsplash-3.jpeg', 0, 'attachment', 'image/jpeg', 0),
(55, 1, '2018-01-15 20:33:02', '2018-01-16 01:33:02', 'Welcome to image alignment! The best way to demonstrate the ebb and flow of the various image positioning options is to nestle them snuggly among an ocean of words. Grab a paddle and let\'s get started.\n\nOn the topic of alignment, it should be noted that users can choose from the options of <em>None</em>, <em>Left</em>, <em>Right, </em>and <em>Center</em>. In addition, they also get the options of <em>Thumbnail</em>, <em>Medium</em>, <em>Large</em> &amp; <em>Fullsize</em>.\n<p style="text-align:center;"><img class="size-full wp-image-906 aligncenter" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /></p>\nThe image above happens to be <em><strong>centered</strong></em>.\n\n<strong><img class="size-full wp-image-904 alignleft" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n<img class="alignnone wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" />\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n<img class="size-full wp-image-905 alignright" title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" />\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd just when you thought we were done, we\'re going to do them all over again with captions!\n\n[caption id="attachment_906" align="aligncenter" width="580"]<img class="size-full wp-image-906" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /> Look at 580x300 getting some <a title="Image Settings" href="http://en.support.wordpress.com/images/image-settings/">caption</a> love.[/caption]\n\nThe image above happens to be <em><strong>centered</strong></em>. The caption also has a link in it, just to see if it does anything funky.\n\n[caption id="attachment_904" align="alignleft" width="150"]<img class="size-full wp-image-904" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /> Itty-bitty caption.[/caption]\n\n<strong></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n[caption id="attachment_907" align="alignnone" width="1200"]<img class=" wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" /> Massive image comment for your eyeballs.[/caption]\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n[caption id="attachment_905" align="alignright" width="300"]<img class="size-full wp-image-905 " title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" /> Feels good to be right all the time.[/caption]\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd that\'s a wrap, yo! You survived the tumultuous waters of alignment. Image alignment achievement unlocked!', 'Short Article Title', '', 'trash', 'closed', 'closed', '', 'short-article-title__trashed', '', '', '2018-01-17 15:33:54', '2018-01-17 20:33:54', '', 0, 'http://localhost/knightsservice.com/service/short-article-title/', 2, 'service', '', 0),
(56, 1, '2018-01-14 20:33:02', '2018-01-15 01:33:02', 'Welcome to image alignment! The best way to demonstrate the ebb and flow of the various image positioning options is to nestle them snuggly among an ocean of words. Grab a paddle and let\'s get started.\n\nOn the topic of alignment, it should be noted that users can choose from the options of <em>None</em>, <em>Left</em>, <em>Right, </em>and <em>Center</em>. In addition, they also get the options of <em>Thumbnail</em>, <em>Medium</em>, <em>Large</em> &amp; <em>Fullsize</em>.\n<p style="text-align:center;"><img class="size-full wp-image-906 aligncenter" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /></p>\nThe image above happens to be <em><strong>centered</strong></em>.\n\n<strong><img class="size-full wp-image-904 alignleft" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n<img class="alignnone wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" />\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n<img class="size-full wp-image-905 alignright" title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" />\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd just when you thought we were done, we\'re going to do them all over again with captions!\n\n[caption id="attachment_906" align="aligncenter" width="580"]<img class="size-full wp-image-906" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /> Look at 580x300 getting some <a title="Image Settings" href="http://en.support.wordpress.com/images/image-settings/">caption</a> love.[/caption]\n\nThe image above happens to be <em><strong>centered</strong></em>. The caption also has a link in it, just to see if it does anything funky.\n\n[caption id="attachment_904" align="alignleft" width="150"]<img class="size-full wp-image-904" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /> Itty-bitty caption.[/caption]\n\n<strong></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n[caption id="attachment_907" align="alignnone" width="1200"]<img class=" wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" /> Massive image comment for your eyeballs.[/caption]\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n[caption id="attachment_905" align="alignright" width="300"]<img class="size-full wp-image-905 " title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" /> Feels good to be right all the time.[/caption]\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd that\'s a wrap, yo! You survived the tumultuous waters of alignment. Image alignment achievement unlocked!', 'This Is a Fascinating Article About Us', '', 'trash', 'closed', 'closed', '', 'this-is-a-fascinating-article-about-us__trashed', '', '', '2018-01-17 15:33:54', '2018-01-17 20:33:54', '', 0, 'http://localhost/knightsservice.com/service/this-is-a-fascinating-article-about-us/', 3, 'service', '', 0),
(57, 1, '2018-01-13 20:33:02', '2018-01-14 01:33:02', '<h2>Headings</h2>\n<h1>Header one</h1>\n<h2>Header two</h2>\n<h3>Header three</h3>\n<h4>Header four</h4>\n<h5>Header five</h5>\n<h6>Header six</h6>\n<h2>Blockquotes</h2>\nSingle line blockquote:\n<blockquote>Stay hungry. Stay foolish.</blockquote>\nMulti line blockquote with a cite reference:\n<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things.</blockquote>\n<cite>Steve Jobs</cite> - Apple Worldwide Developers\' Conference, 1997\n<h2>Tables</h2>\n<table>\n<thead>\n<tr>\n<th>Employee</th>\n<th>Salary</th>\n<th></th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<th><a href="http://example.org/">John Doe</a></th>\n<td>$1</td>\n<td>Because that\'s all Steve Jobs needed for a salary.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Doe</a></th>\n<td>$100K</td>\n<td>For all the blogging she does.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Fred Bloggs</a></th>\n<td>$100M</td>\n<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Bloggs</a></th>\n<td>$100B</td>\n<td>With hair like that?! Enough said...</td>\n</tr>\n</tbody>\n</table>\n<h2>Definition Lists</h2>\n<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>\n<h2>Unordered Lists (Nested)</h2>\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n<h2>Ordered List (Nested)</h2>\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n<h2>HTML Tags</h2>\nThese supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.\n\n<strong>Address Tag</strong>\n\n<address>1 Infinite Loop\nCupertino, CA 95014\nUnited States</address><strong>Anchor Tag (aka. Link)</strong>\n\nThis is an example of a <a title="Apple" href="http://apple.com">link</a>.\n\n<strong>Abbreviation Tag</strong>\n\nThe abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".\n\n<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>\n\nThe acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".\n\n<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThese tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.\n\n<strong>Cite Tag</strong>\n\n"Code is poetry." --<cite>Automattic</cite>\n\n<strong>Code Tag</strong>\n\nYou will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.\n\n<strong>Delete Tag</strong>\n\nThis tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).\n\n<strong>Emphasize Tag</strong>\n\nThe emphasize tag should <em>italicize</em> text.\n\n<strong>Insert Tag</strong>\n\nThis tag should denote <ins>inserted</ins> text.\n\n<strong>Keyboard Tag</strong>\n\nThis scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Preformatted Tag</strong>\n\nThis tag styles large blocks of code.\n<pre>.post-title {\n	margin: 0 0 5px;\n	font-weight: bold;\n	font-size: 38px;\n	line-height: 1.2;\n	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;\n}</pre>\n<strong>Quote Tag</strong>\n\n<q>Developers, developers, developers...</q> --Steve Ballmer\n\n<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis tag shows <span style="text-decoration: line-through;">strike-through text</span>\n\n<strong>Strong Tag</strong>\n\nThis tag shows <strong>bold<strong> text.</strong></strong>\n\n<strong>Subscript Tag</strong>\n\nGetting our science styling on with H<sub>2</sub>O, which should push the "2" down.\n\n<strong>Superscript Tag</strong>\n\nStill sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.\n\n<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Variable Tag</strong>\n\nThis allows you to denote <var>variables</var>.', 'Post About What Is Happening In Our Industry', '', 'trash', 'closed', 'closed', '', 'post-about-what-is-happening-in-our-industry__trashed', '', '', '2018-01-17 15:33:54', '2018-01-17 20:33:54', '', 0, 'http://localhost/knightsservice.com/service/post-about-what-is-happening-in-our-industry/', 4, 'service', '', 0),
(58, 1, '2018-01-12 20:33:02', '2018-01-13 01:33:02', '<h2>Headings</h2>\n<h1>Header one</h1>\n<h2>Header two</h2>\n<h3>Header three</h3>\n<h4>Header four</h4>\n<h5>Header five</h5>\n<h6>Header six</h6>\n<h2>Blockquotes</h2>\nSingle line blockquote:\n<blockquote>Stay hungry. Stay foolish.</blockquote>\nMulti line blockquote with a cite reference:\n<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things.</blockquote>\n<cite>Steve Jobs</cite> - Apple Worldwide Developers\' Conference, 1997\n<h2>Tables</h2>\n<table>\n<thead>\n<tr>\n<th>Employee</th>\n<th>Salary</th>\n<th></th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<th><a href="http://example.org/">John Doe</a></th>\n<td>$1</td>\n<td>Because that\'s all Steve Jobs needed for a salary.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Doe</a></th>\n<td>$100K</td>\n<td>For all the blogging she does.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Fred Bloggs</a></th>\n<td>$100M</td>\n<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Bloggs</a></th>\n<td>$100B</td>\n<td>With hair like that?! Enough said...</td>\n</tr>\n</tbody>\n</table>\n<h2>Definition Lists</h2>\n<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>\n<h2>Unordered Lists (Nested)</h2>\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n<h2>Ordered List (Nested)</h2>\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n<h2>HTML Tags</h2>\nThese supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.\n\n<strong>Address Tag</strong>\n\n<address>1 Infinite Loop\nCupertino, CA 95014\nUnited States</address><strong>Anchor Tag (aka. Link)</strong>\n\nThis is an example of a <a title="Apple" href="http://apple.com">link</a>.\n\n<strong>Abbreviation Tag</strong>\n\nThe abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".\n\n<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>\n\nThe acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".\n\n<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThese tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.\n\n<strong>Cite Tag</strong>\n\n"Code is poetry." --<cite>Automattic</cite>\n\n<strong>Code Tag</strong>\n\nYou will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.\n\n<strong>Delete Tag</strong>\n\nThis tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).\n\n<strong>Emphasize Tag</strong>\n\nThe emphasize tag should <em>italicize</em> text.\n\n<strong>Insert Tag</strong>\n\nThis tag should denote <ins>inserted</ins> text.\n\n<strong>Keyboard Tag</strong>\n\nThis scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Preformatted Tag</strong>\n\nThis tag styles large blocks of code.\n<pre>.post-title {\n	margin: 0 0 5px;\n	font-weight: bold;\n	font-size: 38px;\n	line-height: 1.2;\n	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;\n}</pre>\n<strong>Quote Tag</strong>\n\n<q>Developers, developers, developers...</q> --Steve Ballmer\n\n<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis tag shows <span style="text-decoration: line-through;">strike-through text</span>\n\n<strong>Strong Tag</strong>\n\nThis tag shows <strong>bold<strong> text.</strong></strong>\n\n<strong>Subscript Tag</strong>\n\nGetting our science styling on with H<sub>2</sub>O, which should push the "2" down.\n\n<strong>Superscript Tag</strong>\n\nStill sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.\n\n<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Variable Tag</strong>\n\nThis allows you to denote <var>variables</var>.', 'Ten Things We Say In Sample Blog Posts', '', 'trash', 'closed', 'closed', '', 'ten-things-we-say-in-sample-blog-posts__trashed', '', '', '2018-01-17 15:33:54', '2018-01-17 20:33:54', '', 0, 'http://localhost/knightsservice.com/service/ten-things-we-say-in-sample-blog-posts/', 5, 'service', '', 0),
(59, 1, '2018-01-17 15:33:02', '2018-01-17 20:33:02', '', 'Sample Image #5', '', 'inherit', 'closed', 'closed', '', 'sample-image-5', '', '', '2018-01-17 15:33:02', '2018-01-17 20:33:02', '', 58, 'http://localhost/knightsservice.com/wp-content/uploads/2018/01/unsplash-4.jpeg', 0, 'attachment', 'image/jpeg', 0),
(60, 1, '2018-01-11 20:33:02', '2018-01-12 01:33:02', '<h1>Lorem Ipsum</h1>\n\n<blockquote>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit..."\n"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain..."</blockquote>\n\n<h2>What is Lorem Ipsum?</h2>\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<h3>Why do we use it?</h3>\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>', 'This Post Has a Very Long Title and Should Look Great on All Devices', '', 'trash', 'closed', 'closed', '', 'this-post-has-a-very-long-title-and-should-look-great-on-all-devices-2__trashed', '', '', '2018-01-17 15:33:54', '2018-01-17 20:33:54', '', 0, 'http://localhost/knightsservice.com/service/this-post-has-a-very-long-title-and-should-look-great-on-all-devices-2/', 6, 'service', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(61, 1, '2018-01-10 20:33:02', '2018-01-11 01:33:02', 'Welcome to image alignment! The best way to demonstrate the ebb and flow of the various image positioning options is to nestle them snuggly among an ocean of words. Grab a paddle and let\'s get started.\n\nOn the topic of alignment, it should be noted that users can choose from the options of <em>None</em>, <em>Left</em>, <em>Right, </em>and <em>Center</em>. In addition, they also get the options of <em>Thumbnail</em>, <em>Medium</em>, <em>Large</em> &amp; <em>Fullsize</em>.\n<p style="text-align:center;"><img class="size-full wp-image-906 aligncenter" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /></p>\nThe image above happens to be <em><strong>centered</strong></em>.\n\n<strong><img class="size-full wp-image-904 alignleft" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n<img class="alignnone wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" />\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n<img class="size-full wp-image-905 alignright" title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" />\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd just when you thought we were done, we\'re going to do them all over again with captions!\n\n[caption id="attachment_906" align="aligncenter" width="580"]<img class="size-full wp-image-906" title="Image Alignment 580x300" alt="Image Alignment 580x300" src="https://unsplash.it/580/300/?random" width="580" height="300" /> Look at 580x300 getting some <a title="Image Settings" href="http://en.support.wordpress.com/images/image-settings/">caption</a> love.[/caption]\n\nThe image above happens to be <em><strong>centered</strong></em>. The caption also has a link in it, just to see if it does anything funky.\n\n[caption id="attachment_904" align="alignleft" width="150"]<img class="size-full wp-image-904" title="Image Alignment 150x150" alt="Image Alignment 150x150" src="https://unsplash.it/150/150/?random" width="150" height="150" /> Itty-bitty caption.[/caption]\n\n<strong></strong>The rest of this paragraph is filler for the sake of seeing the text wrap around the 150x150 image, which is <em><strong>left aligned</strong></em>. <strong></strong>\n\nAs you can see the should be some space above, below, and to the right of the image. The text should not be creeping on the image. Creeping is just not right. Images need breathing room too. Let them speak like you words. Let them do their jobs without any hassle from the text. In about one more sentence here, we\'ll see that the text moves from the right of the image down below the image in seamless transition. Again, letting the do it\'s thang. Mission accomplished!\n\nAnd now for a <em><strong>massively large image</strong></em>. It also has <em><strong>no alignment</strong></em>.\n\n[caption id="attachment_907" align="alignnone" width="1200"]<img class=" wp-image-907" title="Image Alignment 1200x400" alt="Image Alignment 1200x400" src="https://unsplash.it/1200/400/?random" width="1200" height="400" /> Massive image comment for your eyeballs.[/caption]\n\nThe image above, though 1200px wide, should not overflow the content area. It should remain contained with no visible disruption to the flow of content.\n\n[caption id="attachment_905" align="alignright" width="300"]<img class="size-full wp-image-905 " title="Image Alignment 300x200" alt="Image Alignment 300x200" src="https://unsplash.it/300/200/?random" width="300" height="200" /> Feels good to be right all the time.[/caption]\n\nAnd now we\'re going to shift things to the <em><strong>right align</strong></em>. Again, there should be plenty of room above, below, and to the left of the image. Just look at him there... Hey guy! Way to rock that right side. I don\'t care what the left aligned image says, you look great. Don\'t let anyone else tell you differently.\n\nIn just a bit here, you should see the text start to wrap below the right aligned image and settle in nicely. There should still be plenty of room and everything should be sitting pretty. Yeah... Just like that. It never felt so good to be right.\n\nAnd that\'s a wrap, yo! You survived the tumultuous waters of alignment. Image alignment achievement unlocked!', 'Short Article Title', '', 'trash', 'closed', 'closed', '', 'short-article-title-2__trashed', '', '', '2018-01-17 15:33:54', '2018-01-17 20:33:54', '', 0, 'http://localhost/knightsservice.com/service/short-article-title-2/', 7, 'service', '', 0),
(62, 1, '2018-01-17 15:33:03', '2018-01-17 20:33:03', '', 'Sample Image #7', '', 'inherit', 'closed', 'closed', '', 'sample-image-7-2', '', '', '2018-01-17 16:25:46', '2018-01-17 21:25:46', '', 61, 'http://localhost/knightsservice.com/wp-content/uploads/2018/01/unsplash-5.jpeg', 0, 'attachment', 'image/jpeg', 0),
(63, 1, '2018-01-09 20:33:03', '2018-01-10 01:33:03', '<h2>Headings</h2>\n<h1>Header one</h1>\n<h2>Header two</h2>\n<h3>Header three</h3>\n<h4>Header four</h4>\n<h5>Header five</h5>\n<h6>Header six</h6>\n<h2>Blockquotes</h2>\nSingle line blockquote:\n<blockquote>Stay hungry. Stay foolish.</blockquote>\nMulti line blockquote with a cite reference:\n<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things.</blockquote>\n<cite>Steve Jobs</cite> - Apple Worldwide Developers\' Conference, 1997\n<h2>Tables</h2>\n<table>\n<thead>\n<tr>\n<th>Employee</th>\n<th>Salary</th>\n<th></th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<th><a href="http://example.org/">John Doe</a></th>\n<td>$1</td>\n<td>Because that\'s all Steve Jobs needed for a salary.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Doe</a></th>\n<td>$100K</td>\n<td>For all the blogging she does.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Fred Bloggs</a></th>\n<td>$100M</td>\n<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Bloggs</a></th>\n<td>$100B</td>\n<td>With hair like that?! Enough said...</td>\n</tr>\n</tbody>\n</table>\n<h2>Definition Lists</h2>\n<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>\n<h2>Unordered Lists (Nested)</h2>\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n<h2>Ordered List (Nested)</h2>\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n<h2>HTML Tags</h2>\nThese supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.\n\n<strong>Address Tag</strong>\n\n<address>1 Infinite Loop\nCupertino, CA 95014\nUnited States</address><strong>Anchor Tag (aka. Link)</strong>\n\nThis is an example of a <a title="Apple" href="http://apple.com">link</a>.\n\n<strong>Abbreviation Tag</strong>\n\nThe abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".\n\n<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>\n\nThe acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".\n\n<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThese tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.\n\n<strong>Cite Tag</strong>\n\n"Code is poetry." --<cite>Automattic</cite>\n\n<strong>Code Tag</strong>\n\nYou will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.\n\n<strong>Delete Tag</strong>\n\nThis tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).\n\n<strong>Emphasize Tag</strong>\n\nThe emphasize tag should <em>italicize</em> text.\n\n<strong>Insert Tag</strong>\n\nThis tag should denote <ins>inserted</ins> text.\n\n<strong>Keyboard Tag</strong>\n\nThis scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Preformatted Tag</strong>\n\nThis tag styles large blocks of code.\n<pre>.post-title {\n	margin: 0 0 5px;\n	font-weight: bold;\n	font-size: 38px;\n	line-height: 1.2;\n	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;\n}</pre>\n<strong>Quote Tag</strong>\n\n<q>Developers, developers, developers...</q> --Steve Ballmer\n\n<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis tag shows <span style="text-decoration: line-through;">strike-through text</span>\n\n<strong>Strong Tag</strong>\n\nThis tag shows <strong>bold<strong> text.</strong></strong>\n\n<strong>Subscript Tag</strong>\n\nGetting our science styling on with H<sub>2</sub>O, which should push the "2" down.\n\n<strong>Superscript Tag</strong>\n\nStill sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.\n\n<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Variable Tag</strong>\n\nThis allows you to denote <var>variables</var>.', 'This Is a Fascinating Article About Us', '', 'trash', 'closed', 'closed', '', 'this-is-a-fascinating-article-about-us-2__trashed', '', '', '2018-01-17 15:33:54', '2018-01-17 20:33:54', '', 0, 'http://localhost/knightsservice.com/service/this-is-a-fascinating-article-about-us-2/', 8, 'service', '', 0),
(64, 1, '2018-01-08 20:33:03', '2018-01-09 01:33:03', '<h2>Headings</h2>\n<h1>Header one</h1>\n<h2>Header two</h2>\n<h3>Header three</h3>\n<h4>Header four</h4>\n<h5>Header five</h5>\n<h6>Header six</h6>\n<h2>Blockquotes</h2>\nSingle line blockquote:\n<blockquote>Stay hungry. Stay foolish.</blockquote>\nMulti line blockquote with a cite reference:\n<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things.</blockquote>\n<cite>Steve Jobs</cite> - Apple Worldwide Developers\' Conference, 1997\n<h2>Tables</h2>\n<table>\n<thead>\n<tr>\n<th>Employee</th>\n<th>Salary</th>\n<th></th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<th><a href="http://example.org/">John Doe</a></th>\n<td>$1</td>\n<td>Because that\'s all Steve Jobs needed for a salary.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Doe</a></th>\n<td>$100K</td>\n<td>For all the blogging she does.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Fred Bloggs</a></th>\n<td>$100M</td>\n<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Bloggs</a></th>\n<td>$100B</td>\n<td>With hair like that?! Enough said...</td>\n</tr>\n</tbody>\n</table>\n<h2>Definition Lists</h2>\n<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>\n<h2>Unordered Lists (Nested)</h2>\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n<h2>Ordered List (Nested)</h2>\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n<h2>HTML Tags</h2>\nThese supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.\n\n<strong>Address Tag</strong>\n\n<address>1 Infinite Loop\nCupertino, CA 95014\nUnited States</address><strong>Anchor Tag (aka. Link)</strong>\n\nThis is an example of a <a title="Apple" href="http://apple.com">link</a>.\n\n<strong>Abbreviation Tag</strong>\n\nThe abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".\n\n<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>\n\nThe acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".\n\n<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThese tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.\n\n<strong>Cite Tag</strong>\n\n"Code is poetry." --<cite>Automattic</cite>\n\n<strong>Code Tag</strong>\n\nYou will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.\n\n<strong>Delete Tag</strong>\n\nThis tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).\n\n<strong>Emphasize Tag</strong>\n\nThe emphasize tag should <em>italicize</em> text.\n\n<strong>Insert Tag</strong>\n\nThis tag should denote <ins>inserted</ins> text.\n\n<strong>Keyboard Tag</strong>\n\nThis scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Preformatted Tag</strong>\n\nThis tag styles large blocks of code.\n<pre>.post-title {\n	margin: 0 0 5px;\n	font-weight: bold;\n	font-size: 38px;\n	line-height: 1.2;\n	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;\n}</pre>\n<strong>Quote Tag</strong>\n\n<q>Developers, developers, developers...</q> --Steve Ballmer\n\n<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis tag shows <span style="text-decoration: line-through;">strike-through text</span>\n\n<strong>Strong Tag</strong>\n\nThis tag shows <strong>bold<strong> text.</strong></strong>\n\n<strong>Subscript Tag</strong>\n\nGetting our science styling on with H<sub>2</sub>O, which should push the "2" down.\n\n<strong>Superscript Tag</strong>\n\nStill sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.\n\n<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Variable Tag</strong>\n\nThis allows you to denote <var>variables</var>.', 'Post About What Is Happening In Our Industry', '', 'trash', 'closed', 'closed', '', 'post-about-what-is-happening-in-our-industry-2__trashed', '', '', '2018-01-17 15:33:54', '2018-01-17 20:33:54', '', 0, 'http://localhost/knightsservice.com/service/post-about-what-is-happening-in-our-industry-2/', 9, 'service', '', 0),
(65, 1, '2018-01-07 20:33:03', '2018-01-08 01:33:03', '<h2>Headings</h2>\n<h1>Header one</h1>\n<h2>Header two</h2>\n<h3>Header three</h3>\n<h4>Header four</h4>\n<h5>Header five</h5>\n<h6>Header six</h6>\n<h2>Blockquotes</h2>\nSingle line blockquote:\n<blockquote>Stay hungry. Stay foolish.</blockquote>\nMulti line blockquote with a cite reference:\n<blockquote>People think focus means saying yes to the thing you\'ve got to focus on. But that\'s not what it means at all. It means saying no to the hundred other good ideas that there are. You have to pick carefully. I\'m actually as proud of the things we haven\'t done as the things I have done. Innovation is saying no to 1,000 things.</blockquote>\n<cite>Steve Jobs</cite> - Apple Worldwide Developers\' Conference, 1997\n<h2>Tables</h2>\n<table>\n<thead>\n<tr>\n<th>Employee</th>\n<th>Salary</th>\n<th></th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<th><a href="http://example.org/">John Doe</a></th>\n<td>$1</td>\n<td>Because that\'s all Steve Jobs needed for a salary.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Doe</a></th>\n<td>$100K</td>\n<td>For all the blogging she does.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Fred Bloggs</a></th>\n<td>$100M</td>\n<td>Pictures are worth a thousand words, right? So Jane x 1,000.</td>\n</tr>\n<tr>\n<th><a href="http://example.org/">Jane Bloggs</a></th>\n<td>$100B</td>\n<td>With hair like that?! Enough said...</td>\n</tr>\n</tbody>\n</table>\n<h2>Definition Lists</h2>\n<dl><dt>Definition List Title</dt><dd>Definition list division.</dd><dt>Startup</dt><dd>A startup company or startup is a company or temporary organization designed to search for a repeatable and scalable business model.</dd><dt>#dowork</dt><dd>Coined by Rob Dyrdek and his personal body guard Christopher "Big Black" Boykins, "Do Work" works as a self motivator, to motivating your friends.</dd><dt>Do It Live</dt><dd>I\'ll let Bill O\'Reilly will <a title="We\'ll Do It Live" href="https://www.youtube.com/watch?v=O_HyZ5aW76c">explain</a> this one.</dd></dl>\n<h2>Unordered Lists (Nested)</h2>\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one\n<ul>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ul>\n<h2>Ordered List (Nested)</h2>\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one\n<ol>\n	<li>List item one</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n</li>\n	<li>List item two</li>\n	<li>List item three</li>\n	<li>List item four</li>\n</ol>\n<h2>HTML Tags</h2>\nThese supported tags come from the WordPress.com code <a title="Code" href="http://en.support.wordpress.com/code/">FAQ</a>.\n\n<strong>Address Tag</strong>\n\n<address>1 Infinite Loop\nCupertino, CA 95014\nUnited States</address><strong>Anchor Tag (aka. Link)</strong>\n\nThis is an example of a <a title="Apple" href="http://apple.com">link</a>.\n\n<strong>Abbreviation Tag</strong>\n\nThe abbreviation <abbr title="Seriously">srsly</abbr> stands for "seriously".\n\n<strong>Acronym Tag (<em>deprecated in HTML5</em>)</strong>\n\nThe acronym <acronym title="For The Win">ftw</acronym> stands for "for the win".\n\n<strong>Big Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThese tests are a <big>big</big> deal, but this tag is no longer supported in HTML5.\n\n<strong>Cite Tag</strong>\n\n"Code is poetry." --<cite>Automattic</cite>\n\n<strong>Code Tag</strong>\n\nYou will learn later on in these tests that <code>word-wrap: break-word;</code> will be your best friend.\n\n<strong>Delete Tag</strong>\n\nThis tag will let you <del>strikeout text</del>, but this tag is no longer supported in HTML5 (use the <code>&lt;strike&gt;</code> instead).\n\n<strong>Emphasize Tag</strong>\n\nThe emphasize tag should <em>italicize</em> text.\n\n<strong>Insert Tag</strong>\n\nThis tag should denote <ins>inserted</ins> text.\n\n<strong>Keyboard Tag</strong>\n\nThis scarcely known tag emulates <kbd>keyboard text</kbd>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Preformatted Tag</strong>\n\nThis tag styles large blocks of code.\n<pre>.post-title {\n	margin: 0 0 5px;\n	font-weight: bold;\n	font-size: 38px;\n	line-height: 1.2;\n	and here\'s a line of some really, really, really, really long text, just to see how the PRE tag handles it and to find out how it overflows;\n}</pre>\n<strong>Quote Tag</strong>\n\n<q>Developers, developers, developers...</q> --Steve Ballmer\n\n<strong>Strike Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis tag shows <span style="text-decoration: line-through;">strike-through text</span>\n\n<strong>Strong Tag</strong>\n\nThis tag shows <strong>bold<strong> text.</strong></strong>\n\n<strong>Subscript Tag</strong>\n\nGetting our science styling on with H<sub>2</sub>O, which should push the "2" down.\n\n<strong>Superscript Tag</strong>\n\nStill sticking with science and Isaac Newton\'s E = MC<sup>2</sup>, which should lift the 2 up.\n\n<strong>Teletype Tag <strong>(<em>deprecated in HTML5</em>)</strong></strong>\n\nThis rarely used tag emulates <tt>teletype text</tt>, which is usually styled like the <code>&lt;code&gt;</code> tag.\n\n<strong>Variable Tag</strong>\n\nThis allows you to denote <var>variables</var>.', 'Ten Things We Say In Sample Blog Posts', '', 'trash', 'closed', 'closed', '', 'ten-things-we-say-in-sample-blog-posts-2__trashed', '', '', '2018-01-17 15:33:54', '2018-01-17 20:33:54', '', 0, 'http://localhost/knightsservice.com/service/ten-things-we-say-in-sample-blog-posts-2/', 10, 'service', '', 0),
(66, 1, '2018-01-06 20:33:03', '2018-01-07 01:33:03', '<h1>Lorem Ipsum</h1>\n\n<blockquote>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit..."\n"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain..."</blockquote>\n\n<h2>What is Lorem Ipsum?</h2>\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\n\n<h3>Why do we use it?</h3>\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\n<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>', 'This Post Has a Very Long Title and Should Look Great on All Devices', '', 'trash', 'closed', 'closed', '', 'this-post-has-a-very-long-title-and-should-look-great-on-all-devices-3__trashed', '', '', '2018-01-17 15:33:54', '2018-01-17 20:33:54', '', 0, 'http://localhost/knightsservice.com/service/this-post-has-a-very-long-title-and-should-look-great-on-all-devices-3/', 11, 'service', '', 0),
(67, 1, '2018-01-18 15:45:01', '2018-01-18 20:45:01', 'Sed felis neque viverra in eleifend acpharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae. Fusce varius risus dapibus dolor. Donec tristique faucibus velit aliquam erat volutpat integer sed felis. Quisque odio lacus tincidunt fringilla iaculis vitae dictum a quam cras consectetuer interdum odio pellentesque ideros nulla atenim.', 'Ladder Assist', 'Ipsum vitae sollicitudin interdum, felis ipsum scelerisque leo turpis in convallis massa dolor. ', 'publish', 'closed', 'closed', '', 'ladder-assist', '', '', '2018-01-19 18:09:22', '2018-01-19 23:09:22', '', 0, 'http://localhost/knightsservice.com/?post_type=service&#038;p=67', 0, 'service', '', 0),
(68, 1, '2018-01-17 15:45:52', '2018-01-17 20:45:52', '', 'icon', '', 'inherit', 'closed', 'closed', '', 'icon', '', '', '2018-01-17 15:45:52', '2018-01-17 20:45:52', '', 67, 'http://localhost/knightsservice.com/wp-content/uploads/2018/01/icon.svg', 0, 'attachment', 'image/svg+xml', 0),
(69, 1, '2018-01-17 15:47:32', '2018-01-17 20:47:32', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:7:"service";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Services fields', 'services-fields', 'publish', 'closed', 'closed', '', 'group_5a5fb6496bf26', '', '', '2018-01-17 15:49:02', '2018-01-17 20:49:02', '', 0, 'http://localhost/knightsservice.com/?post_type=acf-field-group&#038;p=69', 0, 'acf-field-group', '', 0),
(70, 1, '2018-01-17 15:47:32', '2018-01-17 20:47:32', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Service overview', 'service_overview', 'publish', 'closed', 'closed', '', 'field_5a5fb657f502a', '', '', '2018-01-17 15:47:32', '2018-01-17 20:47:32', '', 69, 'http://localhost/knightsservice.com/?post_type=acf-field&p=70', 0, 'acf-field', '', 0),
(71, 1, '2018-01-17 15:48:47', '2018-01-17 20:48:47', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Service menu icon', 'service_menu_icon', 'publish', 'closed', 'closed', '', 'field_5a5fb6a321652', '', '', '2018-01-17 15:49:02', '2018-01-17 20:49:02', '', 69, 'http://localhost/knightsservice.com/?post_type=acf-field&#038;p=71', 1, 'acf-field', '', 0),
(72, 1, '2018-01-17 15:49:41', '2018-01-17 20:49:41', '', 'group-2', '', 'inherit', 'closed', 'closed', '', 'group-2', '', '', '2018-01-17 15:49:41', '2018-01-17 20:49:41', '', 67, 'http://localhost/knightsservice.com/wp-content/uploads/2018/01/group-2.svg', 0, 'attachment', 'image/svg+xml', 0),
(73, 1, '2018-01-15 15:50:50', '2018-01-15 20:50:50', 'Sed felis neque viverra in eleifend acpharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae. Fusce varius risus dapibus dolor. Donec tristique faucibus velit aliquam erat volutpat integer sed felis. Quisque odio lacus tincidunt fringilla iaculis vitae dictum a quam cras consectetuer interdum odio pellentesque ideros nulla atenim.', 'Direct Roof Inspections', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit phasellus vestibulum ornare non accumsan sed sapien. ', 'publish', 'closed', 'closed', '', 'direct-roof-inspections', '', '', '2018-01-19 18:08:34', '2018-01-19 23:08:34', '', 0, 'http://localhost/knightsservice.com/?post_type=service&#038;p=73', 0, 'service', '', 0),
(74, 1, '2018-01-17 15:50:45', '2018-01-17 20:50:45', '', 'group-10', '', 'inherit', 'closed', 'closed', '', 'group-10', '', '', '2018-01-17 15:50:45', '2018-01-17 20:50:45', '', 73, 'http://localhost/knightsservice.com/wp-content/uploads/2018/01/group-10.svg', 0, 'attachment', 'image/svg+xml', 0),
(75, 1, '2018-01-17 15:52:05', '2018-01-17 20:52:05', 'Sed felis neque viverra in eleifend acpharetra in lectus. Curabitur tristique turpis semper quam. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae. Fusce varius risus dapibus dolor. Donec tristique faucibus velit aliquam erat volutpat integer sed felis. Quisque odio lacus tincidunt fringilla iaculis vitae dictum a quam cras consectetuer interdum odio pellentesque ideros nulla atenim.', 'Virtual Claims Inspection', 'Curabitur sed mauris sed molestie faucibus nunc aliquet phasellus laoreet orci lorem nulla lacinia.', 'publish', 'closed', 'closed', '', 'virtual-claims-inspection', '', '', '2018-01-19 18:10:43', '2018-01-19 23:10:43', '', 0, 'http://localhost/knightsservice.com/?post_type=service&#038;p=75', 0, 'service', '', 0),
(76, 1, '2018-01-17 15:52:00', '2018-01-17 20:52:00', '', 'group-14', '', 'inherit', 'closed', 'closed', '', 'group-14', '', '', '2018-01-17 15:52:00', '2018-01-17 20:52:00', '', 75, 'http://localhost/knightsservice.com/wp-content/uploads/2018/01/group-14.svg', 0, 'attachment', 'image/svg+xml', 0),
(77, 1, '2018-01-16 15:53:02', '2018-01-16 20:53:02', 'Donec tristique faucibus velit aliquam erat volutpat integer sed felis. Quisque odio lacus tincidunt fringilla iaculis vitae dictum a quam cras consectetuer interdum odio pellentesque ideros nulla atenim.', 'Certified adjuster', 'Etiam lobortis velit phasellus suscipit urna class aptent taciti torquent hymenaeos selim.', 'publish', 'closed', 'closed', '', 'certified-adjuster', '', '', '2018-01-19 18:11:20', '2018-01-19 23:11:20', '', 0, 'http://localhost/knightsservice.com/?post_type=service&#038;p=77', 0, 'service', '', 0),
(78, 1, '2018-01-17 15:52:58', '2018-01-17 20:52:58', '', 'group-15', '', 'inherit', 'closed', 'closed', '', 'group-15', '', '', '2018-01-17 15:52:58', '2018-01-17 20:52:58', '', 77, 'http://localhost/knightsservice.com/wp-content/uploads/2018/01/group-15.svg', 0, 'attachment', 'image/svg+xml', 0),
(79, 1, '2018-01-17 15:54:15', '2018-01-17 20:54:15', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"page_type";s:8:"operator";s:2:"==";s:5:"value";s:10:"front_page";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Home page fields', 'home-page-fields', 'publish', 'closed', 'closed', '', 'group_5a5fb7b8316fe', '', '', '2018-01-17 16:30:13', '2018-01-17 21:30:13', '', 0, 'http://localhost/knightsservice.com/?post_type=acf-field-group&#038;p=79', 0, 'acf-field-group', '', 0),
(80, 1, '2018-01-17 15:54:15', '2018-01-17 20:54:15', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";i:4;s:6:"layout";s:5:"table";s:12:"button_label";s:11:"Add service";}', 'Services', 'home_services', 'publish', 'closed', 'closed', '', 'field_5a5fb7c0f30a5', '', '', '2018-01-17 16:09:28', '2018-01-17 21:09:28', '', 79, 'http://localhost/knightsservice.com/?post_type=acf-field&#038;p=80', 1, 'acf-field', '', 0),
(81, 1, '2018-01-17 15:54:15', '2018-01-17 20:54:15', 'a:11:{s:4:"type";s:11:"post_object";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:1:{i:0;s:7:"service";}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:0;s:8:"multiple";i:0;s:13:"return_format";s:2:"id";s:2:"ui";i:1;}', 'Service', 'home_service', 'publish', 'closed', 'closed', '', 'field_5a5fb7cdf30a6', '', '', '2018-01-17 16:09:28', '2018-01-17 21:09:28', '', 80, 'http://localhost/knightsservice.com/?post_type=acf-field&#038;p=81', 0, 'acf-field', '', 0),
(82, 1, '2018-01-17 15:54:52', '2018-01-17 20:54:52', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Services section', '', 'publish', 'closed', 'closed', '', 'field_5a5fb8104cb80', '', '', '2018-01-17 15:57:13', '2018-01-17 20:57:13', '', 79, 'http://localhost/knightsservice.com/?post_type=acf-field&#038;p=82', 0, 'acf-field', '', 0),
(83, 1, '2018-01-17 15:57:13', '2018-01-17 20:57:13', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'About us section', '', 'publish', 'closed', 'closed', '', 'field_5a5fb829b62ba', '', '', '2018-01-17 15:57:13', '2018-01-17 20:57:13', '', 79, 'http://localhost/knightsservice.com/?post_type=acf-field&p=83', 2, 'acf-field', '', 0),
(84, 1, '2018-01-17 15:57:13', '2018-01-17 20:57:13', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:12:"medium_large";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'About background image', 'about_background_image', 'publish', 'closed', 'closed', '', 'field_5a5fb831b62bb', '', '', '2018-01-17 15:57:13', '2018-01-17 20:57:13', '', 79, 'http://localhost/knightsservice.com/?post_type=acf-field&p=84', 3, 'acf-field', '', 0),
(85, 1, '2018-01-17 15:57:13', '2018-01-17 20:57:13', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'About title', 'about_title', 'publish', 'closed', 'closed', '', 'field_5a5fb879b62bd', '', '', '2018-01-17 15:59:38', '2018-01-17 20:59:38', '', 79, 'http://localhost/knightsservice.com/?post_type=acf-field&#038;p=85', 4, 'acf-field', '', 0),
(86, 1, '2018-01-17 15:57:13', '2018-01-17 20:57:13', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'About text', 'about_text', 'publish', 'closed', 'closed', '', 'field_5a5fb868b62bc', '', '', '2018-01-17 15:59:38', '2018-01-17 20:59:38', '', 79, 'http://localhost/knightsservice.com/?post_type=acf-field&#038;p=86', 5, 'acf-field', '', 0),
(87, 1, '2018-01-17 15:57:13', '2018-01-17 20:57:13', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'About button text', 'about_button_text', 'publish', 'closed', 'closed', '', 'field_5a5fb887b62be', '', '', '2018-01-17 15:59:38', '2018-01-17 20:59:38', '', 79, 'http://localhost/knightsservice.com/?post_type=acf-field&#038;p=87', 6, 'acf-field', '', 0),
(88, 1, '2018-01-17 15:57:13', '2018-01-17 20:57:13', 'a:10:{s:4:"type";s:9:"page_link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:0:{}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:0;s:14:"allow_archives";i:1;s:8:"multiple";i:0;}', 'About button link', 'about_button_link', 'publish', 'closed', 'closed', '', 'field_5a5fb890b62bf', '', '', '2018-01-17 15:59:38', '2018-01-17 20:59:38', '', 79, 'http://localhost/knightsservice.com/?post_type=acf-field&#038;p=88', 7, 'acf-field', '', 0),
(89, 1, '2018-01-17 15:59:38', '2018-01-17 20:59:38', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Help section', '', 'publish', 'closed', 'closed', '', 'field_5a5fb8c56d45e', '', '', '2018-01-17 15:59:38', '2018-01-17 20:59:38', '', 79, 'http://localhost/knightsservice.com/?post_type=acf-field&p=89', 8, 'acf-field', '', 0),
(90, 1, '2018-01-17 15:59:38', '2018-01-17 20:59:38', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:12:"medium_large";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Help background image', 'help_background_image', 'publish', 'closed', 'closed', '', 'field_5a5fb8d76d45f', '', '', '2018-01-17 15:59:38', '2018-01-17 20:59:38', '', 79, 'http://localhost/knightsservice.com/?post_type=acf-field&p=90', 9, 'acf-field', '', 0),
(91, 1, '2018-01-17 15:59:38', '2018-01-17 20:59:38', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Help text', 'help_text', 'publish', 'closed', 'closed', '', 'field_5a5fb8ef6d462', '', '', '2018-01-17 16:30:13', '2018-01-17 21:30:13', '', 79, 'http://localhost/knightsservice.com/?post_type=acf-field&#038;p=91', 11, 'acf-field', '', 0),
(92, 1, '2018-01-17 15:59:38', '2018-01-17 20:59:38', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Help button text', 'help_button_text', 'publish', 'closed', 'closed', '', 'field_5a5fb8e06d460', '', '', '2018-01-17 16:30:13', '2018-01-17 21:30:13', '', 79, 'http://localhost/knightsservice.com/?post_type=acf-field&#038;p=92', 12, 'acf-field', '', 0),
(93, 1, '2018-01-17 15:59:38', '2018-01-17 20:59:38', 'a:10:{s:4:"type";s:9:"page_link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:0:{}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:0;s:14:"allow_archives";i:1;s:8:"multiple";i:0;}', 'Help button link', 'help_button_link', 'publish', 'closed', 'closed', '', 'field_5a5fb8e46d461', '', '', '2018-01-17 16:30:13', '2018-01-17 21:30:13', '', 79, 'http://localhost/knightsservice.com/?post_type=acf-field&#038;p=93', 13, 'acf-field', '', 0),
(94, 1, '2018-01-17 16:00:27', '2018-01-17 21:00:27', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:21:"msw-framework-options";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Theme options', 'theme-options', 'publish', 'closed', 'closed', '', 'group_5a5fb95bdce04', '', '', '2018-01-19 08:13:43', '2018-01-19 13:13:43', '', 0, 'http://localhost/knightsservice.com/?post_type=acf-field-group&#038;p=94', 0, 'acf-field-group', '', 0),
(95, 1, '2018-01-17 16:00:27', '2018-01-17 21:00:27', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Footer CTA', '', 'publish', 'closed', 'closed', '', 'field_5a5fb9606bf5c', '', '', '2018-01-17 16:00:27', '2018-01-17 21:00:27', '', 94, 'http://localhost/knightsservice.com/?post_type=acf-field&p=95', 0, 'acf-field', '', 0),
(96, 1, '2018-01-17 16:02:20', '2018-01-17 21:02:20', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Footer CTA bg image', 'footer_cta_bg_image', 'publish', 'closed', 'closed', '', 'field_5a5fb9752fd67', '', '', '2018-01-17 16:02:20', '2018-01-17 21:02:20', '', 94, 'http://localhost/knightsservice.com/?post_type=acf-field&p=96', 1, 'acf-field', '', 0),
(97, 1, '2018-01-17 16:02:20', '2018-01-17 21:02:20', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Footer CTA logo', 'footer_cta_logo', 'publish', 'closed', 'closed', '', 'field_5a5fb9c42fd6b', '', '', '2018-01-17 16:02:20', '2018-01-17 21:02:20', '', 94, 'http://localhost/knightsservice.com/?post_type=acf-field&p=97', 2, 'acf-field', '', 0),
(98, 1, '2018-01-17 16:02:20', '2018-01-17 21:02:20', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Footer CTA text', 'footer_cta_text', 'publish', 'closed', 'closed', '', 'field_5a5fb9812fd68', '', '', '2018-01-17 16:02:20', '2018-01-17 21:02:20', '', 94, 'http://localhost/knightsservice.com/?post_type=acf-field&p=98', 3, 'acf-field', '', 0),
(99, 1, '2018-01-17 16:02:20', '2018-01-17 21:02:20', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Footer CTA button text', 'footer_cta_button_text', 'publish', 'closed', 'closed', '', 'field_5a5fb9ab2fd69', '', '', '2018-01-17 16:02:20', '2018-01-17 21:02:20', '', 94, 'http://localhost/knightsservice.com/?post_type=acf-field&p=99', 4, 'acf-field', '', 0),
(100, 1, '2018-01-17 16:02:20', '2018-01-17 21:02:20', 'a:10:{s:4:"type";s:9:"page_link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:0:{}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:0;s:14:"allow_archives";i:1;s:8:"multiple";i:0;}', 'Footer CTA button link', 'footer_cta_button_link', 'publish', 'closed', 'closed', '', 'field_5a5fb9b32fd6a', '', '', '2018-01-17 16:02:20', '2018-01-17 21:02:20', '', 94, 'http://localhost/knightsservice.com/?post_type=acf-field&p=100', 5, 'acf-field', '', 0),
(101, 1, '2018-01-17 16:18:42', '2018-01-17 21:18:42', '', 'Home Page', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2018-01-17 16:18:42', '2018-01-17 21:18:42', '', 4, 'http://localhost/knightsservice.com/4-revision-v1/', 0, 'revision', '', 0),
(102, 1, '2018-01-17 16:25:49', '2018-01-17 21:25:49', '', 'Home Page', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2018-01-17 16:25:49', '2018-01-17 21:25:49', '', 4, 'http://localhost/knightsservice.com/4-revision-v1/', 0, 'revision', '', 0),
(103, 1, '2018-01-17 16:27:44', '2018-01-17 21:27:44', '', 'Home Page', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2018-01-17 16:27:44', '2018-01-17 21:27:44', '', 4, 'http://localhost/knightsservice.com/4-revision-v1/', 0, 'revision', '', 0),
(104, 1, '2018-01-17 16:30:13', '2018-01-17 21:30:13', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Help detail image', 'help_detail_image', 'publish', 'closed', 'closed', '', 'field_5a5fc05279a3c', '', '', '2018-01-17 16:30:13', '2018-01-17 21:30:13', '', 79, 'http://localhost/knightsservice.com/?post_type=acf-field&p=104', 10, 'acf-field', '', 0),
(105, 1, '2018-01-17 16:43:56', '2018-01-17 21:43:56', '', 'The King Blog', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-01-17 16:43:56', '2018-01-17 21:43:56', '', 5, 'http://localhost/knightsservice.com/5-revision-v1/', 0, 'revision', '', 0),
(106, 1, '2018-01-17 16:44:08', '2018-01-17 21:44:08', '', 'The Knight Blog', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-01-17 16:44:08', '2018-01-17 21:44:08', '', 5, 'http://localhost/knightsservice.com/5-revision-v1/', 0, 'revision', '', 0),
(107, 1, '2018-01-17 16:44:59', '2018-01-17 21:44:59', '', 'sky', '', 'inherit', 'closed', 'closed', '', 'sky', '', '', '2018-01-17 16:45:02', '2018-01-17 21:45:02', '', 4, 'http://localhost/knightsservice.com/wp-content/uploads/2018/01/sky.jpg', 0, 'attachment', 'image/jpeg', 0),
(108, 1, '2018-01-17 16:45:56', '2018-01-17 21:45:56', '', 'Home Page', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2018-01-17 16:45:56', '2018-01-17 21:45:56', '', 4, 'http://localhost/knightsservice.com/4-revision-v1/', 0, 'revision', '', 0),
(109, 1, '2018-01-17 16:46:29', '2018-01-17 21:46:29', '', 'Home Page', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2018-01-17 16:46:29', '2018-01-17 21:46:29', '', 4, 'http://localhost/knightsservice.com/4-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(110, 1, '2018-01-17 16:46:50', '2018-01-17 21:46:50', '', 'drone', '', 'inherit', 'closed', 'closed', '', 'drone', '', '', '2018-01-17 16:46:51', '2018-01-17 21:46:51', '', 4, 'http://localhost/knightsservice.com/wp-content/uploads/2018/01/drone.png', 0, 'attachment', 'image/png', 0),
(111, 1, '2018-01-17 16:46:53', '2018-01-17 21:46:53', '', 'Home Page', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2018-01-17 16:46:53', '2018-01-17 21:46:53', '', 4, 'http://localhost/knightsservice.com/4-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(112, 1, '2018-01-17 16:47:09', '2018-01-17 21:47:09', '', 'Home Page', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2018-01-17 16:47:09', '2018-01-17 21:47:09', '', 4, 'http://localhost/knightsservice.com/4-revision-v1/', 0, 'revision', '', 0),
(113, 1, '2018-01-17 16:48:49', '2018-01-17 21:48:49', '', 'roofs', '', 'inherit', 'closed', 'closed', '', 'roofs', '', '', '2018-01-17 16:48:52', '2018-01-17 21:48:52', '', 0, 'http://localhost/knightsservice.com/wp-content/uploads/2018/01/roofs.jpg', 0, 'attachment', 'image/jpeg', 0),
(114, 1, '2018-01-17 16:49:21', '2018-01-17 21:49:21', '', 'logo', '', 'inherit', 'closed', 'closed', '', 'logo-2', '', '', '2018-01-17 16:49:21', '2018-01-17 21:49:21', '', 0, 'http://localhost/knightsservice.com/wp-content/uploads/2018/01/logo-2.svg', 0, 'attachment', 'image/svg+xml', 0),
(115, 1, '2018-01-18 15:22:23', '2018-01-18 20:22:23', 'Vivamus suscipit tortor eget felis porttitor volutpat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur aliquet quam id dui posuere blandit.\r\n\r\nDonec sollicitudin molestie malesuada. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui.', 'Ladder services', '', 'inherit', 'closed', 'closed', '', '31-revision-v1', '', '', '2018-01-18 15:22:23', '2018-01-18 20:22:23', '', 31, 'http://localhost/knightsservice.com/31-revision-v1/', 0, 'revision', '', 0),
(116, 1, '2018-01-18 15:35:35', '2018-01-18 20:35:35', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:28:"msw-service-archive-settings";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Services archive fields', 'services-archive-fields', 'publish', 'closed', 'closed', '', 'group_5a6104f84c915', '', '', '2018-01-18 15:35:44', '2018-01-18 20:35:44', '', 0, 'http://localhost/knightsservice.com/?post_type=acf-field-group&#038;p=116', 0, 'acf-field-group', '', 0),
(117, 1, '2018-01-18 15:35:35', '2018-01-18 20:35:35', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Services intro', 'services_intro', 'publish', 'closed', 'closed', '', 'field_5a61050482b74', '', '', '2018-01-18 15:35:35', '2018-01-18 20:35:35', '', 116, 'http://localhost/knightsservice.com/?post_type=acf-field&p=117', 0, 'acf-field', '', 0),
(118, 1, '2018-01-19 08:05:00', '2018-01-19 13:05:00', '', 'Ladder Services', '', 'publish', 'closed', 'closed', '', 'ladder-services', '', '', '2018-01-19 10:22:17', '2018-01-19 15:22:17', '', 0, 'http://localhost/knightsservice.com/?p=118', 1, 'nav_menu_item', '', 0),
(119, 1, '2018-01-19 08:05:18', '2018-01-19 13:05:18', ' ', '', '', 'publish', 'closed', 'closed', '', '119', '', '', '2018-01-19 10:22:17', '2018-01-19 15:22:17', '', 0, 'http://localhost/knightsservice.com/?p=119', 5, 'nav_menu_item', '', 0),
(120, 1, '2018-01-19 08:05:18', '2018-01-19 13:05:18', ' ', '', '', 'publish', 'closed', 'closed', '', '120', '', '', '2018-01-19 10:22:17', '2018-01-19 15:22:17', '', 0, 'http://localhost/knightsservice.com/?p=120', 3, 'nav_menu_item', '', 0),
(121, 1, '2018-01-19 08:05:18', '2018-01-19 13:05:18', ' ', '', '', 'publish', 'closed', 'closed', '', '121', '', '', '2018-01-19 10:22:17', '2018-01-19 15:22:17', '', 0, 'http://localhost/knightsservice.com/?p=121', 4, 'nav_menu_item', '', 0),
(122, 1, '2018-01-19 08:05:17', '2018-01-19 13:05:17', ' ', '', '', 'publish', 'closed', 'closed', '', '122', '', '', '2018-01-19 10:22:17', '2018-01-19 15:22:17', '', 0, 'http://localhost/knightsservice.com/?p=122', 2, 'nav_menu_item', '', 0),
(123, 1, '2018-01-19 08:13:43', '2018-01-19 13:13:43', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Header image', '', 'publish', 'closed', 'closed', '', 'field_5a61eeee3a66b', '', '', '2018-01-19 08:13:43', '2018-01-19 13:13:43', '', 94, 'http://localhost/knightsservice.com/?post_type=acf-field&p=123', 6, 'acf-field', '', 0),
(124, 1, '2018-01-19 08:13:43', '2018-01-19 13:13:43', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:12:"medium_large";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Header image', 'header_image', 'publish', 'closed', 'closed', '', 'field_5a61eef83a66c', '', '', '2018-01-19 08:13:43', '2018-01-19 13:13:43', '', 94, 'http://localhost/knightsservice.com/?post_type=acf-field&p=124', 7, 'acf-field', '', 0),
(125, 1, '2018-01-19 08:16:30', '2018-01-19 13:16:30', '', 'shutterstock-384604915-shingle-roof', '', 'inherit', 'closed', 'closed', '', 'shutterstock-384604915-shingle-roof', '', '', '2018-01-19 08:16:34', '2018-01-19 13:16:34', '', 0, 'http://localhost/knightsservice.com/wp-content/uploads/2018/01/shutterstock-384604915-shingle-roof.jpg', 0, 'attachment', 'image/jpeg', 0),
(126, 1, '2018-01-19 10:36:33', '2018-01-19 15:36:33', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:16:"page_contact.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Contact page fields', 'contact-page-fields', 'publish', 'closed', 'closed', '', 'group_5a62105aef869', '', '', '2018-01-19 10:41:54', '2018-01-19 15:41:54', '', 0, 'http://localhost/knightsservice.com/?post_type=acf-field-group&#038;p=126', 0, 'acf-field-group', '', 0),
(127, 1, '2018-01-19 10:36:33', '2018-01-19 15:36:33', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:12:"medium_large";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Coverage map image', 'coverage_map_image', 'publish', 'closed', 'closed', '', 'field_5a621062aac29', '', '', '2018-01-19 10:41:54', '2018-01-19 15:41:54', '', 126, 'http://localhost/knightsservice.com/?post_type=acf-field&#038;p=127', 2, 'acf-field', '', 0),
(128, 1, '2018-01-19 10:37:08', '2018-01-19 15:37:08', '', 'coverage-map', '', 'inherit', 'closed', 'closed', '', 'coverage-map', '', '', '2018-01-19 10:37:08', '2018-01-19 15:37:08', '', 6, 'http://localhost/knightsservice.com/wp-content/uploads/2018/01/coverage-map.svg', 0, 'attachment', 'image/svg+xml', 0),
(129, 1, '2018-01-19 10:37:12', '2018-01-19 15:37:12', '', 'Contact Us', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2018-01-19 10:37:12', '2018-01-19 15:37:12', '', 6, 'http://localhost/knightsservice.com/6-revision-v1/', 0, 'revision', '', 0),
(130, 1, '2018-01-19 10:41:10', '2018-01-19 15:41:10', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Coverage title', 'coverage_title', 'publish', 'closed', 'closed', '', 'field_5a621186babc5', '', '', '2018-01-19 10:41:54', '2018-01-19 15:41:54', '', 126, 'http://localhost/knightsservice.com/?post_type=acf-field&#038;p=130', 0, 'acf-field', '', 0),
(131, 1, '2018-01-19 10:41:10', '2018-01-19 15:41:10', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Coverage text', 'coverage_text', 'publish', 'closed', 'closed', '', 'field_5a62118dbabc6', '', '', '2018-01-19 10:41:54', '2018-01-19 15:41:54', '', 126, 'http://localhost/knightsservice.com/?post_type=acf-field&#038;p=131', 1, 'acf-field', '', 0),
(132, 1, '2018-01-19 10:41:41', '2018-01-19 15:41:41', '', 'Contact Us', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2018-01-19 10:41:41', '2018-01-19 15:41:41', '', 6, 'http://localhost/knightsservice.com/6-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form`
#

DROP TABLE IF EXISTS `wp_rg_form`;


#
# Table structure of table `wp_rg_form`
#

CREATE TABLE `wp_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_form`
#
INSERT INTO `wp_rg_form` ( `id`, `title`, `date_created`, `is_active`, `is_trash`) VALUES
(1, 'Contact Form', '2018-01-10 15:46:16', 1, 1),
(2, 'Contact Form', '2018-01-18 19:55:56', 1, 0) ;

#
# End of data contents of table `wp_rg_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_meta`
#

DROP TABLE IF EXISTS `wp_rg_form_meta`;


#
# Table structure of table `wp_rg_form_meta`
#

CREATE TABLE `wp_rg_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `entries_grid_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `confirmations` longtext COLLATE utf8mb4_unicode_520_ci,
  `notifications` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_form_meta`
#
INSERT INTO `wp_rg_form_meta` ( `form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(1, '{"title":"Contact Form","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[{"type":"text","id":1,"label":"First Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"gf_left_half","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","failed_validation":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":""},{"type":"text","id":2,"label":"Last Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"gf_right_half","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","failed_validation":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":""},{"type":"email","id":3,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"gf_left_half","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","failed_validation":"","productField":"","emailConfirmEnabled":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":""},{"type":"phone","id":4,"label":"Phone","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"phoneFormat":"standard","formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"gf_right_half","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","form_id":"","failed_validation":"","productField":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":""},{"type":"textarea","id":5,"label":"Message","adminLabel":"","isRequired":false,"size":"medium","errorMessage":"","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","failed_validation":"","productField":"","form_id":"","useRichTextEditor":false,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"displayOnly":""}],"version":"2.1.1.25","id":1,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"subLabelPlacement":"below","cssClass":"","enableHoneypot":true,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":""}', NULL, '{"5864c20d1ea26":{"id":"5864c20d1ea26","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}}', '{"5864c20d1dba5":{"isActive":true,"id":"5864c20d1dba5","name":"Admin Notification","service":"wordpress","event":"form_submission","to":"{admin_email}","toType":"email","bcc":"","subject":"Website Inquiry","message":"{all_fields}","from":"wp@makespaceweb.com","fromName":"WordPress","replyTo":"{Email:3}","routing":null,"conditionalLogic":null,"disableAutoformat":false}}'),
(2, '{"title":"Contact Form","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Send Your Message","imageUrl":""},"fields":[{"type":"select","id":6,"label":"","adminLabel":"","isRequired":false,"size":"medium","errorMessage":"","inputs":null,"choices":[{"text":"Ladder services","value":"Ladder services","isSelected":false,"price":""},{"text":"Drone technology","value":"Drone technology","isSelected":false,"price":""},{"text":"Reporting","value":"Reporting","isSelected":false,"price":""}],"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Choose a Category","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","conditionalLogic":"","productField":"","enablePrice":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":"","pageNumber":1},{"type":"text","id":1,"label":"First Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"gf_left_half","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":"","pageNumber":1},{"type":"text","id":2,"label":"Last Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"gf_right_half","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":"","pageNumber":1},{"type":"email","id":3,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"gf_left_half","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","emailConfirmEnabled":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":"","pageNumber":1},{"type":"phone","id":4,"label":"Phone","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"phoneFormat":"standard","formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"gf_right_half","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","form_id":"","productField":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"displayOnly":"","pageNumber":1},{"type":"textarea","id":5,"label":"Message","adminLabel":"","isRequired":false,"size":"medium","errorMessage":"","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"","cssClass":"","inputName":"","visibility":"visible","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","form_id":"","useRichTextEditor":false,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"displayOnly":"","pageNumber":1}],"version":"2.2.5","id":2,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"subLabelPlacement":"below","cssClass":"","enableHoneypot":true,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":""}', NULL, '{"5864c20d1ea26":{"id":"5864c20d1ea26","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}}', '{"5864c20d1dba5":{"isActive":true,"id":"5864c20d1dba5","name":"Admin Notification","service":"wordpress","event":"form_submission","to":"{admin_email}","toType":"email","bcc":"","subject":"Website Inquiry","message":"{all_fields}","from":"wp@makespaceweb.com","fromName":"WordPress","replyTo":"{Email:3}","routing":null,"conditionalLogic":null,"disableAutoformat":false}}') ;

#
# End of data contents of table `wp_rg_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_view`
#

DROP TABLE IF EXISTS `wp_rg_form_view`;


#
# Table structure of table `wp_rg_form_view`
#

CREATE TABLE `wp_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `date_created` (`date_created`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_form_view`
#

#
# End of data contents of table `wp_rg_form_view`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_incomplete_submissions`
#

DROP TABLE IF EXISTS `wp_rg_incomplete_submissions`;


#
# Table structure of table `wp_rg_incomplete_submissions`
#

CREATE TABLE `wp_rg_incomplete_submissions` (
  `uuid` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `submission` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_incomplete_submissions`
#

#
# End of data contents of table `wp_rg_incomplete_submissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead`
#

DROP TABLE IF EXISTS `wp_rg_lead`;


#
# Table structure of table `wp_rg_lead`
#

CREATE TABLE `wp_rg_lead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `payment_method` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead`
#

#
# End of data contents of table `wp_rg_lead`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail`;


#
# Table structure of table `wp_rg_lead_detail`
#

CREATE TABLE `wp_rg_lead_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `field_number` float NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_field_number` (`lead_id`,`field_number`),
  KEY `lead_field_value` (`value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_detail`
#

#
# End of data contents of table `wp_rg_lead_detail`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail_long`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail_long`;


#
# Table structure of table `wp_rg_lead_detail_long`
#

CREATE TABLE `wp_rg_lead_detail_long` (
  `lead_detail_id` bigint(20) unsigned NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`lead_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_detail_long`
#

#
# End of data contents of table `wp_rg_lead_detail_long`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_meta`
#

DROP TABLE IF EXISTS `wp_rg_lead_meta`;


#
# Table structure of table `wp_rg_lead_meta`
#

CREATE TABLE `wp_rg_lead_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lead_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `lead_id` (`lead_id`),
  KEY `form_id_meta_key` (`form_id`,`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_meta`
#

#
# End of data contents of table `wp_rg_lead_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_notes`
#

DROP TABLE IF EXISTS `wp_rg_lead_notes`;


#
# Table structure of table `wp_rg_lead_notes`
#

CREATE TABLE `wp_rg_lead_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  `note_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_user_key` (`lead_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_notes`
#

#
# End of data contents of table `wp_rg_lead_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(10, 1, 0),
(12, 1, 0),
(13, 1, 0),
(14, 1, 0),
(16, 1, 0),
(17, 1, 0),
(18, 1, 0),
(20, 1, 0),
(21, 1, 0),
(22, 1, 0),
(23, 1, 0),
(39, 2, 0),
(40, 2, 0),
(42, 3, 0),
(43, 3, 0),
(44, 3, 0),
(45, 3, 0),
(118, 2, 0),
(119, 2, 0),
(120, 2, 0),
(121, 2, 0),
(122, 2, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 11),
(2, 2, 'nav_menu', '', 0, 7),
(3, 3, 'nav_menu', '', 0, 4) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Primary', 'primary', 0),
(3, 'Secondary', 'secondary', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'makespace'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'addtoany_settings_pointer'),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:1:{s:64:"04a86056fa2ec948af0755eb1ca8156b267a2359880c7512f09704e5021152bb";a:4:{s:10:"expiration";i:1516575266;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36";s:5:"login";i:1516402466;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '3'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:2:"::";}'),
(19, 1, 'wp_yoast_notifications', 'a:8:{i:0;a:2:{s:7:"message";s:235:"You just changed the URL of this Field Group. To ensure your visitors do not see a 404 on the old URL, you should create a redirect. <a href="https://yoa.st/1d0?utm_content=6.1.1" target="_blank">Learn how to create redirects here.</a>";s:7:"options";a:8:{s:4:"type";s:11:"notice-info";s:2:"id";s:0:"";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";a:1:{i:0;s:20:"wpseo_manage_options";}s:16:"capability_check";s:3:"all";}}i:1;a:2:{s:7:"message";s:235:"You just changed the URL of this Field Group. To ensure your visitors do not see a 404 on the old URL, you should create a redirect. <a href="https://yoa.st/1d0?utm_content=6.1.1" target="_blank">Learn how to create redirects here.</a>";s:7:"options";a:8:{s:4:"type";s:11:"notice-info";s:2:"id";s:0:"";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";a:1:{i:0;s:20:"wpseo_manage_options";}s:16:"capability_check";s:3:"all";}}i:2;a:2:{s:7:"message";s:235:"You just changed the URL of this Field Group. To ensure your visitors do not see a 404 on the old URL, you should create a redirect. <a href="https://yoa.st/1d0?utm_content=6.1.1" target="_blank">Learn how to create redirects here.</a>";s:7:"options";a:8:{s:4:"type";s:11:"notice-info";s:2:"id";s:0:"";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";a:1:{i:0;s:20:"wpseo_manage_options";}s:16:"capability_check";s:3:"all";}}i:3;a:2:{s:7:"message";s:235:"You just changed the URL of this Field Group. To ensure your visitors do not see a 404 on the old URL, you should create a redirect. <a href="https://yoa.st/1d0?utm_content=6.1.1" target="_blank">Learn how to create redirects here.</a>";s:7:"options";a:8:{s:4:"type";s:11:"notice-info";s:2:"id";s:0:"";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";a:1:{i:0;s:20:"wpseo_manage_options";}s:16:"capability_check";s:3:"all";}}i:4;a:2:{s:7:"message";s:235:"You just changed the URL of this Field Group. To ensure your visitors do not see a 404 on the old URL, you should create a redirect. <a href="https://yoa.st/1d0?utm_content=6.1.1" target="_blank">Learn how to create redirects here.</a>";s:7:"options";a:8:{s:4:"type";s:11:"notice-info";s:2:"id";s:0:"";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";a:1:{i:0;s:20:"wpseo_manage_options";}s:16:"capability_check";s:3:"all";}}i:5;a:2:{s:7:"message";s:790:"We\'ve noticed you\'ve been using Yoast SEO for some time now; we hope you love it! We\'d be thrilled if you could <a href="https://yoa.st/rate-yoast-seo?utm_content=6.1.1">give us a 5 stars rating on WordPress.org</a>!\n\nIf you are experiencing issues, <a href="https://yoa.st/bugreport?utm_content=6.1.1">please file a bug report</a> and we\'ll do our best to help you out.\n\nBy the way, did you know we also have a <a href=\'https://yoa.st/premium-notification?utm_content=6.1.1\'>Premium plugin</a>? It offers advanced features, like a redirect manager and support for multiple keywords. It also comes with 24/7 personal support.\n\n<a class="button" href="http://localhost/knightsservice.com/wp-admin/?page=wpseo_dashboard&yoast_dismiss=upsell">Please don\'t show me this notification anymore</a>";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:19:"wpseo-upsell-notice";s:5:"nonce";N;s:8:"priority";d:0.8000000000000000444089209850062616169452667236328125;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:20:"wpseo_manage_options";s:16:"capability_check";s:3:"all";}}i:6;a:2:{s:7:"message";s:178:"Don\'t miss your crawl errors: <a href="http://localhost/knightsservice.com/wp-admin/admin.php?page=wpseo_search_console&tab=settings">connect with Google Search Console here</a>.";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:17:"wpseo-dismiss-gsc";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:20:"wpseo_manage_options";s:16:"capability_check";s:3:"all";}}i:7;a:2:{s:7:"message";s:286:"You still have the default WordPress tagline, even an empty one is probably better. <a href="http://localhost/knightsservice.com/wp-admin/customize.php?url=http%3A%2F%2Flocalhost%2Fknightsservice.com%2Fwp-admin%2Ftools.php%3Fpage%3Dwp-migrate-db">You can fix this in the customizer</a>.";s:7:"options";a:8:{s:4:"type";s:5:"error";s:2:"id";s:28:"wpseo-dismiss-tagline-notice";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:20:"wpseo_manage_options";s:16:"capability_check";s:3:"all";}}}'),
(20, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:15:"title-attribute";i:2;s:3:"xfn";i:3;s:11:"description";}'),
(21, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(22, 1, 'nav_menu_recently_edited', '2'),
(23, 1, 'wp_user-settings', 'libraryContent=browse&editor=html'),
(24, 1, 'wp_user-settings-time', '1516225995'),
(25, 1, 'acf_user_settings', 'a:0:{}'),
(26, 1, 'closedpostboxes_service', 'a:1:{i:0;s:10:"wpseo_meta";}'),
(27, 1, 'metaboxhidden_service', 'a:5:{i:0;s:23:"acf-group_56cbac453acf3";i:1;s:23:"acf-group_57baf550b8fda";i:2;s:23:"acf-group_56c5356f1e6e2";i:3;s:23:"acf-group_56c54930c0959";i:4;s:7:"slugdiv";}'),
(28, 1, 'closedpostboxes_acf-field-group', 'a:0:{}'),
(29, 1, 'metaboxhidden_acf-field-group', 'a:1:{i:0;s:7:"slugdiv";}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'makespace', '$P$BeBv3YFTCFlSxB29QlVirqUj.gJNyI0', 'makespace', 'wp@makespaceweb.com', '', '2018-01-10 15:45:19', '', 0, 'makespace') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_seo_links`
#

DROP TABLE IF EXISTS `wp_yoast_seo_links`;


#
# Table structure of table `wp_yoast_seo_links`
#

CREATE TABLE `wp_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `target_post_id` bigint(20) unsigned NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_seo_links`
#
INSERT INTO `wp_yoast_seo_links` ( `id`, `url`, `post_id`, `target_post_id`, `type`) VALUES
(46, 'http://example.org/', 53, 0, 'external'),
(47, 'http://example.org/', 53, 0, 'external'),
(48, 'http://example.org/', 53, 0, 'external'),
(49, 'http://example.org/', 53, 0, 'external'),
(50, 'https://www.youtube.com/watch?v=O_HyZ5aW76c', 53, 0, 'external'),
(51, 'http://en.support.wordpress.com/code/', 53, 0, 'external'),
(52, 'http://apple.com', 53, 0, 'external'),
(53, 'http://en.support.wordpress.com/images/image-settings/', 55, 0, 'external'),
(54, 'http://en.support.wordpress.com/images/image-settings/', 56, 0, 'external'),
(55, 'http://example.org/', 57, 0, 'external'),
(56, 'http://example.org/', 57, 0, 'external'),
(57, 'http://example.org/', 57, 0, 'external'),
(58, 'http://example.org/', 57, 0, 'external'),
(59, 'https://www.youtube.com/watch?v=O_HyZ5aW76c', 57, 0, 'external'),
(60, 'http://en.support.wordpress.com/code/', 57, 0, 'external'),
(61, 'http://apple.com', 57, 0, 'external'),
(62, 'http://example.org/', 58, 0, 'external'),
(63, 'http://example.org/', 58, 0, 'external'),
(64, 'http://example.org/', 58, 0, 'external'),
(65, 'http://example.org/', 58, 0, 'external'),
(66, 'https://www.youtube.com/watch?v=O_HyZ5aW76c', 58, 0, 'external'),
(67, 'http://en.support.wordpress.com/code/', 58, 0, 'external'),
(68, 'http://apple.com', 58, 0, 'external'),
(69, 'http://en.support.wordpress.com/images/image-settings/', 61, 0, 'external'),
(70, 'http://example.org/', 63, 0, 'external'),
(71, 'http://example.org/', 63, 0, 'external'),
(72, 'http://example.org/', 63, 0, 'external'),
(73, 'http://example.org/', 63, 0, 'external'),
(74, 'https://www.youtube.com/watch?v=O_HyZ5aW76c', 63, 0, 'external'),
(75, 'http://en.support.wordpress.com/code/', 63, 0, 'external'),
(76, 'http://apple.com', 63, 0, 'external'),
(77, 'http://example.org/', 64, 0, 'external'),
(78, 'http://example.org/', 64, 0, 'external'),
(79, 'http://example.org/', 64, 0, 'external'),
(80, 'http://example.org/', 64, 0, 'external'),
(81, 'https://www.youtube.com/watch?v=O_HyZ5aW76c', 64, 0, 'external'),
(82, 'http://en.support.wordpress.com/code/', 64, 0, 'external'),
(83, 'http://apple.com', 64, 0, 'external'),
(84, 'http://example.org/', 65, 0, 'external'),
(85, 'http://example.org/', 65, 0, 'external'),
(86, 'http://example.org/', 65, 0, 'external'),
(87, 'http://example.org/', 65, 0, 'external'),
(88, 'https://www.youtube.com/watch?v=O_HyZ5aW76c', 65, 0, 'external'),
(89, 'http://en.support.wordpress.com/code/', 65, 0, 'external'),
(90, 'http://apple.com', 65, 0, 'external'),
(94, 'https://www.addtoany.com/add_to/facebook?linkurl=&amp;linkname=', 73, 0, 'external'),
(95, 'https://www.addtoany.com/add_to/twitter?linkurl=&amp;linkname=', 73, 0, 'external'),
(96, 'https://www.addtoany.com/add_to/google_plus?linkurl=&amp;linkname=', 73, 0, 'external'),
(100, 'https://www.addtoany.com/add_to/facebook?linkurl=&amp;linkname=', 67, 0, 'external'),
(101, 'https://www.addtoany.com/add_to/twitter?linkurl=&amp;linkname=', 67, 0, 'external'),
(102, 'https://www.addtoany.com/add_to/google_plus?linkurl=&amp;linkname=', 67, 0, 'external'),
(106, 'https://www.addtoany.com/add_to/facebook?linkurl=&amp;linkname=', 75, 0, 'external'),
(107, 'https://www.addtoany.com/add_to/twitter?linkurl=&amp;linkname=', 75, 0, 'external'),
(108, 'https://www.addtoany.com/add_to/google_plus?linkurl=&amp;linkname=', 75, 0, 'external'),
(109, 'https://www.addtoany.com/add_to/facebook?linkurl=&amp;linkname=', 77, 0, 'external'),
(110, 'https://www.addtoany.com/add_to/twitter?linkurl=&amp;linkname=', 77, 0, 'external'),
(111, 'https://www.addtoany.com/add_to/google_plus?linkurl=&amp;linkname=', 77, 0, 'external') ;

#
# End of data contents of table `wp_yoast_seo_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_yoast_seo_meta`
#

DROP TABLE IF EXISTS `wp_yoast_seo_meta`;


#
# Table structure of table `wp_yoast_seo_meta`
#

CREATE TABLE `wp_yoast_seo_meta` (
  `object_id` bigint(20) unsigned NOT NULL,
  `internal_link_count` int(10) unsigned DEFAULT NULL,
  `incoming_link_count` int(10) unsigned DEFAULT NULL,
  UNIQUE KEY `object_id` (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_yoast_seo_meta`
#
INSERT INTO `wp_yoast_seo_meta` ( `object_id`, `internal_link_count`, `incoming_link_count`) VALUES
(3, 0, 0),
(4, 0, 0),
(5, 0, 0),
(6, 0, 0),
(25, 0, 0),
(26, 0, 0),
(27, 0, 0),
(28, 0, 0),
(29, 0, 0),
(30, 0, 0),
(31, 0, 0),
(33, 0, 0),
(35, 0, 0),
(37, 0, 0),
(41, 0, 0),
(49, 0, 0),
(50, 0, 0),
(53, 0, 0),
(55, 0, 0),
(56, 0, 0),
(57, 0, 0),
(58, 0, 0),
(60, 0, 0),
(61, 0, 0),
(63, 0, 0),
(64, 0, 0),
(65, 0, 0),
(66, 0, 0),
(67, 0, 0),
(73, 0, 0),
(75, 0, 0),
(77, 0, 0) ;

#
# End of data contents of table `wp_yoast_seo_meta`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

